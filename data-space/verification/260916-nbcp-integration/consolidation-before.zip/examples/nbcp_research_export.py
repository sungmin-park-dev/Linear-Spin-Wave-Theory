"""Assemble the NBCP research note and its single-source gap appendix.

The editable Markdown and ordinary LaTeX preamble remain separate. No physics
calculation runs here. Output is a self-contained TeX/PDF folder with hashes.
"""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'docs/nbcp/research-note.md'
APPENDIX = ROOT / 'docs/nbcp/pseudo-goldstone/comparison-report.md'
STYLE = ROOT / 'docs/nbcp/typesetting'
OUTPUT = ROOT / 'docs/build/nbcp/research-note'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(args, cwd):
    result = subprocess.run(args, cwd=cwd, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stdout[-8000:] + result.stderr[-8000:])
    return result


def main():
    quarto, xelatex = shutil.which('quarto'), shutil.which('xelatex')
    if not quarto or not xelatex:
        raise RuntimeError('Quarto and XeLaTeX are required.')
    images = {}

    def relocate(text, origin):
        def image_link(match):
            target=(origin.parent/match.group(1)).resolve()
            if not target.is_file():
                raise FileNotFoundError(target)
            if target.name in images and images[target.name] != target:
                raise ValueError('Image basename collision')
            images[target.name]=target
            return ']('+target.name+')'
        text=re.sub(r'\]\(([^)]+\.(?:png|svg|jpg))\)',image_link,text)
        # Local evidence links point to the original files, even from scratch/output.
        def local_link(match):
            href=match.group(1)
            if href.startswith(('https:', 'http:', '#')) or href in images:
                return match.group(0)
            path, sep, anchor=href.partition('#')
            target=(origin.parent/path).resolve()
            return ']('+target.as_uri()+(sep+anchor if sep else '')+')'
        return re.sub(r'\]\(([^)]+)\)',local_link,text)

    main_text=relocate(SOURCE.read_text(),SOURCE)
    appendix_text=APPENDIX.read_text().split('---',2)[2].strip()
    # One appendix contains the complete detailed note. Its original sections
    # become subsections; its own appendix flag must not restart numbering.
    appendix_text=appendix_text.replace(' .appendix','')
    appendix_text=appendix_text.replace('### Conventions at a glance','## Conventions at a glance')
    appendix_text=relocate(appendix_text,APPENDIX)
    marker='<!-- include-appendix: pseudo-goldstone/comparison-report.md -->'
    if main_text.count(marker)!=1:
        raise ValueError('Expected exactly one gap appendix inclusion marker')
    assembled=main_text.replace(marker,appendix_text)
    inputs=[SOURCE,APPENDIX,STYLE/'research-note-preamble.tex',STYLE/'research-note-filter.lua',Path(__file__)]
    original_hashes={str(p.relative_to(ROOT)):digest(p) for p in inputs}
    with tempfile.TemporaryDirectory(prefix='nbcp-research-') as directory:
        scratch=Path(directory)
        (scratch/'research-note.md').write_text(assembled)
        for name,path in images.items():
            shutil.copy2(path,scratch/name)
        settings={
            'format':{'latex':{
                'documentclass':'article','fontsize':'11pt','papersize':'a4',
                'geometry':['left=25mm','right=25mm','top=25mm','bottom=25mm'],
                'mainfont':'texgyrepagella-regular.otf',
                'mainfontoptions':['BoldFont=texgyrepagella-bold.otf','ItalicFont=texgyrepagella-italic.otf',
                                   'BoldItalicFont=texgyrepagella-bolditalic.otf'],
                'sansfont':'texgyreheros-regular.otf',
                'sansfontoptions':['BoldFont=texgyreheros-bold.otf','ItalicFont=texgyreheros-italic.otf'],
                'monofont':'texgyrecursor-regular.otf','monofontoptions':['BoldFont=texgyrecursor-bold.otf'],
                'mathfont':'texgyrepagella-math.otf','number-sections':True,
                'toc':True,'toc-depth':1,'colorlinks':True,
                'include-in-header':str(STYLE/'research-note-preamble.tex')}},
            'filters':[str(STYLE/'research-note-filter.lua')],
            'crossref':{'eq-prefix':'Eq.','fig-prefix':'Fig.'},'execute':{'enabled':False}}
        (scratch/'settings.yml').write_text(json.dumps(settings,indent=2))
        run([quarto,'render','research-note.md','--to','latex','--metadata-file','settings.yml',
             '--output','research-note.tex'],scratch)
        tex=scratch/'research-note.tex'
        tex.write_text('% Generated from docs/nbcp/research-note.md and the gap appendix.\n'
                       '% Edit Markdown for content; the standard LaTeX preamble is in docs/nbcp/typesetting/.\n'+tex.read_text())
        for _ in range(3):
            run([xelatex,'-interaction=nonstopmode','-halt-on-error','-no-shell-escape','research-note.tex'],scratch)
        log=(scratch/'research-note.log').read_text(errors='replace')
        bad=[line for line in log.splitlines() if any(k in line for k in
             ['Overfull','Missing character','undefined references','multiply defined'])]
        OUTPUT.mkdir(parents=True,exist_ok=True)
        for name in ['research-note.tex','research-note.pdf','research-note.md']+list(images):
            shutil.copy2(scratch/name,OUTPUT/name)
        manifest={'generated_utc':datetime.now(timezone.utc).isoformat(),
                  'inputs_sha256':original_hashes,
                  'figure_inputs_sha256':{str(p.relative_to(ROOT)):digest(p) for p in images.values()},
                  'outputs_sha256':{p.name:digest(p) for p in OUTPUT.iterdir() if p.name!='research-export.json'},
                  'latex_review_messages':bad,
                  'gap_appendix_display_math_delimiters':appendix_text.count('$$'),
                  'scope':'Document assembly only; no physics scan rerun'}
        (OUTPUT/'research-export.json').write_text(json.dumps(manifest,indent=2)+'\n')
        print(json.dumps(manifest,indent=2))
    assert original_hashes=={str(p.relative_to(ROOT)):digest(p) for p in inputs}


if __name__=='__main__':
    main()
