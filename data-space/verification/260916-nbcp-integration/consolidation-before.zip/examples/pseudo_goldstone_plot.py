"""Render the Y/V orbit, gap comparison and audit from saved verification data."""

import argparse
import json
import os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', '/tmp/lswt-mpl-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / 'docs/nbcp/pseudo-goldstone/comparison-report.md'
COLORS = {'current': '#126b89', 'legacy': '#be593b', 'formula': '#82858d'}


def select(report, phase, axis, value):
    return next(r for r in report['scans'] if r['phase'] == phase and
                abs(r['JPD_meV']-(value if axis == 'PD' else 0)) < 1e-12 and
                abs(r['JGamma_meV']-(value if axis == 'Gamma' else 0)) < 1e-12)


def orbit_figure(report, out):
    fig = plt.figure(figsize=(8.2, 6.0), layout='constrained')
    for row, phase in enumerate(['Y', 'V']):
        state = report['states'][phase]
        record = select(report, phase, 'Gamma', .01)
        ax = fig.add_subplot(2, 3, row*3+1, projection='3d')
        colors = ['#ce594e', '#398359', '#4765a4']
        p = np.linspace(0, 2*np.pi, 201)
        for label, t, color in zip(['A', 'B', 'C'], state['theta'], colors):
            if phase == 'V' and label == 'B':
                continue
            if phase == 'V' and label == 'A':
                label = 'A=B'
            xx, yy = np.sin(t)*np.cos(p), np.sin(t)*np.sin(p)
            ax.plot(xx, yy, np.full_like(p, np.cos(t)), color=color, alpha=.7)
            for angle, alpha in [(0, 1), (np.pi/2, .3)]:
                vec = np.array([np.sin(t)*np.cos(angle), np.sin(t)*np.sin(angle), np.cos(t)])
                ax.quiver(0, 0, 0, *vec, color=color, alpha=alpha, arrow_length_ratio=.12)
            ax.text(np.sin(t)*1.13, 0, np.cos(t)*1.13, label, color=color, fontsize=9)
        ax.set(xlim=(-1, 1), ylim=(-1, 1), zlim=(-1, 1), xlabel='x', ylabel='y', zlabel='z')
        ax.set_box_aspect((1, 1, 1))
        ax.set_xticks([-1, 0, 1])
        ax.set_yticks([-1, 0, 1])
        ax.set_zticks([-1, 0, 1])
        ax.tick_params(labelsize=7, pad=0)
        ax.xaxis.labelpad = -4
        ax.yaxis.labelpad = -4
        ax.zaxis.labelpad = -4
        ax.view_init(20, -60)
        ax.set_title(f'{phase}: B = {state["B_T"]:.1f} T')
        if phase == 'V':
            ax.text2D(.02, .93, 'A and B overlap', transform=ax.transAxes, fontsize=8)
        ax = fig.add_subplot(2, 3, row*3+2)
        ec = np.asarray(record['Ecl_meV_per_spin'])
        angle = np.degrees(record['phi'])
        ax.plot(angle, (ec-ec.mean())*1e15, color=COLORS['current'], linewidth=1)
        ax.set(xlabel=r'$\phi$ (degrees)', ylabel=r'$e_{cl}-\bar e_{cl}$ ($10^{-15}$ meV/spin)',
               title='Classical energy', xlim=(0, 360), ylim=(-.2, .2))
        ax.set_xticks([0, 120, 240, 360])
        ax.text(.04, .9, f'Roundoff only\nRange: {np.ptp(ec):.1e} meV/spin', transform=ax.transAxes, fontsize=8)
        ax = fig.add_subplot(2, 3, row*3+3)
        # Keep absolute units while resolving the very different scales.
        factor, unit = (1e12, r'$10^{-12}$ meV/spin') if phase == 'Y' else (1e6, r'$10^{-6}$ meV/spin')
        for label in ['current', 'legacy']:
            values = np.asarray(record[label]['Ezp_meV_per_spin'])
            ax.plot(np.r_[angle, 360], np.r_[values-values.min(), values[0]-values.min()]*factor,
                    label='Current Hamiltonian' if label == 'current' else 'Archived Hamiltonian',
                    color=COLORS[label], linestyle='-' if label == 'current' else '--')
        ax.set(xlabel=r'$\phi$ (degrees)', ylabel=f'$e_{{zp}}-e_{{zp,min}}$ ({unit})',
               title='Zero-point energy', xlim=(0, 360))
        ax.set_xticks([0, 120, 240, 360])
    handles, labels = fig.axes[-1].get_legend_handles_labels()
    fig.legend(handles, labels, loc='outside lower center', ncol=2, fontsize=9, frameon=False)
    for axis in fig.axes:
        if getattr(axis, 'name', '') != '3d':
            axis.grid(alpha=.2)
    for suffix in ['png', 'svg']:
        fig.savefig(out/f'yv-equal-energy-orbits.{suffix}', dpi=300)
    plt.close(fig)


def gap_figure(report, out):
    fig, axs = plt.subplots(2, 2, figsize=(8.2, 6.4), layout='constrained')
    for i, phase in enumerate(['Y', 'V']):
        for j, axis in enumerate(['PD', 'Gamma']):
            ax = axs[i, j]
            rows = sorted([r for r in report['scans'] if r['phase'] == phase and
                           r['JGamma_meV' if axis == 'PD' else 'JPD_meV'] == 0],
                          key=lambda r: r[f'J{axis}_meV'])
            x = np.array([r[f'J{axis}_meV'] for r in rows])*1000
            for label, impl, key, style in [
                ('Current H + canonical response', 'current', 'gap_with_susceptibility_meV', '-o'),
                ('Current H + old gap formula', 'current', 'gap_with_old_uniform_theta_and_times_S_meV', ':s'),
                ('Archived H + old gap formula', 'legacy', 'gap_with_old_uniform_theta_and_times_S_meV', '--^')]:
                y = [r[impl].get(key) for r in rows]
                color = COLORS['formula'] if 'Current H + old' in label else COLORS[impl]
                ax.plot(x, [v*1000 if v is not None else np.nan for v in y], style,
                        color=color, markersize=4, linewidth=1.8, label=label)
            invalid = [k for k, r in enumerate(rows) if r['current']['status'] == 'unstable_sampled_hessian']
            if invalid:
                first = x[min(invalid)]
                ax.axvspan(first, x.max()+.5, color='#edcebf', alpha=.35)
                ax.text(.99, .97, 'Sampled instability\nGap not assigned', ha='right', va='top',
                        transform=ax.transAxes, fontsize=8, color='#934123')
            unresolved = [r for r in rows if r['current']['status'] == 'below_numerical_resolution']
            if unresolved:
                ax.text(.04, .45, 'Smallest nonzero point:\nbelow numerical resolution', transform=ax.transAxes,
                        fontsize=8, color='#555555')
            state = report['states'][phase]
            coupling = r'J_{PD}' if axis == 'PD' else r'J_\Gamma'
            zero = r'$J_\Gamma=0$' if axis == 'PD' else r'$J_{PD}=0$'
            ax.set(title=f'{phase}: B = {state["B_T"]:.1f} T; '+zero,
                   xlabel=rf'${coupling}$ ($\mu$eV)', ylabel=r'Gap ($\mu$eV)', xlim=(-.5, x.max()+.5))
            ax.set_ylim(bottom=0)
            ax.grid(alpha=.2)
    handles, labels = axs[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='outside lower center', ncol=1, fontsize=9, frameon=False)
    for suffix in ['png', 'svg']:
        fig.savefig(out/f'yv-pseudo-gap-comparison.{suffix}', dpi=300)
    plt.close(fig)


def write_report(report, files, out):
    lines = ['# Y/V equal-energy orbit and pseudo-Goldstone gap audit', '',
             'Status: numerical comparison and leading-order curvature calculation for physics review.', '',
             'The production package and archived scripts have not been edited. The new verification scripts generate these results.', '',
             '## Scope and corrected interpretation', '',
             'The target is the SOC-induced gap of the common global-z orbit in arXiv:2601.20963, not the internal, nonuniform zero-field XXZ mode in arXiv:2505.07229. The earlier conversation focused on the latter; that does not invalidate the global-z orbit used by the archived Y/V scripts.', '',
             'Nearest-neighbor bonds only, S=1/2, J=0.075 meV, Jz=0.125 meV, T=0. Y: B=0.2 T; V: B=1.4 T. h=g_z mu_B B, with g_z=4.645. The original gap script defaults to J=0.076 and h=0.05 meV; the comparisons here supply the same paper parameters and states to both implementations.', '',
             '## The classical curve', '',
             r'$$\mathbf S_\alpha(\phi)=S(\sin\vartheta_\alpha\cos\phi,\sin\vartheta_\alpha\sin\phi,\cos\vartheta_\alpha).$$', '',
             r'For the three nearest-neighbor bond orientations, $\sum_d J_d=3\operatorname{diag}(J,J,J_z)$. Each A-B, B-C and C-A pair has all three orientations. Thus PD and Gamma cancel in the classical three-sublattice energy for every $\phi$, while they remain in the finite-momentum spin-wave Hamiltonian. This is an accidental degeneracy when SOC is nonzero. At zero SOC the same orbit is an exact U(1) symmetry and this particular gap is exactly zero.', '',
             'Equal energy on this restricted manifold does not prove a global classical minimum; the finite-momentum Hessians are separately checked for stability. Unstable angular backgrounds are rejected rather than shifted.', '',
             '| Phase | Signed polar angles (radians) | chi_z (1/meV per spin) | dtheta/dh (1/meV) |',
             '|---|---|---:|---|']
    for phase, s in report['states'].items():
        lines.append(f"| {phase} | {np.array(s['theta']).round(9).tolist()} | {s['chi_per_spin_per_meV']:.12g} | {np.array(s['dtheta_dh']).round(7).tolist()} |")
    lines += ['', '## Canonical response and the gap', '',
              r'Let $e_{\rm sw}(\phi)$ be the energy per physical spin and $C_\phi=e_{\rm sw}^{\prime\prime}(\phi_*)$. Define $m_z=(S/3)\sum_\alpha\cos\vartheta_\alpha$ and $\chi_z=\partial m_z/\partial h$ along the relaxed classical branch. The spin Berry term makes the common angle conjugate to the total z magnetization. Eliminating the hard modes gives, at leading order,', '',
              r'$$\Delta_{\rm PG}^2=C_\phi/\chi_z.$$', '',
              r'Using the classical polar Hessian per magnetic cell $A$ and $w_\alpha=-S\sin\vartheta_\alpha$, the implemented response is $d\boldsymbol\vartheta/dh=A^{-1}w$ and $\chi_z=w^T A^{-1}w/3$. This retains spin length and cell/site normalization. It is independently checked by finite differences of the relaxed magnetization and by the six-dimensional classical equations of motion with weak pinning.', '',
              r'The Y response tilts the two canted spins oppositely and leaves the axial spin fixed. A common polar-angle increment is not its canonical partner. The V response is also strongly nonuniform.', '',
              '## Like-for-like gap comparison', '',
              'Each implementation is evaluated at its own angular minimum. This table uses fitted angular curvature; the separate legacy replay logs execute the original finite-difference formulas. Values are in meV.', '',
              '| Phase | SOC term = 0.010 meV | Current H + response | Archived H + response | Current H + old formula | Archived H + old formula |',
              '|---|---|---:|---:|---:|---:|']
    for phase in ['Y', 'V']:
        for axis in ['PD', 'Gamma']:
            r = select(report, phase, axis, .01)
            c, old = r['current'], r['legacy']
            lines.append(f"| {phase} | {axis} | {c.get('gap_with_susceptibility_meV',float('nan')):.9g} | {old.get('gap_with_susceptibility_meV',float('nan')):.9g} | {c.get('gap_with_old_uniform_theta_and_times_S_meV',float('nan')):.9g} | {old.get('gap_with_old_uniform_theta_and_times_S_meV',float('nan')):.9g} |")
    lines += ['', '## Findings in archived code', '',
              '1. `legacy/scripts/2_U_symmetry_YV.py::_get_angles` and `4_Pseudo_Gap.py::_get_E_cl_and_qm` use a common azimuthal increment. That direction is appropriate for this SOC-induced Y/V gap. It must not be replaced by the different internal zero-field XXZ orbit.', '',
              '2. `4_Pseudo_Gap.py` also increments every polar angle by the same amount to compute the hard curvature. This does not construct the conjugate mode. In the signed Y coordinates used here, its Berry pairing with the global-z orbit vanishes. For V it has the wrong amplitude distribution and normalization.', '',
              '3. The same script hardcodes `spin = 1/2` and returns `sqrt(hessian_det) * spin`. The input energies already contain physical spin factors. Neither multiplying by S nor simply changing this to division by S repairs an unnormalized, incorrect coordinate pair.', '',
              '4. It imports `modules.Tools.analysis_tools.Create_Energy_Function`, which still uses the archived Hamiltonian with the B/B-dagger assembly issue. Fixes in `code-space/lswt` do not change this import. Matrix-level comparisons against independent Cartesian HP coefficients are saved below.', '',
              '5. Negative determinants and energy-evaluation exceptions return 0.0. That conflates an invalid calculation with a physical gap closing. Mixed curvature is set to zero without constructing normal coordinates, and the input azimuth is not automatically minimized within the gap class.', '',
              '6. The azimuthal energy plot divides by an angle-dependent energy range; on the exact-U(1) baseline that range is roundoff. Such normalized curves can visually amplify numerical noise. The figures in this audit retain absolute energy units.', '',
              '## Checks and convergence', '',
              '| Phase | Current H vs independent HP, max matrix error | Archived H vs HP | Old hard curvature: original chart | Same spins, different chart |',
              '|---|---:|---:|---:|---:|']
    for c in report['checks']:
        lines.append(f"| {c['phase']} | {c['current_vs_independent_HP_max']:.3e} | {c['legacy_vs_independent_HP_max']:.3e} | {c['old_stiffness_original']:.9g} | {c['old_stiffness_same_spins_other_coordinates']:.9g} |")
    lines += ['', 'Changing one spin from (theta, phi) to (-theta, phi+pi) leaves the physical configuration and the current zero-point energy unchanged, but changes the archived uniform-theta hard curvature. This is a direct diagnostic of its coordinate dependence.', '',
              'The reciprocal quadrature uses N x N midpoints and six rotated copies, without an endpoint duplication or a k=0 regulator. All positive physical bands and the normal-ordering trace constant enter the vacuum energy. Fits include all harmonics 1 through 18, without imposing Z3/Z6. Very small fitted curvature is marked unresolved against an estimated floating-point/fit floor; this estimate is not a rigorous error bound.', '',
              '| Base mesh N | Phase | SOC = 0.010 meV | Gap (meV) |', '|---:|---|---|---:|']
    for file in files:
        d = json.loads(file.read_text())
        for r in d['scans']:
            if max(r['JPD_meV'], r['JGamma_meV']) == .01:
                gap = r['current'].get('gap_with_susceptibility_meV')
                if gap is not None:
                    axis = 'PD' if r['JPD_meV'] else 'Gamma'
                    lines.append(f"| {r['N']} | {r['phase']} | {axis} | {gap:.12g} |")
    validation_path = out/'curvature-validation.json'
    if validation_path.exists():
        validation = json.loads(validation_path.read_text())
        lines += ['', 'Local five-point curvature independently checks the angular fits. Representative results at N=96 and step 0.04 rad:', '',
                  '| Phase | SOC = 0.010 meV | Gap (meV) | N=48 to 96 relative change | Step 0.04 to 0.02 rad relative change |',
                  '|---|---|---:|---:|---:|']
        for c in validation['comparisons']:
            v = next(v for v in validation['measurements'] if v['phase'] == c['phase'] and
                     v[f"J{c['axis']}_meV"] == .01 and v['N'] == 96 and v['step_rad'] == .04)
            lines.append(f"| {c['phase']} | {c['axis']} | {v['gap_meV']:.9g} | {c['mesh_48_to_96_relative_gap_change']:.3e} | {c['step_004_to_002_relative_gap_change']:.3e} |")
        lines += ['', 'For the very weak Y/Gamma energy modulation, making the derivative step too small amplifies cancellation error; all four step sizes are preserved in `curvature-validation.json`. These convergence differences do not bound higher-order physical corrections.', '']
    lines += ['', '## Interpretation limits', '',
              'This verifies the classical orbit, current quadratic Hamiltonian coefficients, canonical normalization and numerical curvature calculation. It is not an independent full one-loop self-energy calculation, an all-orders prediction for S=1/2, or proof of global phase stability. No finite-temperature gap is calculated. The field-induced internal XXZ branch and the zero-field internal pseudo-Goldstone mode are different modes and are not plotted here.', '',
              'The shaded portions of the gap plots indicate sampled unstable spin-wave backgrounds. Missing weak-Gamma Y points indicate inadequate numerical resolution. Neither is assigned a physical zero gap. The finite-mesh minimum magnon frequency is recorded as a diagnostic and is never used as the pseudo-Goldstone gap.', '',
              'A comparison with the published Figure 4 is conditional on the parameters and available local code. The exact source revision and numerical data used for the published gap curve have not been established.', '',
              '## Sources and reproduction', '',
              '- https://arxiv.org/html/2601.20963v1 — model, Y/V global-z orbit and Figure 4 parameter choices.',
              '- https://arxiv.org/html/1805.00947v2 — leading-order curvature formula and conjugate zero-mode coordinates.',
              '- https://arxiv.org/html/2505.07229v1 — nonlinear soft paths; its internal zero-field XXZ mode is a separate target.',
              '- `examples/pseudo_goldstone_comparison.py` — calculation, checks and original-class replay.',
              '- `examples/pseudo_goldstone_plot.py` — figures and this report.',
              '- `examples/pseudo_goldstone_validation.py` — independent local curvature and N=96 checks.',
              '- `scan-N*-P72.json` — actual arrays, failures, diagnostics and source hashes.', '',
              'Example: `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 python examples/pseudo_goldstone_comparison.py --mesh 48 --couplings 0 0.0025 0.005 0.0075 0.01 0.0125 0.015 0.0175 0.02`.', '']
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text('\n'.join(lines))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=ROOT/'data-space/verification/260912-pseudo-goldstone')
    parser.add_argument('--base-mesh', type=int, default=48)
    args = parser.parse_args()
    report = json.loads((args.directory/f'scan-N{args.base_mesh}-P72.json').read_text())
    plt.rcParams.update({'font.size': 9.5, 'axes.titlesize': 10, 'axes.labelsize': 9,
                         'xtick.labelsize': 8, 'ytick.labelsize': 8,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'svg.fonttype': 'none', 'savefig.facecolor': 'white'})
    orbit_figure(report, args.directory)
    gap_figure(report, args.directory)
    files = sorted(args.directory.glob('scan-N*-P72.json'), key=lambda f: int(f.name.split('-')[1][1:]))
    # Once saved, Markdown is an editable review record. Do not overwrite it
    # when regenerating the numerical figures.
    if not REPORT.exists():
        write_report(report, files, args.directory)
    print(args.directory)


if __name__ == '__main__':
    main()
