"""Export the saved comparison Markdown as a typeset research note.

The Markdown is the editable record. This exporter does not run the physics
calculations or rewrite the Markdown. Quarto resolves semantic equation IDs;
XeLaTeX compiles the resulting standalone TeX. Both must be on PATH.
"""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'docs/nbcp/pseudo-goldstone/comparison-report.md'
DATA = ROOT / 'data-space/verification/260912-pseudo-goldstone'
OUTPUT = ROOT / 'docs/build/nbcp'
HEADER = r"""
\usepackage{xurl}
\usepackage{float}
\usepackage{etoolbox}
\usepackage{needspace}
\usepackage{fancyhdr}
\usepackage{lastpage}
\usepackage{titlesec}
\usepackage{tcolorbox}
\usepackage{fvextra}
\usepackage{enumitem}
\usepackage{caption}
\definecolor{NoteInk}{HTML}{24384A}
\definecolor{NoteAccent}{HTML}{126B78}
\definecolor{NoteMuted}{HTML}{63717B}
\definecolor{NotePale}{HTML}{F1F6F6}
\setmathfont{texgyrepagella-math.otf}[version=bold,FakeBold=1.3]
\AtBeginDocument{\hypersetup{linkcolor=NoteAccent,urlcolor=NoteAccent,citecolor=NoteAccent}}
\color{NoteInk}
\linespread{1.035}
\setlength{\parskip}{5pt plus 1pt minus 1pt}
\setlength{\parindent}{0pt}
\setlength{\emergencystretch}{2em}
\setlength{\headheight}{24pt}
\setlength{\headsep}{8mm}
\setlength{\footskip}{12mm}
\setlength{\textfloatsep}{15pt plus 2pt minus 2pt}
\setlength{\intextsep}{14pt plus 2pt minus 2pt}
\renewcommand{\topfraction}{0.9}
\renewcommand{\bottomfraction}{0.85}
\renewcommand{\textfraction}{0.08}
\renewcommand{\floatpagefraction}{0.85}
\setcounter{secnumdepth}{2}
\setcounter{tocdepth}{1}
\setlist{leftmargin=1.6em,itemsep=4pt,parsep=2pt,topsep=5pt}
\floatplacement{figure}{htbp}
\AtBeginEnvironment{longtable}{\small\setlength{\tabcolsep}{5pt}}
\renewcommand{\arraystretch}{1.2}
\captionsetup{font=small,labelfont={bf,sf,color=NoteAccent},
  labelsep=period,skip=9pt,justification=raggedright,singlelinecheck=false}
\titleformat{\section}{\sffamily\bfseries\Large\color{NoteAccent}}
  {\thesection}{0.7em}{}
\titleformat{\subsection}{\sffamily\bfseries\normalsize\color{NoteInk}}
  {\thesubsection}{0.6em}{}
\titlespacing*{\section}{0pt}{20pt plus 3pt minus 2pt}{9pt}
\titlespacing*{\subsection}{0pt}{13pt plus 2pt minus 1pt}{6pt}
\newtcolorbox{noteresult}{colback=NotePale,colframe=NoteAccent,
  boxrule=0pt,leftrule=2pt,arc=0pt,left=11pt,right=11pt,
  top=9pt,bottom=8pt,before skip=12pt,after skip=13pt}
\makeatletter
\providecommand{\subtitle}[1]{%
  \apptocmd{\@title}{\par\vspace{5pt}{\sffamily\mdseries\normalsize\color{NoteMuted}#1\par}}{}{}}
\AtBeginDocument{\patchcmd{\@title}{gaps in}{gaps\\in}{}{}}
\renewcommand{\maketitle}{%
  \thispagestyle{fancy}
  {\sffamily\fontsize{9}{12}\selectfont\color{NoteAccent}
    \addfontfeatures{LetterSpace=12} LINEAR SPIN WAVE THEORY\par}
  \vspace{9pt}
  {\raggedright\sffamily\bfseries\fontsize{26}{30}\selectfont\color{NoteInk}\@title\par}
  \vspace{10pt}
  {\sffamily\small\color{NoteMuted}Research note\enspace /\enspace REPORT_DATE
    \enspace /\enspace In review\par}
  \vspace{9pt}{\color{NoteAccent}\hrule height 0.6pt}\vspace{15pt}}
\makeatother
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\sffamily\fontsize{8}{10}\selectfont\color{NoteMuted}
  Y / V\enspace |\enspace PSEUDO-GOLDSTONE GAPS}
\fancyhead[R]{\sffamily\fontsize{8}{10}\selectfont\color{NoteMuted}RESEARCH NOTE}
\fancyfoot[L]{\sffamily\fontsize{8}{10}\selectfont\color{NoteMuted}
  In review\enspace /\enspace Leading-order curvature calculation}
\fancyfoot[R]{\sffamily\small\color{NoteMuted}\thepage\enspace /\enspace\pageref*{LastPage}}
\renewcommand{\headrulewidth}{0.3pt}
\renewcommand{\headrule}{\hbox to\headwidth{\color{NoteMuted}\leaders\hrule height \headrulewidth\hfill}}
\AtBeginDocument{%
  \RecustomVerbatimEnvironment{Highlighting}{Verbatim}{
    commandchars=\\\{\},breaklines=true,fontsize=\footnotesize}}
"""
FILTER = r"""
function Code(el)
  if FORMAT:match('latex') then
    return pandoc.RawInline('latex', '{\\small\\texttt{\\nolinkurl{' .. el.text .. '}}}')
  end
end

function Header(el)
  if not FORMAT:match('latex') then return end
  local blocks = pandoc.List()
  if el.classes:includes('newpage') then
    blocks:insert(pandoc.RawBlock('latex', '\\clearpage'))
  end
  if el.classes:includes('appendix') then
    blocks:insert(pandoc.RawBlock('latex', '\\appendix'))
  end
  blocks:insert(el)
  return blocks
end

function Div(el)
  if FORMAT:match('latex') and el.classes:includes('result') then
    el.content:insert(1, pandoc.RawBlock('latex', '\\begin{noteresult}'))
    el.content:insert(pandoc.RawBlock('latex', '\\end{noteresult}'))
    return el.content
  end
  if FORMAT:match('latex') and el.classes:includes('keep-together') then
    el.content:insert(1, pandoc.RawBlock('latex', '\\par\\noindent\\begin{minipage}{\\linewidth}'))
    el.content:insert(pandoc.RawBlock('latex', '\\end{minipage}\\par'))
    return el.content
  end
end

function Table(el)
  if #el.colspecs == 2 then
    el.colspecs = {{pandoc.AlignLeft, 0.34}, {pandoc.AlignLeft, 0.66}}
    return el
  end
end
"""


def run(args, cwd):
    result = subprocess.run(args, cwd=cwd, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stdout[-6000:] + result.stderr[-6000:])
    return result


def main():
    quarto = shutil.which('quarto')
    xelatex = shutil.which('xelatex')
    if not quarto or not xelatex:
        raise RuntimeError('Quarto and XeLaTeX are required.')
    source = SOURCE
    source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    updated = re.search(r'^updated: (\d{4}-\d{2}-\d{2})$', source.read_text(), re.MULTILINE)
    if updated is None:
        raise ValueError('The report must declare its updated date.')
    figures = ['yv-equal-energy-orbits.png', 'yv-pseudo-gap-comparison.png']
    for name in figures:
        if not (DATA / name).is_file():
            raise FileNotFoundError(DATA / name)
    with tempfile.TemporaryDirectory(prefix='lswt-report-') as directory:
        scratch = Path(directory)
        header, lua = scratch / 'header.tex', scratch / 'inline-code.lua'
        header.write_text(HEADER.replace('REPORT_DATE', updated.group(1)))
        lua.write_text(FILTER)
        # Render a scratch copy so Quarto's caches and intermediate files do not
        # become part of the calculation record. The source itself is unchanged.
        source_text = source.read_text()
        for name in figures:
            # Only the scratch input uses local figure names. The authored
            # Markdown links to the saved calculation assets in data-space.
            reference = Path(os.path.relpath(DATA / name, source.parent)).as_posix()
            source_text = source_text.replace(f']({reference})', f']({name})')
            shutil.copy2(DATA / name, scratch / name)
        (scratch / source.name).write_text(source_text)
        settings = {
            'format': {'latex': {
                'documentclass': 'article', 'fontsize': '11pt',
                'papersize': 'a4',
                'geometry': ['left=25mm', 'right=25mm', 'top=25mm', 'bottom=25mm'],
                'mainfont': 'texgyrepagella-regular.otf',
                'mainfontoptions': ['BoldFont=texgyrepagella-bold.otf',
                                    'ItalicFont=texgyrepagella-italic.otf',
                                    'BoldItalicFont=texgyrepagella-bolditalic.otf'],
                'sansfont': 'texgyreheros-regular.otf',
                'sansfontoptions': ['BoldFont=texgyreheros-bold.otf',
                                    'ItalicFont=texgyreheros-italic.otf'],
                'monofont': 'texgyrecursor-regular.otf',
                'monofontoptions': ['BoldFont=texgyrecursor-bold.otf'],
                'mathfont': 'texgyrepagella-math.otf',
                'number-sections': True, 'colorlinks': True,
                'include-in-header': str(header),
            }},
            'filters': [str(lua)],
            'crossref': {'eq-prefix': 'Eq.', 'fig-prefix': 'Fig.'},
            'execute': {'enabled': False},
        }
        # JSON is a YAML subset accepted by Quarto's metadata-file reader.
        metadata = scratch / 'render-settings.yml'
        metadata.write_text(json.dumps(settings, indent=2))
        tex = scratch / 'comparison-report.tex'
        command = [quarto, 'render', source.name, '--to', 'latex',
                   '--metadata-file', str(metadata), '--output', tex.name]
        run(command, scratch)
        # This provenance comment is part of generation, not a second editable
        # copy of the report's semantic content.
        tex.write_text(f'% Generated from {source.relative_to(ROOT)}; edit Markdown.\n'
                       f'% Markdown SHA256: {source_hash}\n' + tex.read_text())
        for _ in range(3):
            run([xelatex, '-interaction=nonstopmode', '-halt-on-error',
                 '-no-shell-escape', '-output-directory', str(scratch), str(tex)], scratch)
        log = (scratch / 'comparison-report.log').read_text(errors='replace')
        OUTPUT.mkdir(parents=True, exist_ok=True)
        for suffix in ['tex', 'pdf']:
            shutil.copy2(scratch / f'comparison-report.{suffix}', OUTPUT)
        for name in figures:
            shutil.copy2(scratch / name, OUTPUT / name)
        provenance = {
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'status': 'in-review; format export does not establish physics acceptance',
            'source': source.relative_to(ROOT).as_posix(),
            'data_directory': DATA.relative_to(ROOT).as_posix(),
            'output_directory': OUTPUT.relative_to(ROOT).as_posix(),
            'source_sha256': source_hash,
            'exporter_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'quarto_version': run([quarto, '--version'], OUTPUT).stdout.strip(),
            'xelatex_version': run([xelatex, '--version'], OUTPUT).stdout.splitlines()[0],
            'outputs_and_assets_sha256': {
                name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest()
                for name in ['comparison-report.tex', 'comparison-report.pdf', *figures]
            },
            'layout_messages': [line for line in log.splitlines()
                                if any(key in line for key in
                                       ('Overfull', 'Underfull', 'Missing character', 'Warning:'))],
        }
        (OUTPUT / 'report-export.json').write_text(json.dumps(provenance, indent=2) + '\n')
    print(OUTPUT / 'comparison-report.tex')
    print(OUTPUT / 'comparison-report.pdf')
    print(json.dumps(provenance['layout_messages']))


if __name__ == '__main__':
    main()
