---
frontmatter-version: 1
title: Clock Anisotropy on the Pure-PD Axis and the Thermal V-State Claim
doc-path: docs/nbcp/pseudo-goldstone
artifact-role: source-grounded research review and derivation
status: in-review
last-edited-by: codex
created: 2026-09-16
updated: 2026-09-16
lang: en
---

# Clock Anisotropy on the Pure-PD Axis and the Thermal V-State Claim

The pure-PD limit has an additional exact spin symmetry that changes the allowed angular anisotropy of the V state. At $J_\Gamma=0$, a common spin rotation by $\pi$ leaves the microscopic Hamiltonian invariant. Together with the threefold operation on the V orbit, this forbids a threefold pinning term and permits sixfold pinning. The saved zero-point-energy scans exhibit precisely this distinction: sixfold modulation for pure PD and threefold modulation for pure $\Gamma$.

This is a qualification of the finite-temperature argument, not a demonstration of a thermal V supersolid. A nonzero zero-temperature pseudo-Goldstone gap is compatible with an intermediate algebraic phase when the clock anisotropy is irrelevant there. Whether that phase occurs in this microscopic model also depends on its stiffness, defects and competing orders.

## The claim being examined

[Park et al., arXiv:2601.20963v1](https://arxiv.org/html/2601.20963v1#S2) use sixfold and threefold clock descriptions for Y and V, respectively, in Eqs. (3) and (4). Their thermal argument permits an intermediate BKT regime for Y and excludes it for V. The preceding symmetry discussion distinguishes PD from $\Gamma$ through a spin-only $\pi$ rotation. The present review asks how the thermal conclusion must be scoped on the exactly $J_\Gamma=0$ axis.

The reference state, exchange conventions, fields and energy normalization are those of the [Y/V curvature note](comparison-report.md). The angular variable $\phi$ is the same physical global-$z$ rotation, with period $2\pi$. The derivation below follows one three-sublattice domain and does not identify the full manifold, including translation domains, with a single clock variable.

## The extra symmetry at zero Gamma coupling

Under $R_z(\pi)$, the spin components transform as

$$
(\hat S^x,\hat S^y,\hat S^z)\longmapsto(-\hat S^x,-\hat S^y,\hat S^z).
$$

The XXZ terms, longitudinal Zeeman term and PD terms contain an even number of transverse spin components. Each $\Gamma$ term contains one transverse component and one longitudinal component. Consequently, rotation of every spin maps the family of Hamiltonians according to

$$
\hat U_\pi\hat H(J_{\rm PD},J_\Gamma)\hat U_\pi^\dagger
=\hat H(J_{\rm PD},-J_\Gamma).
$$

Only at $J_\Gamma=0$ is this a symmetry of the same generic PD Hamiltonian. An effective angular energy or free energy that preserves this exact microscopic symmetry must then satisfy

$$
v(\phi+\pi)=v(\phi).
$$

For the V configuration, the combined lattice-spin threefold operation preserves the equivalent pair of sublattices and shifts the orbit coordinate by $2\pi/3$, up to its sign convention. Thus

$$
v(\phi+2\pi/3)=v(\phi).
$$

Write a real angular potential as

$$
v(\phi)=v_0+\sum_{n\ge1}\bigl[a_n\cos(n\phi)+b_n\sin(n\phi)\bigr].
$$

The first symmetry requires even $n$ and the second requires $n\in3\mathbb Z$. Their intersection is $n\in6\mathbb Z$, so the leading symmetry-allowed potential on the pure-PD V branch is

$$
v_{\rm V}^{\rm PD}(\phi)
=v_0-\lambda_6\cos(6\phi-\delta_6)+\text{higher multiples of six}.
$$

This statement does not require a nonzero $\lambda_6$ at every parameter point. At the representative point below, the sixfold coefficient is nonzero. At generic nonzero $J_\Gamma$, the spin-only $\pi$ symmetry is lost and a term $-\lambda_3\cos(3\phi-\delta_3)$ is allowed. The phase offsets $\delta_p$ specify the origin of $\phi$ and do not change the harmonic order.

## Numerical evidence without a symmetry-constrained fit

The diagnostic reanalyzes the saved $T=0$ energies at $S=1/2$, $J=0.075$ meV and $J_z=0.125$ meV. The fields are $B=0.2$ T for Y and $B=1.4$ T for V. Exactly one SOC coupling is $0.010$ meV in each row. With $M=72$ uniformly spaced angles and $\bar e=M^{-1}\sum_j e_j$, the discrete coefficients are

$$
c_n=\frac{2}{M}\sum_{j=0}^{M-1}(e_j-\bar e)e^{-\mathrm i n\phi_j},
\qquad A_n=|c_n|=\sqrt{a_n^2+b_n^2}.
$$

All sampled harmonics below the Nyquist mode are evaluated. No threefold or sixfold selection rule is imposed. At base mesh $N=48$, the amplitudes are:

| Phase | Nonzero coupling | $A_3$ (meV/spin) | $A_6$ (meV/spin) | Dominant harmonic |
|---|---|---:|---:|---:|
| Y | PD | $7.19\times10^{-19}$ | $1.4367745\times10^{-6}$ | 6 |
| Y | Gamma | $1.93\times10^{-18}$ | $1.6429350\times10^{-12}$ | 6 |
| V | PD | $4.28\times10^{-19}$ | $1.0239780\times10^{-5}$ | 6 |
| V | Gamma | $7.1609759\times10^{-7}$ | $8.9632094\times10^{-11}$ | 3 |

The forbidden threefold amplitudes are at the scale of numerical noise; the exact vanishing follows from symmetry, not from declaring those fitted numbers to be zero. The same dominant harmonic is obtained from the $N=12$ and $N=24$ saved scans. For pure-PD V, the largest sampled difference $|e(\phi+\pi/3)-e(\phi)|$ is $2.35\times10^{-17}$ meV/spin or less at $N=48$. With pure $\Gamma$, that difference reaches $1.4322\times10^{-6}$ meV/spin, whereas the $2\pi/3$ shift remains invariant to numerical precision.

![The V-state zero-point energy along the common global-z orbit. Pure PD produces six minima while pure Gamma produces three. Each panel uses absolute energy differences per physical spin, with its own vertical scale; the curves are not normalized by their angular ranges.](../../../data-space/verification/260916-clock-anisotropy/v-clock-anisotropy.png)

The saved Brillouin-zone quadrature includes rotated momentum copies. To check that the pure-PD result is not solely a consequence of that averaging, an additional calculation uses Cartesian Holstein-Primakoff matrices at 128 fresh, unsymmetrized momenta and $\phi=0.173$ rad. For pure-PD V, the largest matrix difference after $\phi\mapsto\phi+\pi$ is $2.87\times10^{-17}$ meV. The individual exchange matrices obey $R_z(\pi)^\mathsf T\mathsf J R_z(\pi)=\mathsf J$ exactly in floating-point arithmetic. For nonzero $\Gamma$, the corresponding test passes only after also reversing $J_\Gamma$, with a maximum matrix residual below $2.9\times10^{-17}$ meV across the four representative cases.

These checks share the existing bond geometry and state inputs. They support the stated symmetry identities; they are not an independent microscopic-model reconstruction or a finite-temperature calculation. Finite angular sampling can alias higher harmonics, so the table alone is not an all-orders Fourier theorem.

## What the clock RG does and does not imply

Consider a two-dimensional compact phase field with an isotropic long-wavelength stiffness $\rho_s$ and weak $p$-fold pinning. Let $\mathcal T=k_{\rm B}T$ and $K=\rho_s/\mathcal T$. In cutoff units, its Gaussian action plus pinning is

$$
\mathcal S_0=\frac K2\int d^2x\,(\nabla\phi)^2,
\qquad
\delta\mathcal S=-y_p\int d^2x\,\cos(p\phi-\delta_p).
$$

Here $\mathcal S_0$ is a dimensionless action, not the spin length $S$, and $y_p$ is a dimensionless pinning coupling. Along the Gaussian fixed line,

$$
\bigl\langle[\phi(\mathbf r)-\phi(0)]^2\bigr\rangle
=\frac{1}{\pi K}\ln(r/a),
\qquad
x_p=\frac{p^2}{4\pi K}.
$$

The latter follows by averaging $\exp[\mathrm i p(\phi(\mathbf r)-\phi(0))]$ over the Gaussian fluctuations and identifying its decay as $r^{-2x_p}$. A unit vortex has an energy cost $\pi\rho_s\ln(L/a)$ and a positional entropy $2k_{\rm B}\ln(L/a)$. The linearized scaling eigenvalues of the pinning and unit-vortex fugacity $y_v$ therefore give

$$
\frac{dy_p}{d\ell}=\left(2-\frac{p^2}{4\pi K}\right)y_p,
\qquad
\frac{dy_v}{d\ell}=(2-\pi K)y_v.
$$

Both perturbations are irrelevant only in the interval

$$
\frac{2}{\pi}<K<\frac{p^2}{8\pi}.
$$

For $p=3$ the interval is empty. For $p=6$ it is nonempty and can equivalently be written

$$
\frac{2\pi\rho_s}{9}<k_{\rm B}T<\frac{\pi\rho_s}{2}.
$$

These are weak-perturbation conditions near the Gaussian fixed line. The stiffness is the coefficient of the continuum gradient term at the scale where the RG is evaluated, not automatically the microscopic exchange or a coarse-lattice bond coupling. Its temperature dependence, vortex renormalization and the full coupled flow prevent using these inequalities as numerical transition temperatures for NBCP. The derivation assumes integer vortices and a phase-only description within a stable density-ordered background; domain walls, fractional or composite defects and competing states require separate analysis.

The zero-temperature relation $\Delta_{\rm PG}^2=C_\phi/\chi_z$ does not supply this missing stiffness. For a single dominant harmonic, $C_\phi\simeq p^2A_p$ in the per-spin convention. That determines the local pinning curvature, while $\rho_s$ measures the cost of spatial phase gradients. They are different quantities.

## Consequence for the paper and the next calculation

The threefold argument is appropriate for a generic V branch with nonzero $J_\Gamma$ and a nonvanishing threefold coefficient. It does not apply unchanged on the exactly $J_\Gamma=0$ axis. There, the pure-PD V branch has the sixfold selection rule and an intermediate algebraic phase is symmetry-allowed within the stated phase-only assumptions. This is a necessary qualification of the domain of the paper's thermal V-state conclusion; it does not establish that a microscopic V supersolid actually survives at finite temperature.

The next quantitative step is to calculate the spatial phase stiffness of the stable Y/V backgrounds and relate the microscopic pinning amplitudes to a consistently normalized continuum theory. A follow-up near the PD axis should then include both threefold and sixfold pinning to study how small nonzero $J_\Gamma$ cuts off apparent algebraic behavior. Finite-size scaling or a coupled-defect analysis is still needed before assigning a thermal transition or a supersolid phase.

## Evidence and reproduction

- [Clock-anisotropy audit JSON](../../../data-space/verification/260916-clock-anisotropy/clock-anisotropy-audit.json): coefficients at three meshes, fresh matrix checks, input and code hashes, and limitations.
- [Diagnostic script](../../../examples/nbcp_clock_anisotropy_audit.py): rerun from the repository root with `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 python examples/nbcp_clock_anisotropy_audit.py`.
- [Existing scan data](../../../data-space/verification/260912-pseudo-goldstone/): unchanged energy arrays; no full angular scan was rerun for this review.

## References

### Internal Documents

- [Y/V pseudo-Goldstone curvature note](comparison-report.md): physical coordinate, canonical response, normalization and numerical stability limits.
- [NBCP research index](../README.md): research scope and related evidence.

### External Sources

- S. Park, S.-M. Park, Y.-T. Oh, H.-Y. Lee and E.-G. Moon, [Spin-orbit-induced Instability and Finite-Temperature Stabilization of a Triangular-lattice Supersolid](https://arxiv.org/html/2601.20963v1), arXiv:2601.20963v1 (2026). Section II, model-symmetry discussion, Figure 4 and Eqs. (3)-(4) specify the claims reviewed here. The arXiv record checked on 2026-09-16 lists v1.
- J. V. Jose, L. P. Kadanoff, S. Kirkpatrick and D. R. Nelson, [Renormalization, vortices, and symmetry-breaking perturbations in the two-dimensional planar model](https://doi.org/10.1103/PhysRevB.16.1217), Physical Review B 16, 1217 (1977); [erratum](https://doi.org/10.1103/PhysRevB.17.1477), Physical Review B 17, 1477 (1978). The publisher abstract supports the sixfold-anisotropy mechanism; the full article and erratum were not inspected here. The linearized exponents used above are explicitly derived from the Gaussian action and vortex energy-entropy balance.
