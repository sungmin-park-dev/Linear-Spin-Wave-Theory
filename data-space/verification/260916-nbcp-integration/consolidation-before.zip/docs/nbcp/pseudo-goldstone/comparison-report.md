---
frontmatter-version: 1
doc-path: docs/nbcp/pseudo-goldstone
last-edited-by: codex
title: |
  Pseudo-Goldstone gaps  
  in the Y and V states
subtitle: "Equal-energy orbits, canonical response, and a comparison with legacy code"
document-title: "Pseudo-Goldstone gaps in the Y and V states"
artifact-role: internal research note and comparison record
status: in-review
created: 2026-09-12
updated: 2026-09-16
lang: en
---

The spin-orbit-coupling-induced pseudo-Goldstone gap in the three-sublattice Y and V states depends on two ingredients: the quantum energy curvature along a classical equal-energy orbit and the classical response conjugate to that orbit. For the nearest-neighbor model considered here, the soft coordinate is a common laboratory-$z$ rotation. Its relaxed conjugate motion is a nonuniform change of the polar angles, determined by the longitudinal susceptibility. This distinction explains why a uniform polar-angle increment in the archived calculation does not reproduce the leading-order gap.

::: {.result}
**Leading-order relation**

$$
C_\phi=\left.\frac{\partial^2 e_{\rm sw}}{\partial\phi^2}\right|_{\phi_*},
\qquad
\Delta_{\rm PG}=\hbar\omega_{\rm PG}
=\sqrt{\frac{C_\phi}{\chi_z}}.
$$ {#eq-lswt-yv-pg-gap}

Here $e_{\rm sw}$ is the energy per physical spin, $\phi_*$ is its selected angular minimum, and $\chi_z=\partial m_z/\partial h$ is evaluated along the relaxed classical branch. The reduction requires a stable background and finite classical stiffness in the other uniform modes.
:::

### Conventions at a glance {.unnumbered}

| Quantity | Meaning and normalization |
|:---|:---|
| $\phi$, $q=\phi-\phi_*$ | Common physical rotation about laboratory $z$; angles in radians |
| $\boldsymbol\vartheta$ | Signed polar-angle chart for the three sublattices |
| $m_z=(S/3)\sum_\alpha\cos\vartheta_\alpha$ | Magnetization per physical spin, in dimensionless spin units |
| $h=g_z\mu_B B$ | Zeeman energy in $-h\sum_i S_i^z$; measured in meV |
| $A$, $\mathbf w$ | Polar Hessian per three-spin cell; $w_\alpha=-S\sin\vartheta_\alpha$ |
| $C_\phi$, $\chi_z$ | Angular energy curvature per spin; susceptibility in meV$^{-1}$ |

The symbols $e$, $A$, and the sublattice labels $\alpha=A,B,C$ retain the conventions of the comparison data. In particular, $A$ is a classical polar Hessian, not the normal block of a bosonic Hamiltonian. No extra $g_z\mu_B$ or spin-length factor is appended to the gap.

**Reading route.** The classical orbit is specified first; the Berry term and constrained relaxation then determine its canonical partner. The Y and V specializations precede the numerical comparison. Implementation findings, convergence tables, and reproduction details are collected in the appendices.

## Model and equal-energy orbit {#sec-orbit .newpage}

The target is the spin-orbit-coupling (SOC) induced gap of the common global-$z$ orbit in [Park et al. (2026)](https://arxiv.org/html/2601.20963v1). The internal, nonuniform zero-field XXZ mode discussed by [Lin and Shi (2025)](https://arxiv.org/html/2505.07229v1) is a different excitation. That distinction is essential when choosing the deformation used to calculate the curvature.

Only nearest-neighbor bonds are included, with $S=1/2$, $J=0.075$ meV, $J_z=0.125$ meV and $T=0$. The representative fields are $B=0.2$ T in Y and $B=1.4$ T in V, with $g_z=4.645$. The two SOC coefficients are denoted by $J_{PD}$ and $J_\Gamma$.

### Common laboratory rotation

$$
\mathbf S_\alpha(\phi)=R_z(\phi)\mathbf S_\alpha(0)
=S\begin{pmatrix}
\sin\vartheta_\alpha\cos\phi\\
\sin\vartheta_\alpha\sin\phi\\
\cos\vartheta_\alpha
\end{pmatrix},\qquad \alpha=A,B,C.
$$ {#eq-lswt-yv-pg-orbit}

The same lab-frame rotation acts on all three spins. In the signed-polar-angle chart used here, opposite transverse directions are represented by opposite signs of $\vartheta$, with a common azimuth. This is a physical spin rotation, not a rotation of a local transverse basis about a fixed spin.

For the three nearest-neighbor bond orientations, $\sum_d J_d=3\operatorname{diag}(J,J,J_z)$. Each A-B, B-C and C-A pair has all three orientations. Thus PD and Gamma cancel in the classical three-sublattice energy for every $\phi$, while they remain in the finite-momentum spin-wave Hamiltonian. This is an accidental degeneracy when SOC is nonzero. At zero SOC the same orbit is an exact U(1) symmetry and this particular gap is exactly zero.

Equal energy on this restricted manifold does not prove a global classical minimum; the finite-momentum Hessians are separately checked for stability. Unstable angular backgrounds are rejected rather than shifted.

![Common-z spin trajectories (in units of $S$), classical energy and zero-point energy. The classical modulation is at roundoff level. The right column uses different absolute energy scales for Y and V; both show $J_\Gamma=0.010$ meV and $J_{PD}=0$.](../../../data-space/verification/260912-pseudo-goldstone/yv-equal-energy-orbits.png){#fig-yv-orbit fig-pos="htbp"}

## Canonical response and the gap {#sec-canonical}

The curvature relation is specialized here to the common laboratory-$z$ orbit. The following Y/V expressions are the derivation used in this comparison, rather than formulas quoted directly from the cited papers.

### Berry term and magnetization
Write $q=\phi-\phi_*$ and let $\mathbf x=\delta\boldsymbol\vartheta$ denote polar displacements from a stationary coplanar state. The spin Berry term, in a gauge differing from other common gauges by a total derivative, is $L_B=\hbar S\sum_i\cos\vartheta_i\,\dot\phi_i$. A common azimuth therefore couples to the total z magnetization. Per physical spin,

$$
\ell_B=\hbar m_z\dot q,
\qquad
p\equiv\delta m_z=\frac{\mathbf w^{\mathsf T}\mathbf x}{3},
\qquad
w_\alpha=-S\sin\vartheta_\alpha.
$$ {#eq-lswt-yv-pg-berry}

The constant equilibrium term $\hbar m_{z,0}\dot q$ does not affect the local equations of motion. The physical spin tangent of the global-z orbit is $\partial_q\mathbf S_\alpha=S\sin\vartheta_\alpha\,\mathbf e_{\phi,\alpha}$. Thus a common azimuth does not produce equal local transverse displacements. In the Y state the axial spin has zero tangent on this orbit. This statement remains regular in Cartesian tangent coordinates even though its individual azimuth is undefined at the pole.

### Relaxation at fixed magnetization

For the common-azimuth states, the classical energy per magnetic cell is

$$
E_{\rm cl}^{\rm cell}
=3S^2\sum_{(\alpha\beta)=(AB),(BC),(CA)}
\left[J\sin\vartheta_\alpha\sin\vartheta_\beta
+J_z\cos\vartheta_\alpha\cos\vartheta_\beta\right]
-hS\sum_\alpha\cos\vartheta_\alpha.
$$ {#eq-lswt-yv-pg-classical-energy}



The SOC cancellation on this uniform three-sublattice manifold is why the same expression supplies the classical hard stiffness. Assume that $A$ is positive definite and that the common-z direction is the only soft uniform mode. At fixed $p=\delta m_z$, the classical energy cost is obtained by minimizing $\mathbf x^{\mathsf T}A\mathbf x/6$ subject to $\mathbf w^{\mathsf T}\mathbf x=3p$. The stationary solution is

$$
\mathbf x_*(p)
=\frac{3A^{-1}\mathbf w}{\mathbf w^{\mathsf T}A^{-1}\mathbf w}\,p,
\qquad
\delta e_{\rm cl,min}=
\frac{3p^2}{2\mathbf w^{\mathsf T}A^{-1}\mathbf w}
=\frac{p^2}{2\chi_z}.
$$ {#eq-lswt-yv-pg-fixed-magnetization}

The same response follows without a dynamical assumption by differentiating the classical stationarity equation with respect to the Zeeman energy $h$:

$$
A\frac{d\boldsymbol\vartheta}{dh}=\mathbf w,
\qquad
\chi_z=\frac{1}{3}\mathbf w^{\mathsf T}A^{-1}\mathbf w,
\qquad
\frac{d\boldsymbol\vartheta}{dm_z}=\frac{A^{-1}\mathbf w}{\chi_z}.
$$ {#eq-lswt-yv-pg-susceptibility}

::: {.keep-together}
The quadratic effective energy per spin near the selected angle is

$$
\delta e=\frac{(\delta m_z)^2}{2\chi_z}
+\frac{C_\phi}{2}(\delta\phi)^2.
$$
:::

With the Berry term $\hbar\,\delta m_z\,\partial_t\delta\phi$, the linear equations give $\hbar^2\partial_t^2\delta\phi=-(C_\phi/\chi_z)\delta\phi$, yielding the gap in @eq-lswt-yv-pg-gap. The total Lagrangian contains the common factor $N_{\rm site}$, which cancels from the equations of motion.

### Trial directions and their stiffness

For $\mathbf x=\mathbf u\,\xi$, with a fixed trial direction $\mathbf u$, define

$$
b_{\mathbf u}=\frac{\mathbf w^{\mathsf T}\mathbf u}{3},
\qquad
\kappa_{\mathbf u}=\frac{\mathbf u^{\mathsf T}A\mathbf u}{3}.
$$ {#eq-lswt-yv-pg-trial-coordinates}

Here $A$ is the classical polar Hessian per three-spin magnetic cell, not a particle block of the spin-wave matrix. The restricted Berry term is $\hbar b_{\mathbf u}\xi\dot q$. If $b_{\mathbf u}=0$, these two coordinates do not form a canonical pair. If it is nonzero, $p_{\mathbf u}=b_{\mathbf u}\xi$ is a canonical momentum on this restricted surface, whose trial gap is

$$
\Delta_{\mathbf u}^{\,2}
=\frac{C_\phi\kappa_{\mathbf u}}{b_{\mathbf u}^{2}}.
$$ {#eq-lswt-yv-pg-trial-gap}

This is a prediction of the restricted two-coordinate model, not automatically a normal-mode frequency of the full spin system. Reversing the convention for $\xi$ or the orientation of the Berry two-form changes the sign of $b_{\mathbf u}$ but not this expression.

The condition for a trial direction to give the same leading result is stronger than $b_{\mathbf u}\ne0$. The Cauchy-Schwarz inequality in the positive $A$ metric gives

$$
(\mathbf w^{\mathsf T}\mathbf u)^2
\le (\mathbf w^{\mathsf T}A^{-1}\mathbf w)
   (\mathbf u^{\mathsf T}A\mathbf u),
\qquad
\frac{\kappa_{\mathbf u}}{b_{\mathbf u}^{2}}
\ge\frac{1}{\chi_z}.
$$ {#eq-lswt-yv-pg-stiffness-bound}

Equality holds precisely when $\mathbf u$ is proportional to $A^{-1}\mathbf w$. A correctly Berry-normalized but unrelaxed trial direction therefore overestimates the stiffness of this leading two-coordinate reduction. The bound concerns the restricted classical reduction, not an error bound on the full quantum spectrum.

## Y and V states {#sec-states}

### Y: opposite tilts of the canted spins

Use the signed chart $\boldsymbol\vartheta=(t,-t,\pi)$, with

$$
\cos t=\frac{h+3SJ_z}{3S(J+J_z)}.
$$ {#eq-lswt-yv-pg-y-state}

The old choice $\mathbf u=(1,1,1)^{\mathsf T}$ has $b_{\mathbf u}=-(S/3)(\sin t-\sin t+0)=0$. It leaves $m_z$ unchanged to first order. A nonzero classical curvature along it cannot be combined with the global-z curvature to obtain a canonical oscillation frequency.

::: {.keep-together}
Differentiating the Y branch instead gives

$$
\frac{d\boldsymbol\vartheta}{dh}
=\frac{(-1,1,0)^{\mathsf T}}{3S(J+J_z)\sin t},
\qquad
\chi_z^{Y}=\frac{2}{9(J+J_z)}.
$$ {#eq-lswt-yv-pg-y-response}
:::

For the admissible direction $\mathbf u_Y=(-1,1,0)^{\mathsf T}$, its Berry coefficient and stiffness are

$$
b_Y=\frac{2S\sin t}{3},
\qquad
\kappa_Y=2S^2(J+J_z)\sin^2t,
\qquad
\Delta_Y^2=\frac{9(J+J_z)}{2}C_\phi.
$$ {#eq-lswt-yv-pg-y-gap}

At $B=0.2$ T, $d\boldsymbol\vartheta/dh=(-5.6088836,5.6088836,0)$ meV$^{-1}$. In physical terms the two canted spins tilt oppositely and the axial spin stays fixed to first order. This is not a common polar increment. These formulas are local to the stable Y branch; approaching an additional soft mode or a collinear endpoint requires a new analysis.

### V: nonuniform response of the three spins

Write $\boldsymbol\vartheta=(t,t,v)$. Exchange symmetry between A and B implies a relaxed response $(t',t',v')$, where primes mean derivatives with respect to $h$. Define $a=A_{AA}+A_{AB}$, $b=A_{AC}$, $c=A_{CC}$ and $D=ac-2b^2$. Then

$$
\begin{pmatrix}a&b\\2b&c\end{pmatrix}
\begin{pmatrix}t'\\v'\end{pmatrix}
=-S\begin{pmatrix}\sin t\\\sin v\end{pmatrix},
$$ {#eq-lswt-yv-pg-v-system}

so that

$$
t'=-\frac{S(c\sin t-b\sin v)}{D},
\qquad
v'=-\frac{S(a\sin v-2b\sin t)}{D},
$$

$$
\chi_z^{V}=
\frac{S^2}{3D}
\left(2c\sin^2t-4b\sin t\sin v+a\sin^2v\right).
$$ {#eq-lswt-yv-pg-v-response}

The asymmetric appearance of the reduced $2\times2$ matrix reflects the two equal A/B displacements; it is not itself the Hessian in orthonormal reduced coordinates. At $B=1.4$ T the response is $(-0.2057662,-0.2057662,9.7220817)$ meV$^{-1}$ and $\chi_z^{V}=1.5509777351$ meV$^{-1}$ per spin.

For the uniform trial direction, $b_{\mathbf 1}=0.0240478049$ and $\kappa_{\mathbf 1}=0.0850517106$ meV per spin. Berry normalization is possible, but its restricted susceptibility is only $b_{\mathbf 1}^2/\kappa_{\mathbf 1}=0.0067993567$ meV$^{-1}$. Consequently its Berry-corrected trial gap would be 15.1032 times the relaxed result in the weak-pinning limit. This is not the archived code's gap ratio: that code also uses a different final normalization. The point is that fixing only that normalization still leaves the wrong hard-mode direction.

### Representative stationary states

| Phase | Sublattice | $\vartheta_\alpha$ (rad) | $d\vartheta_\alpha/dh$ (1/meV) |
|---|---|---:|---:|
| Y | A | 0.636389179 | -5.6088836 |
| Y | B | -0.636389179 | 5.6088836 |
| Y | C | 3.141592654 | 0.0 |
| V | A | 0.409364861 | -0.2057662 |
| V | B | 0.409364861 | -0.2057662 |
| V | C | -1.223629194 | 9.7220817 |

The susceptibilities per spin are $\chi_z^{Y}=1.11111111111$ meV$^{-1}$ and $\chi_z^{V}=1.55097773512$ meV$^{-1}$.

## Numerical comparison {#sec-results}

Each implementation is evaluated at its own angular minimum. This table uses fitted angular curvature; the separate legacy replay logs execute the original finite-difference formulas. Values are in meV.

| Phase | SOC | Current/resp. | Archive/resp. | Current/old | Archive/old |
|---|---|---:|---:|---:|---:|
| Y | PD | 0.00686217 | 0.0323672 | 0.000519921 | 0.00245234 |
| Y | Gamma | $7.2960\times10^{-6}$ | $3.4602\times10^{-6}$ | $5.5279\times10^{-7}$ | $2.6217\times10^{-7}$ |
| V | PD | 0.0156468 | 0.0259926 | 0.00284145 | 0.00472023 |
| V | Gamma | 0.00203898 | 0.00111472 | 0.000370278 | 0.000202433 |

The indicated SOC coefficient is 0.010 meV and the other is zero. Current/Archive identifies the quadratic Hamiltonian; resp./old identifies the susceptibility reduction or the archived uniform-theta formula. The base reciprocal mesh is $N=48$. Full-precision values remain in `scan-N48-P72.json`.

![Pseudo-Goldstone gap versus each SOC coefficient. Blue: current Hamiltonian and canonical response. Gray: current Hamiltonian and old formula. Orange: archived Hamiltonian and old formula. Shading denotes instability detected in the sampled current-Hamiltonian backgrounds; a physical gap is not assigned there.](../../../data-space/verification/260912-pseudo-goldstone/yv-pseudo-gap-comparison.png){#fig-yv-gap fig-pos="htbp"}

### Cross-checks of the canonical response

The canonical response is cross-checked in both representative states without recomputing the zero-point-energy curves. Explicit Y/V formulas agree with the full $A^{-1}\mathbf w$ response. Differentiating independently relaxed field states at $\delta h=10^{-5}$ meV gives relative tangent errors below $8.0\times10^{-9}$. Nonlinear minimization at fixed magnetization approaches the derived tangent and energy cost as the displacement decreases.

For all eight sign charts in each phase, a finite-difference Hessian of the actual Cartesian bond energy agrees with the transformed analytic Hessian within $1.8\times10^{-9}$ meV; the relative susceptibility change is below $2.1\times10^{-8}$. The six-dimensional classical tangent dynamics with a weak pinning potential reproduces both the gap coefficient and the polar mode profile. Across pinning curvatures $10^{-7}$ and $10^{-9}$ meV per cell, relative frequency and mode-profile errors are below $7.3\times10^{-8}$ and $2.6\times10^{-7}$, respectively.

These checks support the local classical reduction and its normalization. They do not replace human physics review or provide an independent one-loop self-energy calculation. Several checks share the same classical energy or Hessian; their agreement is a consistency check, not a wholly independent microscopic calculation.

## Approximation and interpretation {#sec-interpretation}

### Curvature order and coordinate conventions

In [arXiv:1805.00947, Eqs. (7)-(9)](https://arxiv.org/html/1805.00947v2), the simple illustration uses equally weighted local transverse coordinates. Its prefactor $1/S$ belongs to that coordinate normalization. Here the physical global azimuth has sublattice weights $\sin\vartheta_\alpha$, so one must compute the Berry coefficient or use the magnetization coordinate directly.

The leading type-I calculation does not require a quantum mixed curvature to be identically zero. The classical energy is independent of the common azimuth, so its mixed curvature vanishes. With the usual expansion at fixed $h/S$, the hard classical curvature is $O(S^2)$ and the quantum soft and mixed curvatures are $O(S)$. The square of the quantum mixed curvature is therefore subleading in the determinant relative to the product of the classical hard and quantum soft curvatures. Near additional soft directions that ordering can fail. Thus setting the mixed term to zero is consistent with the present leading-order reduction; it is not a separately demonstrated leading-order error in the archived result.

The coordinate-relabeling check also needs a precise interpretation. Under $\vartheta_\alpha\mapsto-\vartheta_\alpha$, $\phi_\alpha\mapsto\phi_\alpha+\pi$ for selected sublattices, let $D_s$ be the diagonal sign matrix. The same physical response transforms as $A\mapsto D_sAD_s$, $\mathbf w\mapsto D_s\mathbf w$ and $\mathbf x_*\mapsto D_s\mathbf x_*$, leaving $\chi_z$ invariant. Reusing the numerical vector $(1,1,1)$ in the new chart generally chooses a different physical deformation. The old hard-curvature change diagnoses an unspecified deformation rule, not a failure of the classical energy's coordinate invariance.

### Limits of the comparison

This verifies the classical orbit, current quadratic Hamiltonian coefficients, canonical normalization and numerical curvature calculation. It is not an independent full one-loop self-energy calculation, an all-orders prediction for S=1/2, or proof of global phase stability. No finite-temperature gap is calculated. The field-induced internal XXZ branch and the zero-field internal pseudo-Goldstone mode are different modes and are not plotted here.

The shaded portions of the gap plots indicate sampled unstable spin-wave backgrounds. Missing weak-Gamma Y points indicate inadequate numerical resolution. Neither is assigned a physical zero gap. The finite-mesh minimum magnon frequency is recorded as a diagnostic and is never used as the pseudo-Goldstone gap.

A comparison with the published Figure 4 is conditional on the parameters and available local code. The exact source revision and numerical data used for the published gap curve have not been established.

## References {.unnumbered}

1. Seongjun Park, Sung-Min Park, Yun-Tak Oh, Hyun-Yong Lee, and Eun-Gook Moon, *Spin-orbit-induced Instability and Finite-Temperature Stabilization of a Triangular-lattice Supersolid*, [arXiv:2601.20963v1](https://arxiv.org/abs/2601.20963v1) (2026). Source for the model, common-$z$ orbit, and Figure 4 parameter choices.

2. Jeffrey G. Rau, Paul A. McClarty, and Roderich Moessner, *Pseudo-Goldstone gaps and order-by-quantum-disorder in frustrated magnets*, [Physical Review Letters **121**, 237201](https://doi.org/10.1103/PhysRevLett.121.237201) (2018); [arXiv:1805.00947v2](https://arxiv.org/abs/1805.00947v2). Source for the leading-order curvature formula and conjugate zero-mode coordinates. The susceptibility reduction here records its application to the common-$z$ mode.

3. Xiyue Lin and Tao Shi, *Pseudo-Goldstone Modes at Finite Temperature*, [arXiv:2505.07229v1](https://arxiv.org/abs/2505.07229v1) (2025). Reference for nonlinear soft paths; the internal zero-field XXZ mode discussed there is a separate target.

## Legacy implementation findings {#sec-legacy .appendix .newpage}

1. `legacy/scripts/2_U_symmetry_YV.py::_get_angles` and `4_Pseudo_Gap.py::_get_E_cl_and_qm` use a common azimuthal increment. That direction is appropriate for this SOC-induced Y/V gap. It must not be replaced by the different internal zero-field XXZ orbit.

2. `4_Pseudo_Gap.py` also increments every polar angle by the same amount to compute the hard curvature. In the signed Y coordinates used here, its Berry pairing with the global-z orbit vanishes. In V this pair can be Berry-normalized, but its amplitude distribution is not the relaxed low-energy response. The detailed check above distinguishes these two failures.

3. The same script hardcodes `spin = 1/2` and returns `sqrt(hessian_det) * spin`. The input energies already contain physical spin factors. Neither multiplying by S nor simply changing this to division by S repairs an unnormalized, incorrect coordinate pair.

4. It imports `modules.Tools.analysis_tools.Create_Energy_Function`, which still uses the archived Hamiltonian with the B/B-dagger assembly issue. Fixes in `code-space/lswt` do not change this import. Matrix-level comparisons against independent Cartesian HP coefficients are saved below.

5. Negative determinants and energy-evaluation exceptions return 0.0. That conflates an invalid calculation with a physical gap closing. The input azimuth is not automatically minimized within the gap class. The zero mixed-curvature assignment is consistent with the leading type-I approximation under the conditions derived above; it is not a separately demonstrated source of the leading discrepancy.

6. The azimuthal energy plot divides by an angle-dependent energy range; on the exact-U(1) baseline that range is roundoff. Such normalized curves can visually amplify numerical noise. The figures in this audit retain absolute energy units.

Code locations in `legacy/scripts/4_Pseudo_Gap.py`: the archived energy-factory import is on line 7, uniform polar/azimuthal offsets on lines 55-58, exception-to-zero handling on lines 117-119, mixed-curvature assignment on line 135, and determinant/spin-factor handling on lines 149-157. These locators refer to the source hashes saved with the scans.

### Matrix and coordinate checks

The matrix comparison uses independent Cartesian Holstein-Primakoff (HP) coefficients at $J_{PD}=J_\Gamma=0.005$ meV. Matrix errors are in meV; the two hard-curvature columns are in meV per spin.

| Phase | Current H error | Archive H error | Original chart | Equivalent chart |
|---|---:|---:|---:|---:|
| Y | $2.784\times10^{-17}$ | $1.536\times10^{-2}$ | 0.0206658746 | 0.0766217798 |
| V | $4.164\times10^{-17}$ | $2.017\times10^{-2}$ | 0.0850517129 | 0.0255063026 |

Changing one spin from (theta, phi) to (-theta, phi+pi) leaves the physical configuration and the current zero-point energy unchanged, but reapplying the archived uniform-theta rule selects a different physical perturbation and hence a different hard curvature. The relaxed susceptibility is invariant, as checked in the detailed derivation above.

## Numerical convergence {#sec-convergence .newpage}

The reciprocal quadrature uses N x N midpoints and six rotated copies, without an endpoint duplication or a k=0 regulator. All positive physical bands and the normal-ordering trace constant enter the vacuum energy. Fits include all harmonics 1 through 18, without imposing Z3/Z6. Very small fitted curvature is marked unresolved against an estimated floating-point/fit floor; this estimate is not a rigorous error bound.

| Base mesh N | Phase | SOC = 0.010 meV | Gap (meV) |
|---:|---|---|---:|
| 12 | Y | PD | 0.0068587113552 |
| 12 | Y | Gamma | $7.29595989041\times10^{-6}$ |
| 12 | V | PD | 0.0156410420112 |
| 12 | V | Gamma | 0.00203895133135 |
| 24 | Y | PD | 0.00686145193025 |
| 24 | Y | Gamma | $7.29600055943\times10^{-6}$ |
| 24 | V | PD | 0.0156460286068 |
| 24 | V | Gamma | 0.00203898155653 |
| 48 | Y | PD | 0.0068621739178 |
| 48 | Y | Gamma | $7.2959923841\times10^{-6}$ |
| 48 | V | PD | 0.0156468152768 |
| 48 | V | Gamma | 0.00203898166782 |

Local five-point curvature independently checks the angular fits. Representative results at N=96 and step 0.04 rad:

| Phase | SOC | Gap (meV) | Mesh change | Step change |
|---|---|---:|---:|---:|
| Y | PD | 0.00686213408 | $1.524\times10^{-5}$ | $2.009\times10^{-5}$ |
| Y | Gamma | $7.29575296\times10^{-6}$ | $-2.291\times10^{-5}$ | $9.395\times10^{-5}$ |
| V | PD | 0.0156467362 | $8.114\times10^{-6}$ | $2.554\times10^{-5}$ |
| V | Gamma | 0.00203897924 | $-3.107\times10^{-8}$ | $1.087\times10^{-6}$ |

Mesh change means $N=48\to96$ at a fixed step of 0.04 rad; step change means $0.04\to0.02$ rad at $N=96$. The entries are relative changes, not percentages. Their absolute values are below 0.01% at these four representative points. The existing Hamiltonian-pairing regression suite also passed all eight tests during the calculation session.

For the very weak Y/Gamma energy modulation, making the derivative step too small amplifies cancellation error; all four step sizes are preserved in `curvature-validation.json`. These convergence differences do not bound higher-order physical corrections.

## Reproduction and provenance {#sec-reproduction .newpage}

- `examples/pseudo_goldstone_comparison.py`: calculation, checks and original-class replay.
- `examples/pseudo_goldstone_plot.py`: figures and the initial numerical report. An existing Markdown record is preserved when figures are regenerated.
- `examples/pseudo_goldstone_validation.py`: independent local curvature and $N=96$ checks.
- `examples/pseudo_goldstone_conjugate_mode.py`: explicit Y/V partner, constrained relaxation, coordinate invariance and weak-pinning dynamics checks.
- `examples/pseudo_goldstone_export.py`: Markdown-to-TeX/PDF export.
- `scan-N*-P72.json`: actual arrays, failures, diagnostics and source hashes.
- `curvature-validation.json`: finite-difference and mesh checks.
- `conjugate-mode-validation-260915.json`: the 2026-09-15 canonical-partner verification and source hashes.
- `legacy-replay-*.txt`: unchanged legacy gap class executed with the matched inputs.

Run the scan from the repository root:

```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 \
  python examples/pseudo_goldstone_comparison.py --mesh 48 \
  --couplings 0 0.0025 0.005 0.0075 0.01 0.0125 0.015 0.0175 0.02
```

To regenerate TeX and its PDF preview from this Markdown:

```bash
python examples/pseudo_goldstone_export.py
```

The editable note is stored in `docs/nbcp/pseudo-goldstone/`; calculation data and original figures remain in `data-space/verification/260912-pseudo-goldstone/`. The exporter requires Quarto and XeLaTeX and writes TeX, PDF, two PNG copies and `report-export.json` to `docs/build/nbcp/`. Keep those PNG copies beside the TeX when compiling or moving the output.

### Scope and revision record

The numerical comparison was recorded on 2026-09-12, the explicit canonical-mode derivation and cross-checks on 2026-09-15, and the research-note layout on 2026-09-16. This Markdown is the editable internal record; TeX and PDF are generated from it. The note remains in review and is not an accepted theory document or a publication-ready result. The production package and archived scripts were not edited as part of this comparison.

The original gap script defaults to $J=0.076$ meV and $h=0.05$ meV. The comparisons instead supply the same paper parameters and states to both implementations. An earlier discussion of the internal XXZ orbit did not invalidate the common-$z$ orbit used by the archived SOC-induced Y/V calculation.

The scan field `old_pair_Berry_coefficient_per_spin` records $+(S/3)\sum_\alpha\sin\vartheta_\alpha$, opposite to the sign convention used for $b_{\mathbf u}$ in the derivation. The gap depends on its square. The canonical-response evidence and source hashes are preserved in `conjugate-mode-validation-260915.json`.
