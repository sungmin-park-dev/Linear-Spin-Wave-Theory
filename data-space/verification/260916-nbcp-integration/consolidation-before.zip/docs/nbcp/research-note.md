---
frontmatter-version: 1
title: "NBCP: phases and spin supersolidity"
doc-path: docs/nbcp
artifact-role: integrated research note
status: in-review
last-edited-by: codex
created: 2026-09-16
updated: 2026-09-16
date: 2026-09-16
date-format: "D MMMM YYYY"
lang: en
---

$\mathrm{Na_2BaCo(PO_4)_2}$ (NBCP) provides a setting in which a magnetic field, easy-axis exchange and bond-dependent interactions compete on a triangular lattice. The central question is whether the Y and V magnetic orders retain the phase coherence required for spin supersolidity when spin-orbit coupling removes exact spin-rotation symmetry. Answering it requires three distinct steps: specifying the microscopic model, establishing the stability of a magnetic state, and determining its long-wavelength phase dynamics.

The material and classical analysis below develop the original Overleaf research notes. The supersolidity discussion incorporates the subsequent local curvature and clock-anisotropy calculations. Detailed pseudo-Goldstone derivations, numerical comparisons and convergence evidence are collected in Appendix A. All results remain subject to physics review; a stable local branch is not by itself a complete phase diagram.

# NBCP and its effective spin model {#sec-nbcp-introduction}

## Magnetic degrees of freedom and the two-dimensional approximation

The Co ions form triangular magnetic layers. Crystal-field effects and atomic spin-orbit coupling produce a low-energy effective spin-$1/2$ doublet; higher multiplets lie approximately 71 meV above it. A dominant in-plane nearest-neighbor model is motivated by the exchange paths and weaker interlayer coupling. These are the material assumptions used in [Gao et al. (2022)](https://doi.org/10.1038/s41535-022-00500-3), rather than a claim that every further-neighbor or interlayer interaction vanishes exactly.

Atomic spin-orbit coupling, which helps create the effective doublet, must be distinguished from the coefficients of the residual bond-dependent exchanges. A small fitted $J_{\rm PD}$ or $J_\Gamma$ does not imply that the atomic spin-orbit interaction is absent. In this note, “zero SOC” is shorthand for the exchange-model limit $J_{\rm PD}=J_\Gamma=0$.

We use $z\parallel c$ and $x$ along one nearest-neighbor bond. The external field is $B\parallel z$, and $h=g_z\mu_B B$ is its Zeeman energy. Spin operators are dimensionless, with eigenvalues measured in units of $\hbar$; exchange constants, $h$, and excitation gaps are expressed in meV. Energies denoted by $e$ are per physical spin.

## Symmetry-constrained nearest-neighbor exchange

For one unoriented bond counted once, write $\hat H_{ij}=\hat{\mathbf S}_i^{\mathsf T}\mathsf J_{ij}\hat{\mathbf S}_j$. Bond-centered inversion exchanges $i$ and $j$. Spin is an axial vector, so its components do not change sign under spatial inversion. Invariance therefore requires $\mathsf J_{ij}=\mathsf J_{ij}^{\mathsf T}$. A twofold rotation about the reference $x$ bond has spin-space matrix $\operatorname{diag}(1,-1,-1)$ and forbids its $xy$ and $xz$ entries. The remaining four parameters give

$$
\mathsf J_0=
\begin{pmatrix}
J+2J_{\rm PD}&0&0\\
0&J-2J_{\rm PD}&J_\Gamma\\
0&J_\Gamma&J_z
\end{pmatrix}.
$$ {#eq-nbcp-reference-bond}

Let $R_z(\beta)$ be the active Cartesian rotation about $z$. Rotating the bond and both spins gives $\mathsf J_\beta=R_z(\beta)\mathsf J_0R_z(\beta)^{\mathsf T}$. Its transverse anisotropy contains $\cos 2\beta$ and $\sin 2\beta$. Only for the three bond phases $\varphi_d=0,\pm2\pi/3$ can one use $\cos2\varphi_d=\cos\varphi_d$ and $\sin2\varphi_d=-\sin\varphi_d$, obtaining

$$
\mathsf J_d=
\begin{pmatrix}
J+2J_{\rm PD}\cos\varphi_d&-2J_{\rm PD}\sin\varphi_d&-J_\Gamma\sin\varphi_d\\
-2J_{\rm PD}\sin\varphi_d&J-2J_{\rm PD}\cos\varphi_d&J_\Gamma\cos\varphi_d\\
-J_\Gamma\sin\varphi_d&J_\Gamma\cos\varphi_d&J_z
\end{pmatrix}.
$$ {#eq-nbcp-bond-matrix}

The microscopic Hamiltonian is consequently

$$
\hat H=\sum_{\langle ij\rangle}\hat{\mathbf S}_i^{\mathsf T}
\mathsf J_{d(ij)}\hat{\mathbf S}_j-h\sum_i\hat S_i^z.
$$ {#eq-nbcp-model}

The bond phase $\varphi_d$ labels a fixed exchange tensor. The collective angle $\phi$ introduced below rotates the spins while keeping these tensors fixed. They must not be varied together when evaluating the order-by-disorder energy.

With $\hat S^\pm=\hat S^x\pm i\hat S^y$, the transverse XXZ interaction is $J(\hat S_i^+\hat S_j^-+\hat S_i^-\hat S_j^+)/2$. Thus a convention with coefficient $J_\pm$ multiplying that entire bracket has $J=2J_\pm$, not $J=J_\pm$. The original notes contain both identifications; the Cartesian matrix fixes the convention used here.

## Parameter sets and the scope of the calculation

The original notes contain several parameter sets with different origins. They should remain separate when comparing a field quoted in tesla with an exchange or field quoted in meV.

| Parameter set | $J$ | $J_z$ | $g_z$ |
|:---|---:|---:|---:|
| Thermodynamic fit, Gao et al. | $0.88\,k_B\mathrm{K}$ | $1.48\,k_B\mathrm{K}$ | 4.89 |
| Older Overleaf phase calculations | 0.076 meV | 0.125 meV | 4.645 |
| Current Y/V gap comparison | 0.075 meV | 0.125 meV | 4.645 |

The thermodynamic values are reported in [Gao et al.](https://doi.org/10.1038/s41535-022-00500-3); the last row follows the Figure 4 parameters of [Park et al., arXiv:2601.20963v1](https://arxiv.org/html/2601.20963v1). The middle row records the historical local convention, not a new fit. The present calculation uses $S=1/2$, nearest-neighbor bonds and a single layer. The earlier next-nearest-neighbor draft is not included: its axis and angular conventions require further review.

# Phase analysis {#sec-nbcp-phases .newpage}

## Three-sublattice classical energy

Let $\mathbf n_\alpha=\mathbf S_\alpha/S$, with $\alpha=A,B,C$, specify a uniform three-sublattice configuration. Each pair of sublattices is connected by all three bond orientations. Since $\sum_d\mathsf J_d=3\operatorname{diag}(J,J,J_z)$, its classical energy per physical spin reduces to

$$
e_{\rm cl}=S^2\sum_{(\alpha\beta)=(AB),(BC),(CA)}
\left[J\sin\vartheta_\alpha\sin\vartheta_\beta
\cos(\phi_\alpha-\phi_\beta)
+J_z\cos\vartheta_\alpha\cos\vartheta_\beta\right]
-\frac{hS}{3}\sum_\alpha\cos\vartheta_\alpha.
$$ {#eq-nbcp-three-energy}

Here $\vartheta$ may be signed, with $\mathbf n=(\sin\vartheta\cos\phi,\sin\vartheta\sin\phi,\cos\vartheta)$. Negative $\vartheta$ is a coordinate choice, equivalent to a positive polar angle and an azimuth shifted by $\pi$.

The SOC contributions cancel in this restricted classical energy. They do not disappear from the operator Hamiltonian, from finite-momentum fluctuations, or from states with other magnetic unit cells. In particular, the cancellation does not establish SOC-independent global phase boundaries.

## Y, UUD, V and the polarized state

At common azimuth $\phi=0$, the following signed-angle definitions fix the states independently of historical names:

| State | $(\vartheta_A,\vartheta_B,\vartheta_C)$ | Characteristic structure |
|:---|:---|:---|
| Y | $(t,-t,\pi)$ | Opposite transverse components; one spin antiparallel to the field |
| UUD | $(0,0,\pi)$ | Two up spins and one down spin; $m_z=S/3$ |
| V | $(t,t,v)$ | Two equal canted spins; the third has the opposite transverse direction |
| P | $(0,0,0)$ | All spins parallel to the field; $m_z=S$ |

For Y, substituting $c=\cos t$ into @eq-nbcp-three-energy gives

$$
e_Y=S^2[-J+(J+J_z)c^2-2J_zc]-\frac{hS}{3}(2c-1),
\qquad c=\frac{h+3SJ_z}{3S(J+J_z)}.
$$ {#eq-nbcp-y-energy}

Its merger with UUD occurs at $c=1$. The collinear energies are $e_{\rm UUD}=-S^2J_z-hS/3$ and $e_P=3S^2J_z-hS$. Their crossing alone does not locate the intervening canted phase.

For the V family, the energy and two independent stationarity conditions are

$$
\begin{aligned}
e_V={}&S^2\left[J(\sin^2t+2\sin t\sin v)
+J_z(\cos^2t+2\cos t\cos v)\right]
-\frac{hS}{3}(2\cos t+\cos v),\\
0={}&J\cos t(\sin t+\sin v)-J_z\sin t(\cos t+\cos v)
+\frac{h}{3S}\sin t,\\
0={}&2J\sin t\cos v-2J_z\cos t\sin v+\frac{h}{3S}\sin v.
\end{aligned}
$$ {#eq-nbcp-v-stationarity}

The second and third lines are respectively $(\partial_t e_V)/(2S^2)=0$ and $(\partial_v e_V)/S^2=0$. Their solutions must also pass a stability check. At $B=1.4$ T with the current gap parameters, the selected classical branch has $(t,t,v)=(0.409364861,0.409364861,-1.223629194)$ rad.

The original `Three_MSL.tex` calls a family with two equal canted spins a “Gamma phase.” Its normalized vectors are

$$
\mathbf n_A=\mathbf n_B=(-\sin t,0,\cos t),
\qquad \mathbf n_C=(\sin\psi,0,-\cos\psi).
$$

A common $R_z(\pi)$ rotation maps this family to V above with $v=\psi-\pi$. This is a geometric identification of the reference families; at nonzero $J_\Gamma$, that spin-only rotation is not a symmetry of the full Hamiltonian. The old “V” ansatz instead assigns opposite transverse components to A and B. Its restricted extrema must not be substituted for the V solution above or identified with the paper's $\Psi$ phase merely by renaming.

## Classical reference fields and their stability meaning

The UUD stability matrix can be derived in regular Cartesian coordinates at the collinear poles. Put $\mathbf S_A=(\sqrt S x_A,\sqrt S y_A,S-(x_A^2+y_A^2)/2)$ and similarly for B; for C replace the last component by $-S+(x_C^2+y_C^2)/2$. To quadratic order, $\delta e=(\mathbf x^{\mathsf T}M\mathbf x+\mathbf y^{\mathsf T}M\mathbf y)/2$, where

$$
M=\begin{pmatrix}
h/3&JS&JS\\
JS&h/3&JS\\
JS&JS&2J_zS-h/3
\end{pmatrix}.
$$ {#eq-nbcp-uud-hessian}

The antisymmetric A/B eigenvector has eigenvalue $h/3-JS$. The symmetric A/B sector and C reduce to a $2\times2$ matrix with diagonal entries $h/3+JS$ and $2J_zS-h/3$, and off-diagonal entry $\sqrt2JS$. Setting the lower eigenvalue to zero gives the upper UUD boundary. At P, the diagonal entries become $h/3-2J_zS$, giving the saturation boundary. For $J_z>J>0$ the three reference fields are

$$
\begin{aligned}
h_{c1}&=3SJ,\\
h_{c2}&=3S\left[J_z-\frac J2+
\sqrt{J_z^2+J_zJ-\frac74J^2}\right],\\
h_{c3}&=3S(J+2J_z),\qquad B_{ci}=h_{ci}/(g_z\mu_B).
\end{aligned}
$$ {#eq-nbcp-critical-fields}

These are the classical XXZ reference boundaries and uniform three-sublattice softening conditions. Quantum corrections, other ordering wave vectors and SOC-driven competitors require separate calculations.

| $J$ (meV) | $(h_{c1},h_{c2},h_{c3})$ (meV) | $(B_{c1},B_{c2},B_{c3})$ (T) |
|---:|:---|:---|
| 0.075 | (0.112500, 0.315916, 0.487500) | (0.418417, 1.174976, 1.813142) |
| 0.076 | (0.114000, 0.314316, 0.489000) | (0.423996, 1.169024, 1.818721) |

Both rows use $J_z=0.125$ meV, $S=1/2$, $g_z=4.645$ and $\mu_B=0.05788381806$ meV/T. The older notes also quote $(0.1005,0.3278,0.4755)$ meV while specifying $J=0.076$ meV. Those numbers are not evaluations of @eq-nbcp-critical-fields at the stated inputs and are not used here. The present reference fields were recalculated; the archived phase scans were not rerun.

## Competing magnetic cells and quantum results

The source notebook contains a two-sublattice stripe energy and a four-sublattice variational construction. These are essential competitors because they retain the anisotropic bond contributions that cancel in the three-sublattice energy. For a stripe whose same-sublattice bonds are of type 0, the bond count gives

$$
E^{(2)}_{\rm cell}=\mathbf S_A^{\mathsf T}\mathsf J_0\mathbf S_A
+\mathbf S_B^{\mathsf T}\mathsf J_0\mathbf S_B
+2\mathbf S_A^{\mathsf T}(\mathsf J_1+\mathsf J_2)\mathbf S_B
-h(S_A^z+S_B^z).
$$ {#eq-nbcp-stripe-energy}

Comparison with a three-sublattice state requires $E^{(2)}_{\rm cell}/2$ and $E^{(3)}_{\rm cell}/3$. A stationary point found in a fixed spin plane still requires fluctuations outside that plane and at finite momentum to be checked. In particular, an exactly in-plane stripe at $h\ne0$ experiences a linear Zeeman torque; a field-independent Hessian evaluated there does not prove finite-field stability.

The target paper reports Y, UUD, V, $\Psi$ and P at zero bond-dependent SOC, and stripe and four-site SkX orders as SOC grows. Its phase map uses iDMRG cylinders, while the reported $\Psi$ state is not a stable LSWT reference. These results motivate the competitor list; their phase boundaries and finite-circumference convergence have not been independently reproduced here. See [Park et al., Section II](https://arxiv.org/html/2601.20963v1#S2).

For a four-site noncoplanar texture, scalar chirality and geometric topological charge are different diagnostics. The signed triple product $\mathbf n_i\cdot(\mathbf n_j\times\mathbf n_k)$ is an oriented local chirality. A lattice solid angle additionally depends on dot products and a branch choice. The original four-site draft takes an absolute value in its solid-angle numerator; that loses orientation and cannot be used to establish a signed skyrmion charge. No topological charge from that draft is adopted in the present phase classification.

# Supersolidity of the Y and V phases {#sec-nbcp-supersolidity .newpage}

## Density order and transverse phase coherence

For $S=1/2$, the mapping $n_i=\hat S_i^z+1/2$ and $b_i^\dagger=\hat S_i^+$ relates longitudinal spin order to boson-density order and transverse spin coherence to boson phase coherence. A three-sublattice density order parameter can be defined by

$$
D_z=\frac13\left(\langle S_A^z\rangle+
e^{2\pi i/3}\langle S_B^z\rangle+
e^{-2\pi i/3}\langle S_C^z\rangle\right).
$$ {#eq-nbcp-density-order}

Nonzero $D_z$ distinguishes a longitudinally modulated state from the uniformly polarized state. A transverse ordered component is described by $\langle S_\alpha^+\rangle=\Psi_\alpha e^{i\phi}$ in a chosen broken-symmetry state, with sublattice-dependent amplitudes $\Psi_\alpha$. The common phase is the relevant collective coordinate; the sum of the three transverse moments can vanish even when these amplitudes are nonzero.

At exact U(1) symmetry and zero temperature, coexistence of density order and transverse long-range order supplies the usual spin-supersolid criterion. At nonzero temperature in the strictly two-dimensional phase-only regime, the transverse criterion is algebraic correlations and a nonzero renormalized stiffness, while density order must persist. A static Y/V-shaped arrangement, a large magnetocaloric response, or a local energy minimum alone does not establish both properties.

## From a classical orbit to quantum pinning

The common spin rotation is $\mathbf S_\alpha(\phi)=R_z(\phi)\mathbf S_\alpha(0)$ for all three sublattices. It is an exact symmetry at $J_{\rm PD}=J_\Gamma=0$. At nonzero SOC, the three-sublattice classical energy remains constant along this orbit by the bond-sum cancellation, although the finite-momentum spin-wave Hamiltonian changes. The spin-wave vacuum energy can therefore select discrete values of $\phi$.

For a stable background and a single soft uniform phase, let $C_\phi=\partial_\phi^2e_{\rm sw}|_{\phi_*}$ and $\chi_z=\partial m_z/\partial h$, where $m_z=(S/3)\sum_\alpha\cos\vartheta_\alpha$ follows the relaxed classical branch. The leading gap is

$$
\Delta_{\rm PG}^2=\frac{C_\phi}{\chi_z}.
$$ {#eq-nbcp-gap-summary}

The conjugate response is a nonuniform polar displacement, not a common increment of every polar angle. Appendix A derives this statement from the Berry term and gives the complete legacy comparison. The current representative gaps at nonzero coupling 0.010 meV are 0.00686217 meV (Y/PD), $7.2960\times10^{-6}$ meV (Y/Gamma), 0.0156468 meV (V/PD) and 0.00203898 meV (V/Gamma). They describe the leading local pinning calculation at $T=0$, not a finite-temperature transition or an all-orders prediction for $S=1/2$.

## The pure-PD V branch requires sixfold pinning

The Fourier content of the angular energy determines which discrete pinning competes with phase coherence. For pure PD, the microscopic Hamiltonian is invariant under $R_z(\pi)$; at nonzero $J_\Gamma$, that transformation instead maps $J_\Gamma$ to $-J_\Gamma$. Within a fixed V density domain, the threefold lattice-spin operation also imposes $v(\phi+2\pi/3)=v(\phi)$. At $J_\Gamma=0$, both conditions require Fourier indices in $6\mathbb Z$.

Consequently a generic V phase with nonzero Gamma coupling may have a threefold term, but the pure-PD V branch has leading allowed sixfold pinning. The local unconstrained Fourier analysis of the saved energies supports this distinction. At base mesh $N=48$, its dominant amplitudes are $A_6=1.0239780\times10^{-5}$ meV/spin for V/PD and $A_3=7.1609759\times10^{-7}$ meV/spin for V/Gamma. The separate [clock-anisotropy derivation](pseudo-goldstone/clock-anisotropy-review.md) contains the symmetry argument, all four Y/V cases and matrix checks.

![V-state angular vacuum energy for pure PD and pure Gamma at coupling 0.010 meV. The ordinate is the energy difference per physical spin; the two panels have different scales.](../../data-space/verification/260916-clock-anisotropy/v-clock-anisotropy.png){#fig-nbcp-clock}

This distinction qualifies the use of a three-state clock model for every V regime. It does not by itself establish a finite-temperature V supersolid.

## Thermal phase coherence and the missing stiffness

To separate local pinning from spatial rigidity, consider a continuum energy with physical area element $d^2r$,

$$
F[\phi]=\int d^2r\left[
\frac12\rho_{\mu\nu}\partial_\mu\phi\,\partial_\nu\phi
+\frac{v(\phi)}{a_{\rm spin}}\right],
\qquad a_{\rm spin}=\frac{\sqrt3a^2}{2}.
$$ {#eq-nbcp-continuum-energy}

Here $a$ is the nearest-neighbor distance, $a_{\rm spin}$ is the area per spin, $\rho_{\mu\nu}$ has units of energy, and $v$ is a pinning energy per spin. After the other modes have been relaxed, the coefficient of a small phase gradient defines the stiffness. Uniform-rotation data determine $v$ but contain no information about that gradient coefficient. In the same leading local dynamical reduction, the small-wave-vector dispersion would satisfy

$$
\varepsilon(\mathbf q)^2=
\frac{C_\phi+a_{\rm spin}\rho_{\mu\nu}q_\mu q_\nu}{\chi_z}.
$$ {#eq-nbcp-phase-dispersion}

This equation states the normalization of a proposed long-wavelength matching; the required $\rho_{\mu\nu}$ has not yet been extracted from the microscopic calculation.

For an isotropic phase theory, define $K=\rho_s/(k_BT)$ and a weak $p$-fold perturbation $-y_p\cos(p\phi-\delta_p)$. Gaussian correlations give scaling dimension $x_p=p^2/(4\pi K)$, whereas the unit-vortex fugacity has eigenvalue $2-\pi K$. Both pinning and integer vortices are irrelevant only if

$$
\frac{2}{\pi}<K<\frac{p^2}{8\pi}.
$$ {#eq-nbcp-clock-window}

The interval is absent for $p=3$ and present for $p=6$. This is a conditional phase-only RG statement. It assumes a stable density-ordered background, weak perturbations near the Gaussian fixed line and the specified vortex content. Translation-domain walls, fractional defects, competing phases and temperature-dependent stiffness can alter the microscopic thermal sequence. The interval is therefore not a numerical prediction of NBCP transition temperatures.

The next calculation should determine the relaxed spatial stiffness, match it to the per-spin pinning potential and test both density order and transverse correlations at finite temperature. The gap calculation settles the normalization of a local uniform mode; it does not replace those steps.

# Pseudo-Goldstone gap: derivation and calculation {#sec-nbcp-gap-appendix .appendix .newpage}

The detailed appendix is maintained in the [Y/V curvature and comparison note](pseudo-goldstone/comparison-report.md). Its full body is included here in the generated TeX and PDF, retaining the canonical-coordinate derivation, Y/V response formulas, gap plots, legacy findings and convergence tables. This link and the inclusion marker keep a single editable owner for the detailed calculation.

<!-- include-appendix: pseudo-goldstone/comparison-report.md -->
