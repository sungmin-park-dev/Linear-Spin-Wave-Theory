---
frontmatter-version: 1
title: NBCP Research Sources
doc-path: docs/nbcp/sources
status: in-review
last-edited-by: codex
created: 2026-09-16
updated: 2026-09-16
---

# NBCP 참고자료

현재 Y/V 연구의 문헌 목록과 각 문헌의 역할은 [부록의 References](../pseudo-goldstone/comparison-report.md#references)에 기록되어 있다. 물질 및 phase 분석의 문헌은 [통합 연구노트](../research-note.md)의 해당 주장 가까이에 연결한다. 현재 별도의 논문 사본은 없다.

## 기존 Overleaf 연구노트

[2026-09-16 원문 대조 기록](overleaf-2026-09-16-review.md)에 로그인된 연구 프로젝트의 확인 범위, 파일·section 대응과 수식 검토 결과를 보존했다. `main.tex`, `analysis.tex`, 3·2·4부격자 파일의 내용을 통합본에 선별 반영했다. 이 파일은 원문 발췌·검토 기록이며 전체 ZIP 또는 원본 TeX 백업이 아니다. 온라인 원본을 다시 확인할 수 있는 프로젝트 링크와 당시 줄 번호를 제공한다.

유한온도 clock 이방성 논의의 원문 확인 범위와 RG 참고문헌은 [Clock Anisotropy Review](../pseudo-goldstone/clock-anisotropy-review.md#external-sources)에 기록한다.

일반 LSWT 원본 노트와 전사본은 [LSWT sources](../../lswt/sources/README.md)에 보존한다. 같은 원자료를 두 주제 폴더에 중복 복사하지 않고 해당 자료를 연결한다.
