-- Translate semantic Markdown attributes into ordinary LaTeX environments.
function Header(el)
  if not FORMAT:match('latex') then return end
  local blocks = pandoc.List()
  if el.classes:includes('newpage') then
    blocks:insert(pandoc.RawBlock('latex', '\\clearpage'))
  end
  if el.classes:includes('appendix') then
    blocks:insert(pandoc.RawBlock('latex', '\\appendix'))
  end
  blocks:insert(el)
  return blocks
end

function Div(el)
  if FORMAT:match('latex') and el.classes:includes('result') then
    el.content:insert(1, pandoc.RawBlock('latex', '\\begin{tcolorbox}[colback=NotePale,colframe=NoteAccent,boxrule=0pt,leftrule=2pt,arc=0pt]'))
    el.content:insert(pandoc.RawBlock('latex', '\\end{tcolorbox}'))
    return el.content
  end
  -- Allow normal page breaking instead of unbreakable minipage wrappers.
  if el.classes:includes('keep-together') then return el.content end
end

function Code(el)
  if FORMAT:match('latex') then
    return pandoc.RawInline('latex', '{\\small\\texttt{\\nolinkurl{' .. el.text .. '}}}')
  end
end
