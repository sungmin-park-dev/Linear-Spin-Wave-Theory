---
frontmatter-version: 1
title: NBCP Research Notes
doc-path: docs/nbcp
status: in-review
last-edited-by: codex
created: 2026-09-16
updated: 2026-09-16
---

# NBCP 연구 노트

[전체 문서](../README.md) · [LSWT 일반 이론](../lswt/README.md)

Na₂BaCo(PO₄)₂ 연구에서 사용하는 모델별 유도, 수치 결과와 비교 기록을 관리한다. 일반적인 LSWT 정의와 유도는 LSWT 문서에서 다루고, 여기서는 연구 질문과 해당 모델의 적용 조건을 중심으로 서술한다.

## 현재 연구노트와 목차

집필 진입점은 [research-note.md](research-note.md)다. 로그인된 Overleaf 원문을 대조하여 아래 순서로 구성했다.

1. **NBCP 소개**: effective spin, NN 교환행렬의 대칭 유도, 단위와 매개변수 출처.
2. **Phase 분석**: 3부격자 에너지, Y/UUD/V/P 정의, 고전 임계장, stripe·4부격자 경쟁 상태.
3. **Y/V supersolidity 분석**: 질서변수, 양자 pinning, pure-PD V의 6회 대칭, 열적 주장과 공간적 강성의 역할.
4. **부록 A — pseudo-Goldstone gap**: 기존 곡률·canonical response 유도와 수치 검증을 전체 포함.

본문 1–3장은 `research-note.md`에서 편집한다. 부록의 상세 내용은 아래 `comparison-report.md` 한 곳에서 편집하며, 통합 TeX·PDF를 만들 때 전체가 포함된다. [통합 PDF](../build/nbcp/research-note/research-note.pdf) · [통합 TeX](../build/nbcp/research-note/research-note.tex).

## 상세 계산과 근거

| 연구 주제 | 편집 원본 | 검토 상태 |
|---|---|---|
| 부록 A: Y/V pseudo-Goldstone gap | [comparison-report.md](pseudo-goldstone/comparison-report.md) | in-review; 통합본과 독립 출력이 같은 원본을 사용 |
| PD 축의 clock 이방성과 유한온도 주장 | [clock-anisotropy-review.md](pseudo-goldstone/clock-anisotropy-review.md) | in-review; 순수 PD V의 6회 대칭 확인, 열적 상의 존재는 미검증 |

## 관련 자료

- [TeX·PDF 출력 안내](../build/README.md): 현재 노트의 생성 출력물과 재생성 방법.
- [계산·검증 데이터](../../data-space/verification/260912-pseudo-goldstone/): JSON, 그림과 legacy 실행 로그.
- [참고자료](sources/README.md): 연구 노트가 사용하는 문헌.
- [Overleaf 원문 대조 기록](sources/overleaf-2026-09-16-review.md): 파일별 확인 범위, 본문 배치, 보류 항목 및 원문 수식 차이. 전체 프로젝트 백업은 아님.
- [열린 연구 이슈](../../GOVERNMENT/Working-Pad/issue-notes/open/260810-pseudo-goldstone-gap.md): 계산 차이와 남은 검토.

현재 노트는 Markdown을 편집 원본으로 사용한다. 폴더 통합은 TeX 직접 집필 방식으로의 전환을 포함하지 않는다. 출력물은 원본과 같은 내용을 담는 파생물이며 직접 수정하지 않는다.
