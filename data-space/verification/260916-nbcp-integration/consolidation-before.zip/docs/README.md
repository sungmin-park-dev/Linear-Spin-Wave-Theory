---
frontmatter-version: 1
title: Documentation
doc-path: docs
status: in-review
last-edited-by: codex
created: 2026-09-16
updated: 2026-09-16
---

# 문서 안내

LSWT 일반 이론과 NBCP 연구 노트를 주제별로 관리한다. 현재 집필하는 본문, 그 근거인 참고자료, 과거 문서와 생성 출력물은 아래 위치로 구분한다.

| 찾는 내용 | 위치 | 용도 |
|---|---|---|
| LSWT 일반 이론 | [lswt/](lswt/README.md) | 정의·가정·일반 유도·관측량 설명. 번호 폴더는 읽는 순서다. |
| NBCP 연구 | [nbcp/](nbcp/README.md) | 모델별 질문·유도·수치 결과·기존 계산과의 비교 |
| LSWT 원자료 | [lswt/sources/](lswt/sources/README.md) | 원본 노트·TeX 전사본·외부 논문·검증 근거 |
| NBCP 참고자료 | [nbcp/sources/](nbcp/sources/README.md) | 연구 노트에서 사용하는 참고문헌 안내 |
| 집필을 종료한 문서 | [archive/](archive/README.md) | 이전 문서·스냅샷. 기존 legacy 자료의 위치도 안내한다. |
| 생성 출력물 | [build/](build/README.md) | 원본에서 생성한 TeX·PDF와 출력에 필요한 자산 |

## 현재 편집할 파일

- 일반 이론은 [LSWT 읽기 순서](lswt/README.md)에서 해당 Markdown 문서를 찾는다.
- NBCP 본문은 [research-note.md](nbcp/research-note.md)에서 편집한다. 상세 pseudo-Goldstone 부록은 [comparison-report.md](nbcp/pseudo-goldstone/comparison-report.md)가 소유하며 통합 출력 때 포함된다. TeX·PDF는 생성물이며 별도 편집 원본이 아니다.
- 계산 코드와 결과 데이터는 각각 [examples/](../examples/)와 [data-space/](../data-space/)에서 관리한다. NBCP 노트에서 해당 실행·검증 기록을 연결한다.

폴더 위치는 검토 완료 여부를 뜻하지 않는다. LSWT 이론의 acceptance, NBCP 연구 검토, 코드 검증은 별도로 기록한다. 참고자료는 현재 주장을 확인하는 근거이며 본문과 동등한 편집 원본이 아니다.

현재 구조와 이전 경로의 대응은 [2026-09-16 문서 통합 기록](../GOVERNMENT/Working-Pad/issue-notes/closed/260916-docs-topic-consolidation.md)에 있다.
