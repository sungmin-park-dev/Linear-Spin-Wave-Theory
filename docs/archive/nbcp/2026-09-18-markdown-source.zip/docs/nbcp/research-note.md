---
frontmatter-version: 1
title: "NBCP: phases and spin supersolidity"
doc-path: docs/nbcp
artifact-role: integrated research note
status: in-review
last-edited-by: codex
created: 2026-09-16
updated: 2026-09-18
date: 2026-09-18
date-format: "D MMMM YYYY"
lang: en
---

# Introduction {#sec-nbcp-introduction}

$\mathrm{Na_2BaCo(PO_4)_2}$ (NBCP) provides a setting in which a magnetic field, easy-axis exchange and bond-dependent interactions compete on a triangular lattice. The central question is whether the Y and V magnetic orders retain the phase coherence required for spin supersolidity when spin-orbit coupling removes exact spin-rotation symmetry. Answering it requires three distinct steps: specifying the microscopic model, establishing the stability of a magnetic state, and determining its long-wavelength phase dynamics.

The analysis proceeds from the microscopic Hamiltonian and candidate phases to the common low-energy theory of Y and V, the conditions for spin supersolidity, and separate tests in each phase. Classical stability, leading quantum pinning and finite-temperature order are distinct questions. The present evidence is strongest for the classical Y gradient and density-wall sectors; it does not establish a complete quantum phase diagram or a thermal supersolid phase.

The material and classical analysis develop the original Overleaf research notes. Existing curvature, angular-matching and nonlinear calculations are retained with their approximation limits. Detailed gap, clock-RG and stiffness derivations are collected in the appendices. All results remain subject to physics review; a stable local branch is not by itself a complete phase diagram.

# Model Hamiltonian {#sec-nbcp-model-hamiltonian .newpage}

## Magnetic degrees of freedom and the two-dimensional approximation

The Co ions form triangular magnetic layers. Crystal-field effects and atomic spin-orbit coupling produce a low-energy effective spin-$1/2$ doublet; higher multiplets lie approximately 71 meV above it. A dominant in-plane nearest-neighbor model is motivated by the exchange paths and weaker interlayer coupling. These are the material assumptions used in [Gao et al. (2022)](https://doi.org/10.1038/s41535-022-00500-3), rather than a claim that every further-neighbor or interlayer interaction vanishes exactly.

Atomic spin-orbit coupling, which helps create the effective doublet, must be distinguished from the coefficients of the residual bond-dependent exchanges. A small fitted $J_{\rm PD}$ or $J_\Gamma$ does not imply that the atomic spin-orbit interaction is absent. In this note, “zero SOC” is shorthand for the exchange-model limit $J_{\rm PD}=J_\Gamma=0$.

We use $z\parallel c$ and $x$ along one nearest-neighbor bond. The external field is $B\parallel z$, and $h=g_z\mu_B B$ is its Zeeman energy. Spin operators are dimensionless, with eigenvalues measured in units of $\hbar$; exchange constants, $h$, and excitation gaps are expressed in meV. Energies denoted by $e$ are per physical spin.

## Symmetry-constrained nearest-neighbor exchange

For one unoriented bond counted once, write $\hat H_{ij}=\hat{\mathbf S}_i^{\mathsf T}\mathsf J_{ij}\hat{\mathbf S}_j$. Bond-centered inversion exchanges $i$ and $j$. Spin is an axial vector, so its components do not change sign under spatial inversion. Invariance therefore requires $\mathsf J_{ij}=\mathsf J_{ij}^{\mathsf T}$. A twofold rotation about the reference $x$ bond has spin-space matrix $\operatorname{diag}(1,-1,-1)$ and forbids its $xy$ and $xz$ entries. The remaining four parameters give

$$
\mathsf J_0=
\begin{pmatrix}
J+2J_{\rm PD}&0&0\\
0&J-2J_{\rm PD}&J_\Gamma\\
0&J_\Gamma&J_z
\end{pmatrix}.
$$ {#eq-nbcp-reference-bond}

Let $R_z(\beta)$ be the active Cartesian rotation about $z$. Rotating the bond and both spins gives $\mathsf J_\beta=R_z(\beta)\mathsf J_0R_z(\beta)^{\mathsf T}$. Its transverse anisotropy contains $\cos 2\beta$ and $\sin 2\beta$. Only for the three bond phases $\varphi_d=0,\pm2\pi/3$ can one use $\cos2\varphi_d=\cos\varphi_d$ and $\sin2\varphi_d=-\sin\varphi_d$, obtaining

$$
\mathsf J_d=
\begin{pmatrix}
J+2J_{\rm PD}\cos\varphi_d&-2J_{\rm PD}\sin\varphi_d&-J_\Gamma\sin\varphi_d\\
-2J_{\rm PD}\sin\varphi_d&J-2J_{\rm PD}\cos\varphi_d&J_\Gamma\cos\varphi_d\\
-J_\Gamma\sin\varphi_d&J_\Gamma\cos\varphi_d&J_z
\end{pmatrix}.
$$ {#eq-nbcp-bond-matrix}

The microscopic Hamiltonian is consequently

$$
\hat H=\sum_{\langle ij\rangle}\hat{\mathbf S}_i^{\mathsf T}
\mathsf J_{d(ij)}\hat{\mathbf S}_j-h\sum_i\hat S_i^z.
$$ {#eq-nbcp-model}

The bond phase $\varphi_d$ labels a fixed exchange tensor. The collective angle $\phi$ introduced below rotates the spins while keeping these tensors fixed. They must not be varied together when evaluating the order-by-disorder energy.

With $\hat S^\pm=\hat S^x\pm i\hat S^y$, the transverse XXZ interaction is $J(\hat S_i^+\hat S_j^-+\hat S_i^-\hat S_j^+)/2$. Thus a convention with coefficient $J_\pm$ multiplying that entire bracket has $J=2J_\pm$, not $J=J_\pm$. The original notes contain both identifications; the Cartesian matrix fixes the convention used here.

## Parameter sets and the scope of the calculation

The original notes contain several parameter sets with different origins. They should remain separate when comparing a field quoted in tesla with an exchange or field quoted in meV.

| Parameter set | $J$ | $J_z$ | $g_z$ |
|:---|---:|---:|---:|
| Thermodynamic fit, Gao et al. | $0.88\,k_B\mathrm{K}$ | $1.48\,k_B\mathrm{K}$ | 4.89 |
| Older Overleaf phase calculations | 0.076 meV | 0.125 meV | 4.645 |
| Current Y/V gap comparison | 0.075 meV | 0.125 meV | 4.645 |

The thermodynamic values are reported in [Gao et al.](https://doi.org/10.1038/s41535-022-00500-3); the last row follows the Figure 4 parameters of [Park et al., arXiv:2601.20963v1](https://arxiv.org/html/2601.20963v1). The middle row records the historical local convention, not a new fit. The present calculation uses $S=1/2$, nearest-neighbor bonds and a single layer. The earlier next-nearest-neighbor draft is not included: its axis and angular conventions require further review.

# Phase Diagram {#sec-nbcp-phases .newpage}

The classical three-sublattice analysis supplies reference branches and local boundaries. A phase diagram requires comparison with other magnetic cells and the relevant quantum energies. The distinction is maintained below: a stable magnon spectrum is a local test, while the lowest energy among an incomplete set of candidate states need not identify the global ground state.

## Classical phase diagram {#sec-nbcp-classical-phases}

### Three-sublattice classical energy

Let $\mathbf n_\alpha=\mathbf S_\alpha/S$, with $\alpha=A,B,C$, specify a uniform three-sublattice configuration. Each pair of sublattices is connected by all three bond orientations. Since $\sum_d\mathsf J_d=3\operatorname{diag}(J,J,J_z)$, its classical energy per physical spin reduces to

$$
e_{\rm cl}=S^2\sum_{(\alpha\beta)=(AB),(BC),(CA)}
\left[J\sin\vartheta_\alpha\sin\vartheta_\beta
\cos(\phi_\alpha-\phi_\beta)
+J_z\cos\vartheta_\alpha\cos\vartheta_\beta\right]
-\frac{hS}{3}\sum_\alpha\cos\vartheta_\alpha.
$$ {#eq-nbcp-three-energy}

Here $\vartheta$ may be signed, with $\mathbf n=(\sin\vartheta\cos\phi,\sin\vartheta\sin\phi,\cos\vartheta)$. Negative $\vartheta$ is a coordinate choice, equivalent to a positive polar angle and an azimuth shifted by $\pi$.

The SOC contributions cancel in this restricted classical energy. They do not disappear from the operator Hamiltonian, from finite-momentum fluctuations, or from states with other magnetic unit cells. In particular, the cancellation does not establish SOC-independent global phase boundaries.

### Classical reference fields and their stability meaning

The UUD stability matrix can be derived in regular Cartesian coordinates at the collinear poles. Put $\mathbf S_A=(\sqrt S x_A,\sqrt S y_A,S-(x_A^2+y_A^2)/2)$ and similarly for B; for C replace the last component by $-S+(x_C^2+y_C^2)/2$. To quadratic order, $\delta e=(\mathbf x^{\mathsf T}M\mathbf x+\mathbf y^{\mathsf T}M\mathbf y)/2$, where

$$
M=\begin{pmatrix}
h/3&JS&JS\\
JS&h/3&JS\\
JS&JS&2J_zS-h/3
\end{pmatrix}.
$$ {#eq-nbcp-uud-hessian}

The antisymmetric A/B eigenvector has eigenvalue $h/3-JS$. The symmetric A/B sector and C reduce to a $2\times2$ matrix with diagonal entries $h/3+JS$ and $2J_zS-h/3$, and off-diagonal entry $\sqrt2JS$. Setting the lower eigenvalue to zero gives the upper UUD boundary. At P, the diagonal entries become $h/3-2J_zS$, giving the saturation boundary. For $J_z>J>0$ the three reference fields are

$$
\begin{aligned}
h_{c1}&=3SJ,\\
h_{c2}&=3S\left[J_z-\frac J2+
\sqrt{J_z^2+J_zJ-\frac74J^2}\right],\\
h_{c3}&=3S(J+2J_z),\qquad B_{ci}=h_{ci}/(g_z\mu_B).
\end{aligned}
$$ {#eq-nbcp-critical-fields}

These are the classical XXZ reference boundaries and uniform three-sublattice softening conditions. Quantum corrections, other ordering wave vectors and SOC-driven competitors require separate calculations.

| $J$ (meV) | $(h_{c1},h_{c2},h_{c3})$ (meV) | $(B_{c1},B_{c2},B_{c3})$ (T) |
|---:|:---|:---|
| 0.075 | (0.112500, 0.315916, 0.487500) | (0.418417, 1.174976, 1.813142) |
| 0.076 | (0.114000, 0.314316, 0.489000) | (0.423996, 1.169024, 1.818721) |

Both rows use $J_z=0.125$ meV, $S=1/2$, $g_z=4.645$ and $\mu_B=0.05788381806$ meV/T. The older notes also quote $(0.1005,0.3278,0.4755)$ meV while specifying $J=0.076$ meV. Those numbers are not evaluations of @eq-nbcp-critical-fields at the stated inputs and are not used here. The present reference fields were recalculated; the archived phase scans were not rerun.

## Quantum corrections: zero-point energy {#sec-nbcp-phase-quantum-correction}

At harmonic order, the comparison adds the spin-wave vacuum energy to the classical energy for each admissible reference state. The positive physical magnon bands and the normal-ordering trace constant must both be included, and all candidate energies must use the same per-spin normalization and Brillouin-zone convention. An unstable quadratic background cannot be assigned a physical harmonic vacuum energy by discarding its unstable modes.

The existing calculations resolve the vacuum-energy dependence along selected Y/V angular orbits; they do not reoptimize and compare all candidate phases across the model's parameter space. Consequently, the classical reference fields are not promoted to quantum-corrected phase boundaries. The local angular selection and its pseudo-Goldstone gap are treated in @sec-nbcp-yv-low-energy; numerical quadrature and convergence are recorded in @sec-convergence.

## Characterization of phases {#sec-nbcp-phase-characterization}

### Y, UUD, V and the polarized state

At common azimuth $\phi=0$, the following signed-angle definitions fix the states independently of historical names:

| State | $(\vartheta_A,\vartheta_B,\vartheta_C)$ | Characteristic structure |
|:---|:---|:---|
| Y | $(t,-t,\pi)$ | Opposite transverse components; one spin antiparallel to the field |
| UUD | $(0,0,\pi)$ | Two up spins and one down spin; $m_z=S/3$ |
| V | $(t,t,v)$ | Two equal canted spins; the third has the opposite transverse direction |
| P | $(0,0,0)$ | All spins parallel to the field; $m_z=S$ |

For Y, substituting $c=\cos t$ into @eq-nbcp-three-energy gives

$$
e_Y=S^2[-J+(J+J_z)c^2-2J_zc]-\frac{hS}{3}(2c-1),
\qquad c=\frac{h+3SJ_z}{3S(J+J_z)}.
$$ {#eq-nbcp-y-energy}

Its merger with UUD occurs at $c=1$. The collinear energies are $e_{\rm UUD}=-S^2J_z-hS/3$ and $e_P=3S^2J_z-hS$. Their crossing alone does not locate the intervening canted phase.

For the V family, the energy and two independent stationarity conditions are

$$
\begin{aligned}
e_V={}&S^2\left[J(\sin^2t+2\sin t\sin v)
+J_z(\cos^2t+2\cos t\cos v)\right]
-\frac{hS}{3}(2\cos t+\cos v),\\
0={}&J\cos t(\sin t+\sin v)-J_z\sin t(\cos t+\cos v)
+\frac{h}{3S}\sin t,\\
0={}&2J\sin t\cos v-2J_z\cos t\sin v+\frac{h}{3S}\sin v.
\end{aligned}
$$ {#eq-nbcp-v-stationarity}

The second and third lines are respectively $(\partial_t e_V)/(2S^2)=0$ and $(\partial_v e_V)/S^2=0$. Their solutions must also pass a stability check. At $B=1.4$ T with the current gap parameters, the selected classical branch has $(t,t,v)=(0.409364861,0.409364861,-1.223629194)$ rad.

The original `Three_MSL.tex` calls a family with two equal canted spins a “Gamma phase.” Its normalized vectors are

$$
\mathbf n_A=\mathbf n_B=(-\sin t,0,\cos t),
\qquad \mathbf n_C=(\sin\psi,0,-\cos\psi).
$$

A common $R_z(\pi)$ rotation maps this family to V above with $v=\psi-\pi$. This is a geometric identification of the reference families; at nonzero $J_\Gamma$, that spin-only rotation is not a symmetry of the full Hamiltonian. The old “V” ansatz instead assigns opposite transverse components to A and B. Its restricted extrema must not be substituted for the V solution above or identified with the paper's $\Psi$ phase merely by renaming.

### Competing magnetic cells and quantum results

The source notebook contains a two-sublattice stripe energy and a four-sublattice variational construction. These are essential competitors because they retain the anisotropic bond contributions that cancel in the three-sublattice energy. For a stripe whose same-sublattice bonds are of type 0, the bond count gives

$$
E^{(2)}_{\rm cell}=\mathbf S_A^{\mathsf T}\mathsf J_0\mathbf S_A
+\mathbf S_B^{\mathsf T}\mathsf J_0\mathbf S_B
+2\mathbf S_A^{\mathsf T}(\mathsf J_1+\mathsf J_2)\mathbf S_B
-h(S_A^z+S_B^z).
$$ {#eq-nbcp-stripe-energy}

Comparison with a three-sublattice state requires $E^{(2)}_{\rm cell}/2$ and $E^{(3)}_{\rm cell}/3$. A stationary point found in a fixed spin plane still requires fluctuations outside that plane and at finite momentum to be checked. In particular, an exactly in-plane stripe at $h\ne0$ experiences a linear Zeeman torque; a field-independent Hessian evaluated there does not prove finite-field stability.

The target paper reports Y, UUD, V, $\Psi$ and P at zero bond-dependent SOC, and stripe and four-site SkX orders as SOC grows. Its phase map uses iDMRG cylinders, while the reported $\Psi$ state is not a stable LSWT reference. These results motivate the competitor list; their phase boundaries and finite-circumference convergence have not been independently reproduced here. See [Park et al., Section II](https://arxiv.org/html/2601.20963v1#S2).

# Skyrmion Phase {#sec-nbcp-skyrmion .newpage}

The four-site SkX order reported by the target paper is a candidate competitor, not a phase independently established by the present calculations. The source notes contain a four-sublattice variational construction, but its stationary texture, stability and signed topological charge require a consistent audit before it can be used in a phase comparison.

## Spin texture and topological identification

For a four-site noncoplanar texture, scalar chirality and geometric topological charge are different diagnostics. The signed triple product $\mathbf n_i\cdot(\mathbf n_j\times\mathbf n_k)$ is an oriented local chirality. A lattice solid angle additionally depends on dot products and a branch choice. The original four-site draft takes an absolute value in its solid-angle numerator; that loses orientation and cannot be used to establish a signed skyrmion charge. No topological charge from that draft is adopted in the present phase classification.

## Energy and stability requirements

A completed characterization must specify the periodic spin texture, the orientation and counting of elementary triangles, the signed topological-charge convention and the energy per physical spin. Comparison with Y, V and stripe states must use the same Hamiltonian parameters. A magnon spectrum would test local stability of the selected texture; it would not replace that energy comparison. These calculations and a verified SkX band structure are not yet supplied here.

# Y and V Phases: Symmetry and Low-Energy Theory {#sec-nbcp-yv-low-energy .newpage}

The Y and V reference states carry sublattice-dependent longitudinal and transverse components. Their common collective coordinate is a laboratory-$z$ rotation of all three spins. This chapter identifies the symmetry and conjugate response shared by the two phases; the phase-specific spatial and thermal tests are treated separately in @sec-nbcp-y-phase and @sec-nbcp-v-phase.

## Exact symmetry and accidental classical degeneracy

At zero bond-dependent SOC, a common spin rotation is an exact U(1) symmetry of the Hamiltonian. Choosing a transverse orientation then concerns spontaneous symmetry breaking of that Hamiltonian. At nonzero SOC, the constant energy of the restricted three-sublattice orbit instead follows from cancellation of the bond-dependent terms. It is an accidental classical degeneracy, even though the microscopic Hamiltonian need not have continuous spin-rotation symmetry. This distinction must be retained when interpreting a pseudo-Goldstone mode.

## From a classical orbit to quantum pinning

The common spin rotation is $\mathbf S_\alpha(\phi)=R_z(\phi)\mathbf S_\alpha(0)$ for all three sublattices. It is an exact symmetry at $J_{\rm PD}=J_\Gamma=0$. At nonzero SOC, the three-sublattice classical energy remains constant along this orbit by the bond-sum cancellation, although the finite-momentum spin-wave Hamiltonian changes. The spin-wave vacuum energy can therefore select discrete values of $\phi$.

For a stable background and a single soft uniform phase, let $C_\phi=\partial_\phi^2e_{\rm sw}|_{\phi_*}$ and $\chi_z=\partial m_z/\partial h$, where $m_z=(S/3)\sum_\alpha\cos\vartheta_\alpha$ follows the relaxed classical branch. The leading gap is

$$
\Delta_{\rm PG}^2=\frac{C_\phi}{\chi_z}.
$$ {#eq-nbcp-gap-summary}

The conjugate response is a nonuniform polar displacement, not a common increment of every polar angle. Appendix A derives this statement from the Berry term; @sec-nbcp-verification-appendix and its linked code review retain the legacy comparison. The current representative gaps at nonzero coupling 0.010 meV are 0.00686217 meV (Y/PD), $7.2960\times10^{-6}$ meV (Y/Gamma), 0.0156468 meV (V/PD) and 0.00203898 meV (V/Gamma). They describe the leading local pinning calculation at $T=0$, not a finite-temperature transition or an all-orders prediction for $S=1/2$.

## Canonical response and interpretation of the gap

The angular curvature alone does not determine the excitation energy. Its conjugate response allows the polar directions of the three spins to relax differently, and the susceptibility fixes the normalization of the collective motion. The derivation in @sec-canonical and the Y/V specializations in @sec-states distinguish this response from the common polar-angle increment used in the archived calculation.

The relevant gap is the leading pinning-induced energy of this collective coordinate. It is not the smallest frequency on a finite momentum mesh, a gap assigned to an unstable branch, or the energy of a different internal XXZ mode. A zero-temperature gap also does not by itself decide whether a thermal algebraic phase exists. The symmetry-allowed angular harmonics are examined for Y in @sec-nbcp-y-rg-status and for V in @sec-nbcp-v-symmetry.

# Supersolidity: Definition and Conditions {#sec-nbcp-supersolidity .newpage}

## Density order and transverse phase coherence

For $S=1/2$, the mapping $n_i=\hat S_i^z+1/2$ and $b_i^\dagger=\hat S_i^+$ relates longitudinal spin order to boson-density order and transverse spin coherence to boson phase coherence. A three-sublattice density order parameter can be defined by

$$
D_z=\frac13\left(\langle S_A^z\rangle+
e^{2\pi i/3}\langle S_B^z\rangle+
e^{-2\pi i/3}\langle S_C^z\rangle\right).
$$ {#eq-nbcp-density-order}

Nonzero $D_z$ distinguishes a longitudinally modulated state from the uniformly polarized state. A transverse ordered component is described by $\langle S_\alpha^+\rangle=\Psi_\alpha e^{i\phi}$ in a chosen broken-symmetry state, with sublattice-dependent amplitudes $\Psi_\alpha$. The common phase is the relevant collective coordinate; the sum of the three transverse moments can vanish even when these amplitudes are nonzero.

At exact U(1) symmetry and zero temperature, coexistence of density order and transverse long-range order supplies the usual spin-supersolid criterion. At nonzero temperature in the strictly two-dimensional phase-only regime, the transverse criterion is algebraic correlations and a nonzero renormalized stiffness, while density order must persist. A static Y/V-shaped arrangement, a large magnetocaloric response, or a local energy minimum alone does not establish both properties.

## Spatial stiffness and continuum normalization

To separate local pinning from spatial rigidity, consider a continuum energy with physical area element $d^2r$,

$$
F[\phi]=\int d^2r\left[
\frac12\rho_{\mu\nu}\partial_\mu\phi\,\partial_\nu\phi
+\frac{v(\phi)}{a_{\rm spin}}\right],
\qquad a_{\rm spin}=\frac{\sqrt3a^2}{2}.
$$ {#eq-nbcp-continuum-energy}

Here $a$ is the nearest-neighbor distance, $a_{\rm spin}$ is the area per spin, $\rho_{\mu\nu}$ has units of energy, and $v$ is a pinning energy per spin. After the other modes have been relaxed, the coefficient of a small phase gradient defines the stiffness. Uniform-rotation data determine $v$ but contain no information about that gradient coefficient. When the leading local dynamical reduction has no mixed time-and-space derivative term, the small-wave-vector dispersion satisfies

$$
\varepsilon(\mathbf q)^2=
\frac{C_\phi+a_{\rm spin}\rho_{\mu\nu}q_\mu q_\nu}{\chi_z}.
$$ {#eq-nbcp-phase-dispersion}

The matching is tested for the zero-SOC classical Y state in @sec-nbcp-y-stiffness. With SOC, a mixed frequency--momentum term can invalidate this reciprocal form even while a static stiffness exists; @sec-nbcp-y-soc-conditions derives the replacement. The V stiffness and quantum and thermal renormalizations remain undetermined.

## Clock RG and the algebraic window {#sec-nbcp-clock}

The clock description applies after short-distance modes have been eliminated and the thermal coefficients have been matched. For a constant positive stiffness tensor, use the effective stiffness $\rho_{\rm eff}=\sqrt{\det\rho}$ and dimensionless Gaussian coefficient $K=\rho_{\rm eff}/(k_{\rm B}T)$ at the relevant scale. Here $p$ is the clock harmonic, $y_p$ its dimensionless pinning amplitude, $y_v$ the unit-vortex fugacity, and $\eta$ the exponent of transverse algebraic correlations. The field and fugacity normalizations, shell integration and coupled flow are derived in @sec-nbcp-clock-rg.

 At $y_p=y_v=0$, simultaneous irrelevance requires $2-p^2/(4\pi K)<0$ and $2-\pi K<0$. Thus

$$
\frac{2}{\pi}<K<\frac{p^2}{8\pi}.
$$ {#eq-nbcp-clock-window}

A nonempty interval requires $p>4$; $p=4$ is marginal at the meeting point and is not decided by these linear inequalities. For $p=3$ the interval is empty. For $p=6$,

$$
\frac{2}{\pi}<K<\frac{9}{2\pi},\qquad
\frac19<\eta<\frac14,\qquad
\frac{2\pi\rho_{\rm eff}}9<k_{\rm B}T<\frac{\pi\rho_{\rm eff}}2.
$$ {#eq-nbcp-clock-sixfold-window}

The last form is a condition using the stiffness at the relevant scale, not a pair of transition temperatures obtained by inserting a classical bare exchange. With nonzero initial fugacities, the trajectory must reach the Gaussian basin. In a weak-clock scenario the low-temperature side is pinned, the intermediate region has algebraic transverse correlations, and the high-temperature side has proliferated vortices. The limiting exponents $1/9$ and $1/4$ provide more direct finite-size targets than an unrenormalized estimate of the transition temperatures. Stable longitudinal density order must coexist with the algebraic correlations for the intermediate state to meet the spin-supersolid criterion used here.

## Microscopic tests of the clock reduction {#sec-nbcp-clock-matching-tests}

The proposed clock description has a theoretical basis, but symmetry is not sufficient to establish its applicability to NBCP. Sixfold pinning can be irrelevant on a Gaussian fixed line, and numerical studies of the standard ferromagnetic six-state clock model find two transitions; for example, [Chen et al. (2017)](https://arxiv.org/abs/1706.03455) determine the lower and upper transitions with tensor renormalization. These results establish properties of that effective model. They do not show that a frustrated quantum magnet with additional density domains and competing modes lies in the same basin of attraction. The symmetry and universality argument in [Park et al., Sec. II](https://arxiv.org/html/2601.20963v1#S2) is therefore a physically motivated effective-theory hypothesis, rather than a completed microscopic finite-temperature derivation.

There is a controlled route in principle: start from a stable phase theory, separate massive modes from the compact phase, and match all relevant couplings before applying RG. In a weak-SOC regime continuously connected to a U(1) algebraic phase, weak irrelevant perturbations preserve that phase provided the density sector remains noncritical and no additional relevant defect is introduced. This conditional argument is stronger than a guess based only on the number of angular minima. Its hypotheses must be checked for the chosen field and SOC strength. The following tests specify the full program; @sec-nbcp-y-full-zone-stability supplies an initial harmonic stability screen, not completion of the thermal matching.

**Separation of the other modes.** At each field and SOC point, compute the constrained static Hessian and the dynamical spectrum over the magnetic Brillouin zone, with mesh refinement near minima. Inspect several points on the angular orbit and the selected minimum, allowing the hard internal coordinates to relax. Track mode character with eigenvectors or spectral projectors so that a band crossing is not mistaken for the disappearance of a nonphase mode. An instability at nonzero momentum, an extra soft mode or a nearly critical density amplitude invalidates a single-phase reduction even if the uniform five-dimensional block is positive.

Let $\Delta_h$ be the lowest dynamical energy of a mode proposed for elimination, and $\xi_h$ its static correlation length. A local low-energy elimination requires external scales $\varepsilon\ll\Delta_h$ and $k\xi_h\ll1$. The inequality $k_BT\ll\Delta_h$ is a sufficient condition for freezing its thermal occupation, not a necessary condition for integrating it out: thermally occupied modes with finite short correlation lengths can instead generate temperature-dependent coefficients. Raw eigenvalues of an arbitrarily normalized static Hessian must not be compared with temperature as though they were excitation energies. The output should identify retained modes, eliminated modes, their scales and the momentum range of the proposed phase theory. Local stability must also be distinguished from a comparison with competing phases.

**Angular gradients and higher harmonics.** Compute the relaxed tensor $\rho_{\mu\nu}(\phi,T)$ across the full orbit from a constrained small-amplitude spatial response, and compute the angular free energy $f_>(\phi,T)$ after eliminating the chosen fast modes. The zero-temperature calculation already provides part of this starting point. At finite temperature, a harmonic contribution contains $k_BT\sum\ln[1-\exp(-\varepsilon/k_BT)]$ as well as the properly normalized vacuum energy. Low-energy phase modes retained for the subsequent RG must not also be integrated out in this matching step. The matching cutoff and energy normalization must be recorded.

Define unrestricted Fourier coefficients before imposing the expected symmetry. For the uniform Y potential, write

$$
f_>(\phi,T)=f_0(T)-\sum_{n=6,12,\ldots}
\lambda_n(T)\cos[n\phi-\delta_n(T)].
$$ {#eq-nbcp-matching-harmonics}

Forbidden harmonics provide symmetry and numerical diagnostics. Increase the momentum mesh and angular resolution until the retained coefficients and their uncertainties stabilize. Compare the contribution of the higher harmonics to both the energy and its curvature, which weights the $n$th amplitude by $n^2$. A small $\lambda_{12}/\lambda_6$ alone is not a complete truncation test. Fourier-resolve the angle-dependent gradient tensor as well, then compare the truncated and extended effective theories under RG or finite-size statistical calculations. Their predictions should be stable against adding harmonics and changing the matching scale within an overlap region. The normal-ordered Gaussian power counting given above supplies the weak-coupling expectation for derivative terms; it does not replace this matching.

**Density walls and composite defects.** Keep the three translation-related density domains as explicit boundary data. In a long strip, impose different density domains on the two sides, vary the transverse phase difference $\Delta\phi$, and relax all spin directions, including local canting and density amplitude. The excess energy per wall length estimates a classical wall tension. At finite temperature the required quantity is instead the excess constrained free energy,

$$
\sigma(T,\Delta\phi)=\lim_{L_\parallel\to\infty}
\frac{F_{\rm wall}(T,\Delta\phi)-F_{\rm bulk}(T)}{L_\parallel}.
$$ {#eq-nbcp-matching-wall-tension}

Boundary contributions must be subtracted consistently; a periodic construction generally contains two walls and requires that factor to be removed. Determine whether the density wall favors a nonzero phase offset, whether it becomes soft, and whether its junctions bind phase winding. A wall between density translation domains is not automatically the same object as a wall between neighboring sixfold angular minima.

To measure defect binding and confinement, constrain a defect pair at separation $R$ and compare its relaxed energy or free energy with isolated walls and vortex pairs. A useful diagnostic form, where a phase-only description holds away from the cores, is

$$
F_{\rm pair}(R)-F_{\rm bulk}
\simeq 2F_{\rm core}
+2\pi\rho_{\rm eff}q^2\ln(R/a_0)+\sigma_{\rm string}R.
$$ {#eq-nbcp-matching-defect-pair}

The core positions are held fixed here; translational entropy is assigned later through the defect fugacity. The winding $q$ and any confining string must be derived from the full density-plus-phase order parameter and its boundary conditions. Fractional vortices must not be assumed to be allowed or deconfined. If a smaller winding is found to be deconfined, its Gaussian fugacity eigenvalue is $2-\pi Kq^2$, and the integer-vortex clock criterion must be revised. A bound composite defect can instead renormalize core weights without changing the smallest asymptotically free winding.

**Matching and testing the RG trajectory.** At a common cutoff $a_0$, determine the smooth stiffness, angular potential and core free energies in the same approximation and thermal ensemble. For a constant positive tensor and unit vortices the initial variables are

$$
K_0(T)=\frac{\sqrt{\det\rho_0(T)}}{k_BT},\qquad
y_{n,0}(T)=\frac{a_0^2\lambda_n(T)}{a_{\rm spin}k_BT},\qquad
y_{v,0}(T)=A_{\rm core}(T)e^{-F_{\rm core}(T)/(k_BT)}.
$$ {#eq-nbcp-matching-rg-inputs}

The core prefactor depends on the matching convention. The stiffness here is the coefficient at the matching scale, not an already fully renormalized thermodynamic stiffness to which the same vortex corrections can be added again. Propagate these inputs and their uncertainties through the coupled flow, including additional operators if the earlier tests retain them. A weak-coupling RG is useful only while its fugacities remain small. If they are large initially, a nonperturbative statistical calculation of the matched model is needed. An inferred algebraic regime should survive changes of matching cutoff and truncation rather than appearing only for a particular initial guess.

Finally test the thermal theory on increasing sizes. The target observations are transverse correlations $G_\perp(r)\propto r^{-\eta}$, loss of sixfold locking in the long-distance phase distribution, a finite appropriately defined phase stiffness, and persistent longitudinal density order. For the simple sixfold scenario the algebraic exponent lies between $1/9$ and $1/4$, with substantial finite-size corrections near the boundaries. The phase-locking diagnostic can be defined as $W_6(L)=\langle\cos[6\arg\Psi-\delta_6]\rangle$, where $\Psi$ is the transverse order parameter projected onto the chosen Y ordering pattern. Its size dependence, together with correlations and density-order observables, is more informative than observing six minima in a zero-temperature energy plot.

The efficient order is spectrum and mode separation, then angular matching, then real-space defects, followed by the thermal flow and size scaling. A classical spin simulation tests a classical approximation; a simulation of the matched phase theory tests the matching assumptions. Neither alone constitutes a calculation of the full $S=1/2$ quantum magnet. Quantitative quantum conclusions require a controlled assessment of the semiclassical error or an independent quantum thermal method with spatial-size convergence. The four angular panels in @fig-yv-orbit complete only the zero-temperature potential comparison, not these thermal tests.

# Supersolidity in the Y Phase {#sec-nbcp-y-phase .newpage}

The Y analysis tests the conditions of @sec-nbcp-clock-matching-tests at a representative field of 0.2 T. Its classical spatial stiffness and leading quantum angular potential come from different orders of approximation. The local matching, nonlinear checks and remaining thermal questions are therefore reported separately.

## Classical stiffness and its microscopic reduction

The zero-SOC derivation in @sec-nbcp-y-stiffness fixes the phase normalization, conjugate response and area factors. The SOC extension in @sec-nbcp-y-soc-conditions integrates out the five nonphase uniform coordinates and includes their momentum-dependent relaxation. It supplies the local static tensor and identifies a mixed frequency-momentum term in the dynamics. These are classical coefficients; quantum gradient and finite-temperature corrections have not been computed.

## Full-zone stability of the Y orbit {#sec-nbcp-y-full-zone-stability}

At $B=0.2$ T, the sampled classical Y backgrounds have no detected finite-momentum harmonic instability for the seven SOC pairs in the table below. This is a local stability result for the nearest-neighbor model with $S=1/2$, $J=0.075$ meV and $J_z=0.125$ meV. The SOC coefficients are test parameters, not material estimates. The calculation examines quadratic fluctuations about a stationary Y configuration; it does not compare its energy with a distant competing minimum.

The independent Cartesian Hessian $\mathcal K(\mathbf k)$ acts on dimensionless orthonormal spin tangents $(x_A,x_B,x_C,y_A,y_B,y_C)$. Its ordered eigenvalues $\lambda_1\leq\cdots\leq\lambda_6$ measure energy curvature per magnetic cell, not excitation energy. For the local Holstein--Primakoff coordinates, the change to the Nambu basis is

$$
\mathcal H_{\rm BdG}(\mathbf k)
=\mathsf T^\dagger\mathcal K(\mathbf k)\mathsf T,
\qquad
\mathsf T=\frac{1}{\sqrt{2S}}
\begin{pmatrix} I_3&I_3\\-iI_3&iI_3\end{pmatrix}.
$$ {#eq-nbcp-y-tangent-bdg-check}

This relation checks the complete matrix, including anomalous terms. The independently assembled matrix and the current bosonic Hamiltonian agree within $4.2\times10^{-17}$ meV at the tested momenta. The archived anomalous-block discrepancy remains visible with SOC and is not used to define acceptance. The dynamical energies are obtained independently as the eigenvalues of $i\Pi\mathcal K$, with the spin Poisson matrix $\Pi$ defined by the tangent coordinates. Both a negative static eigenvalue and a nonreal dynamical eigenvalue are inspected: real frequencies alone would not establish an energy minimum.

The momentum grids contain $24^2$, $48^2$ and $96^2$ points on a complete magnetic reciprocal primitive cell and include $\mathbf k=0$. Twelve background angles, separated by $5^\circ$, cover one $60^\circ$ symmetry sector. Equality of the full static spectral sets under a $60^\circ$ orbit shift is separately checked. Four previously resolved zero-point minima on the individual SOC axes are also examined at their saved angles, giving 88 backgrounds and 1,064,448 mesh evaluations. These selected angles refer to the leading semiclassical potential on the classical orbit; the hard coordinates have not been reoptimized with the quantum energy. Several starting points near low mesh values are used to refine the static minima and the second ordered dynamical energy continuously in momentum.

| $J_{\rm PD}$ (meV) | $J_\Gamma$ (meV) | Smallest sampled stiffness eigenvalue (meV) | Refined minimum of $\lambda_2$ (meV/cell) |
|---:|---:|---:|---:|
| 0 | 0 | 0.00382336 | 0.02009477 |
| 0.005 | 0 | 0.00316691 | 0.02009477 |
| 0 | 0.005 | 0.00381699 | 0.02009477 |
| 0.005 | 0.005 | 0.00316054 | 0.02009477 |
| 0.010 | 0 | 0.00170734 | 0.02009477 |
| 0 | 0.010 | 0.00379787 | 0.02009477 |
| 0.010 | 0.010 | 0.00168185 | 0.02009477 |

Each table entry is the minimum over the background angles tested for that SOC pair. The minimum of $\lambda_2$ occurs at the uniform point within numerical precision, where the SOC contribution cancels. The lowest curvature instead reaches the expected phase zero mode. Its most negative refined value is of order $-5\times10^{-17}$ meV/cell, well inside the chosen $10^{-10}$ meV/cell numerical threshold. No additional static zero eigenvalue is detected. Away from the origin, the largest imaginary dynamical component is below $7.2\times10^{-16}$ meV. At the origin, the defective soft dynamical pair produces imaginary roundoff of order $3\times10^{-9}$ meV; the exact static nullity and the known phase tangent identify this as the harmonic phase mode. No onsite shift or artificial pinning is introduced. The static and imaginary-frequency thresholds are adjustable numerical diagnostics, not rigorous error bounds or physical degeneracy scales.

To check mode character near the origin, define the normalized global-phase tangent $\widehat g=g/\lVert g\rVert$ and the projector onto the lowest static eigenvector. Along twelve directions and six radii $0.001\leq ka\leq0.1$, its squared overlap with $\widehat g$ exceeds $0.9971$, and the overlap between successive projectors exceeds $0.9995$. The mode connected to the uniform phase therefore remains identifiable on this sampled small-momentum domain. The second ordered positive dynamical energy remains about $0.104$ meV. It is an excitation-count diagnostic; it is not a globally tracked hard branch through every possible crossing, nor should the static value $0.0201$ meV/cell be substituted for it in a thermal occupation factor.

![Full-zone harmonic screen of Y at 0.2 T. Left: the smaller eigenvalue of the relaxed classical stiffness tensor. Center: the refined second static eigenvalue, whose minimum is uniform and independent of these SOC pairs within numerical precision. Right: the refined minimum of the second ordered nonnegative dynamical energy. Refinement is numerical and does not give certified lower bounds. No quantum gap or thermal coefficient is included.](../../data-space/verification/260917-y-stability/y-stability-screen.png){#fig-nbcp-y-stability}

The result supports using a single phase as the candidate long-wavelength coordinate at these parameter points. Finite grids, finite angular sampling and local minimum searches do not prove stability for every momentum and parameter. In particular, the test has not established a thermodynamic phase boundary, a hard-mode correlation length, the absence of competing density domains, or a finite-temperature algebraic phase. The angular matching below retains the observed angle dependence of the gradient tensor and assesses it together with the higher harmonics of the angular potential.

## Angular matching of Y stiffness and potential {#sec-nbcp-y-angular-matching}

The angular matching at $B=0.2$ T separates two approximations: replacing the classical tensor $\rho(\phi)$ by a constant, and retaining only the sixth harmonic of the leading vacuum energy. These approximations have different accuracies. At $J_{\rm PD}=0.010$ meV, freezing the gradient coefficient produces a much larger error than truncating the potential to its sixth harmonic. The calculation uses the same seven SOC pairs as the harmonic screen, the fixed classical Y orbit and the static elimination in @eq-nbcp-y-soc-static-schur. No quantum relaxation of the five hard coordinates or quantum gradient correction is included.

**The tensor over the complete phase circle.** The tensor is evaluated on successively refined uniform grids of 72, 144, 288 and 576 angles over $2\pi$. Its Cartesian components contain second and fourth harmonics. In the chosen spatial axes, their numerical representation is

$$
\begin{aligned}
\rho(\phi)&=\bar\rho I_2+
\begin{pmatrix}\operatorname{Re}z(\phi)&\operatorname{Im}z(\phi)\\
\operatorname{Im}z(\phi)&-\operatorname{Re}z(\phi)\end{pmatrix},\\
z(\phi)&=-r_2 e^{2i\phi}+r_4 e^{-4i\phi},\qquad
\langle\rho(\phi)\rangle_\phi=\bar\rho I_2.
\end{aligned}
$$ {#eq-nbcp-y-angular-tensor}

Here $r_2,r_4$ and $\bar\rho$ have units of meV and depend on the couplings and field; $r_2,r_4$ are nonnegative at the positive SOC values tested here. This is a representation of the calculated classical coefficient at this field, not a fit for arbitrary field or a thermal stiffness. For pure PD at 0.010 meV, $(\bar\rho,r_2,r_4)=(0.0024436903,0.0005097814,0.0002265658)$ meV. For pure Gamma at 0.010 meV, these become $(0.0038106162,0.0000127445,0)$ meV. With both couplings equal to 0.010 meV, they are $(0.0024309458,0.0005225260,0.0002265658)$ meV.

The second and fourth component harmonics respect tensor covariance. If $R$ rotates the spatial axes by $\pi/3$, then $\rho(\phi+\pi/3)=R\rho(\phi)R^{\mathsf T}$. Thus the scalar sixfold selection rule must not be imposed separately on $\rho_{xx}$, $\rho_{xy}$ and $\rho_{yy}$. The eigenvalues, determinant and principal directions follow as

$$
\begin{aligned}
\rho_\pm(\phi)&=\bar\rho\pm\sqrt{r_2^2+r_4^2-2r_2r_4\cos6\phi},\\
\det\rho(\phi)&=\bar\rho^2-r_2^2-r_4^2+2r_2r_4\cos6\phi,\\
\vartheta_+(\phi)&=\tfrac12\arg z(\phi)\pmod\pi.
\end{aligned}
$$ {#eq-nbcp-y-angular-invariants}

The last angle is the direction of the larger eigenvalue and is undefined for an isotropic tensor. On the pure-Gamma axis, both eigenvalues and the determinant are constant, but their principal axes rotate with $\phi$. A constant $\sqrt{\det\rho}$ therefore does not imply a constant tensor over the compact phase circle. The area-preserving coordinate change used below for a fixed tensor cannot remove this phase-dependent rotation by one global spatial transformation.

To quantify the constant approximation, choose the angular mean $\rho_{\rm c}=\bar\rho I_2$ and compare directional gradient energies relative to the full tensor:

$$
\epsilon_\rho=\max_{\phi,\,\widehat{\mathbf q}}
\frac{\left|\widehat{\mathbf q}^{\mathsf T}
[\rho_{\rm c}-\rho(\phi)]\widehat{\mathbf q}\right|}
{\widehat{\mathbf q}^{\mathsf T}\rho(\phi)\widehat{\mathbf q}}.
$$ {#eq-nbcp-y-angular-gradient-error}

The angular maximum is sampled; the directional maximum at each angle is obtained from the eigenvalues of $\rho^{-1/2}(\rho_{\rm c}-\rho)\rho^{-1/2}$. This specifies an approximation and its error rather than an optimized or renormalized matching prescription. Freezing the tensor at $\phi=0$ instead gives larger whole-orbit errors: about 59.7% for pure PD at 0.010 meV and 62.1% for the equal mixed case.

| $J_{\rm PD}$ (meV) | $J_\Gamma$ (meV) | $\bar\rho$ (meV) | Range of $\sqrt{\det\rho}$ (meV) | $\epsilon_\rho$ |
|---:|---:|---:|:---|---:|
| 0 | 0 | 0.00382336 | 0.00382336 | 0 |
| 0.005 | 0 | 0.00347844 | 0.00346446--0.00347279 | 9.84% |
| 0 | 0.005 | 0.00382017 | 0.00382017 | 0.0835% |
| 0.005 | 0.005 | 0.00347526 | 0.00346098--0.00346941 | 9.96% |
| 0.010 | 0 | 0.00244369 | 0.00233011--0.00242722 | 43.13% |
| 0 | 0.010 | 0.00381062 | 0.00381059 | 0.3356% |
| 0.010 | 0.010 | 0.00243095 | 0.00231265--0.00241286 | 44.54% |

**The angular potential and curvature.** The classical energy is constant along this orbit. Its leading angular potential is therefore the zero-point contribution $e_{\rm zp}(\phi)$ per physical spin. Fourier coefficients are extracted over the full circle before discarding any harmonics:

$$
\begin{aligned}
v(\phi)&=e_{\rm zp}(\phi)-\langle e_{\rm zp}\rangle_\phi
=\sum_{n\geq1}[a_n\cos(n\phi)+b_n\sin(n\phi)],\\
\lambda_n&=\sqrt{a_n^2+b_n^2},\qquad
v_6(\phi)=a_6\cos6\phi+b_6\sin6\phi,\\
C_\phi=v''(\phi_*)&=-\sum_{n\geq1}n^2
[a_n\cos(n\phi_*)+b_n\sin(n\phi_*)].
\end{aligned}
$$ {#eq-nbcp-y-angular-potential}

The coefficients and $C_\phi$ are in meV/spin; the continuum potential density is $v/a_{\rm spin}$. The factor $n^2$ explains why a small energy harmonic can have a larger effect on local pinning. For a pure sixth harmonic, the minimum curvature is $36\lambda_6$. We compare that value with the curvature of the resolved multi-harmonic potential at its minimum, and separately define the energy error $\epsilon_E=\max_\phi|v-v_6|/\lambda_6$. Neither diagnostic contains a quantum correction to the spatial stiffness.

The saved current-Hamiltonian scans on the individual SOC axes are reused at $N=12,24,48$ and 72 angles. At $N=48$, adding the interleaved angles gives 144 samples. Full-circle mixed-SOC scans are computed separately at $N=24,48$; they are not obtained by adding the two pure-axis energies. All six nonzero cases are checked at $N=96$ with 72 angles. Each momentum quadrature uses the reciprocal-cell midpoint grid and six rotated copies, avoiding the defective zero-frequency point without an onsite shift. This preserves the lattice symmetry of the quadrature; the Fourier extraction itself imposes no sixfold selection rule. Spectral covariance is also checked at fresh, unaveraged momenta.

The finest momentum-grid estimates are:

| $J_{\rm PD}$ (meV) | $J_\Gamma$ (meV) | $\lambda_6$ (meV/spin) | $\lambda_{12}/\lambda_6$ | Sixth-only curvature error |
|---:|---:|---:|---:|---:|
| 0.005 | 0 | $1.187\times10^{-7}$ | $2.120\times10^{-4}$ | 0.0847% |
| 0 | 0.005 | $2.5\times10^{-14}$ | unresolved | unresolved |
| 0.005 | 0.005 | $1.259\times10^{-7}$ | $2.111\times10^{-4}$ | 0.0844% |
| 0.010 | 0 | $1.437\times10^{-6}$ | $2.885\times10^{-3}$ | 1.142% |
| 0 | 0.010 | $1.643\times10^{-12}$ | unresolved | unresolved |
| 0.010 | 0.010 | $1.670\times10^{-6}$ | $2.885\times10^{-3}$ | 1.143% |

For the pure-PD and mixed cases at 0.010 meV, $\epsilon_E$ is about 0.289%, while the sum of resolved higher-harmonic amplitudes weighted by $n^2$, divided by $36\lambda_6$, is about 1.16%. Their eighteenth-harmonic amplitude ratios are $9.54\times10^{-7}$ and $2.46\times10^{-6}$, respectively. The twelfth harmonic therefore dominates the correction to the minimum curvature at these points. The zero-SOC control retains its exact continuous symmetry and has no physical angular pinning.

Mixed SOC changes the sixth coefficient appreciably even though the pure-Gamma potential is tiny. Adding the pure-PD and pure-Gamma sixth coefficients underestimates the directly computed mixed coefficient by 5.71% at $(0.005,0.005)$ meV and 13.96% at $(0.010,0.010)$ meV, relative to the mixed result. The coexistence of the two interactions changes the vacuum spectrum; the small pure-Gamma energy alone does not control this cross effect.

![Y angular matching at 0.2 T for pure PD, pure Gamma and equal mixed SOC, with each active coefficient equal to 0.010 meV. Top: the two classical stiffness eigenvalues and the square root of the determinant. Bottom: centered vacuum energies from the 144-angle N48 scans and their sixth harmonics. The pure-Gamma energy panel uses a much smaller absolute scale. Constant eigenvalues on that axis coexist with rotating principal directions. These are classical gradient and leading quantum potential coefficients, not thermal matching data.](../../data-space/verification/260918-y-angular-matching/y-angular-matching.png){#fig-nbcp-y-angular-matching fig-pos="htbp"}

**Resolution and interpretation.** Increasing the tensor angular resolution from 72 to 576 changes the sampled extrema and low-order Fourier coefficients by less than $9\times10^{-19}$ meV. The tensor covariance residual is below $5\times10^{-18}$ meV; component amplitudes above fourth order are below $2\times10^{-19}$ meV. At fresh background angles and $ka=0.001$, the finite-momentum static and production paired-dispersion estimates differ from the derivative-based coefficient by at most $5.6\times10^{-7}$ and $4.7\times10^{-7}$ relatively. These are convergence checks within the same classical model.

For the potential, doubling the angular resolution changes the amplitudes below harmonic 36 by at most $1.5\times10^{-18}$ meV/spin at fixed $N=48$. The sixth coefficients in the PD-containing cases change by $2.1\times10^{-5}$--$3.7\times10^{-5}$ relatively from $N=48$ to 96. These observed differences are convergence diagnostics, not certified quadrature error bounds. The independent Cartesian-to-Nambu matrix comparison differs from the production Hamiltonian by less than $5.6\times10^{-17}$ meV, and direct dynamical eigenvalue sums reproduce the vacuum energy within $1.3\times10^{-17}$ meV/spin.

Pure-Gamma requires a separate resolution statement. An empirical coefficient floor, the larger of $100\epsilon_{\rm mach}\max|e_{\rm zp}|$ and the largest non-sixfold amplitude, is approximately $1.8\times10^{-16}$ meV/spin. It is a conservative numerical diagnostic, not an uncertainty distribution or rigorous error bound. The sixth coefficient lies above it, but the higher coefficients do not. At $J_\Gamma=0.005$ and 0.010 meV, this floor is respectively about 0.7% and 0.011% of $\lambda_6$. The smaller observed mesh changes do not justify extra physical precision. Setting unresolved coefficients to zero would make the sixth-only curvature error vanish by construction; the table therefore reports it as unresolved. Weighting a floor-sized uncertainty at every unresolved sampled harmonic by $n^2$ gives a curvature diagnostic of roughly $2.7\times10^{-12}$ meV/spin at 72 angles. This exceeds the small-Gamma sixth-harmonic curvature and is about 4.6% of the larger-Gamma value. It is deliberately conservative and does not bound the unmeasured harmonics beyond the angular Nyquist limit.

A separate five-point energy derivative at $N=96$ corroborates the resolved Fourier curvature: for the four PD-containing cases, its relative discrepancy decreases to less than $2.8\times10^{-6}$ at a step of 0.02 rad. For pure Gamma at 0.005 meV, reducing the step instead increases the discrepancy from about 0.25% to 1.9%, directly exposing cancellation noise. At 0.010 meV, steps of 0.04 and 0.02 rad give differences near $3\times10^{-5}$. These comparisons support the leading signal without resolving the tiny higher harmonics. The full dynamical spectra at 37 fresh unaveraged momenta satisfy the combined $60^\circ$ rotation to within $10^{-15}$ meV, and 49 off-grid tensor evaluations reproduce @eq-nbcp-y-angular-tensor within $4\times10^{-18}$ meV.

The practical result is that a sixth-harmonic potential is accurate at the percent level in local curvature for the tested PD-containing points, whereas their constant-gradient approximation can be much less accurate. Subsequent defect calculations should retain the angular tensor and at least the sixth and twelfth potential harmonics when using these microscopic inputs. On the pure-Gamma axis, a constant tensor is a much closer approximation, while the extremely weak potential demands its own numerical error assessment. This remains a mixture of classical stiffness and leading zero-point potential at $T=0$. Quantum gradient corrections, finite-temperature matching, vortex-core weights and a thermal RG trajectory are not supplied by this calculation.

## Nonlinear smooth-wave test of the Y gradient theory {#sec-nbcp-y-nonlinear-gradient}

The angular matching can be tested beyond infinitesimal spin deviations without first simulating a thermal transition. At $B=0.2$ T, consider the three pairs $(J_{\rm PD},J_\Gamma)=(0.005,0)$, $(0.010,0)$ and $(0.010,0.010)$ meV. On a periodic array of $L\times L$ magnetic cells, prescribe the phase of the transverse staggered component and relax the other five coordinates in every cell:

$$
\arg(n^+_{A,\mathbf R}-n^+_{B,\mathbf R})
=\phi_{\mathbf R}=\phi_0+A\cos(\mathbf q\cdot\mathbf R),
\qquad n_i^+=n_i^x+\mathrm i n_i^y.
$$ {#eq-nbcp-y-nonlinear-phase}

Here $\mathbf n_i$ are unit spins. Each spin is parameterized as $\mathbf n_i=\mathbf n_i^{(0)}\sqrt{1-x_i^2-y_i^2}+\mathbf e_{1i}x_i+\mathbf e_{2i}y_i$, with the background and tangent frame rotated by the prescribed cell phase. The five-coordinate chart imposes $y_A=y_B$; it preserves the staggered phase exactly while allowing independent polar deviations and the remaining transverse motions. The calculation minimizes the full classical exchange and field energy, rather than its quadratic expansion. Coordinate bounds keep the positive-root chart regular, but none is active in the final configurations. This is a search for constrained local minima within the Y branch, not for competing density domains or global minima.

The comparison uses $\phi_0=0,\pi/6$, amplitudes $A=0.02,0.2,0.5,1$ rad and $L=8,16,32,64$, with an additional $L=128$ refinement at $A=0.02,1$. Reciprocal-cell modes $(1,1)$ and $(1,-1)$ give waves along the numerical Cartesian axes, with wavelengths $3La/2$ and $\sqrt{3}La/2$, respectively. There are 216 cases; the largest contains 49,152 spins. No zero-point pinning potential or thermal correction is added.

The continuum energy per spin predicted by the previously matched tensor is

$$
\Delta e_{\rm cont}=\frac{a_{\rm spin}A^2}{2}
\int_0^{2\pi}\frac{dt}{2\pi}\sin^2t\,
\mathbf q^{\mathsf T}\rho(\phi_0+A\cos t)\mathbf q,
\qquad a_{\rm spin}=\frac{\sqrt{3}a^2}{2}.
$$ {#eq-nbcp-y-nonlinear-energy}

Keeping $\rho(\phi_0)$ fixed instead gives a separate diagnostic of the error caused by discarding its angular dependence. The table reports the largest absolute relative energy error over the three SOC pairs, two directions and two background angles, with the relaxed lattice energy as denominator.

All four amplitudes have errors below 1% at $L=64$, where the wavelengths are approximately $55a$ and $96a$. At $A=1$, the error falls further to 0.24% at $L=128$, while the frozen-tensor error remains about 10%. The relaxed internal deviations also decrease with wavelength. These observations support the leading, angle-dependent classical gradient energy for the sampled smooth configurations, including finite phase excursions. The 1% observation is not a universal wavelength cutoff.

| $L$ | Full $\rho(\phi)$, $A=0.02$ | Full $\rho(\phi)$, $A=1$ | Frozen $\rho(\phi_0)$, $A=1$ |
|---:|---:|---:|---:|
| 8 | 16.05% | 14.45% | 20.80% |
| 16 | 6.89% | 7.28% | 14.55% |
| 32 | 2.06% | 3.04% | 11.38% |
| 64 | 0.54% | 0.90% | 10.34% |
| 128 | 0.14% | 0.24% | 10.06% |

![Nonlinear classical smooth-wave comparison at 0.2 T. Each curve shows a maximum over the tested SOC pairs, directions and background angles. Left: energy error with the full angular tensor. Center: error with the tensor frozen at the background angle. Right: the largest relaxed tangent displacement from the local Y orbit. Increasing L increases the wavelength; it is not a thermal finite-size scaling study. Only the smallest and largest amplitudes were continued to L=128.](../../data-space/verification/260918-y-nonlinear-gradient/nonlinear-gradient-convergence.png){#fig-nbcp-y-nonlinear-gradient fig-pos="htbp"}

**Constraint matching and numerical checks.** A phase attached to a magnetic cell differs at finite momentum from the physical-site Fourier convention used in the earlier kernel. The harmonic comparison therefore transforms that kernel with $K_{\rm cell}=UKU^\dagger$, where $U$ contains $e^{\mathrm i\mathbf q\cdot\mathbf r_i}$ on both tangent blocks, before eliminating the same five constrained coordinates. At $A=5\times10^{-4}$ rad, the full lattice energy agrees with this finite-momentum harmonic prediction to within $5.9\times10^{-7}$ relatively. Thus the continuum discrepancy contains finite-gradient and cell-coordinate corrections as well as finite-amplitude effects; it should not all be labeled a nonlinear interaction correction.

An explicit bond enumeration agrees with the vectorized energy within $5.3\times10^{-17}$ meV, and a directional finite-difference check of the analytic gradient has a discrepancy below $5.6\times10^{-11}$ under the diagnostic's normalization. Across the main scan, the largest residual gradient is $1.9\times10^{-9}$ meV, and spin-length and phase-constraint residuals are below $3\times10^{-16}$. Two random all-cell perturbations at $L=32$, $A=1$, $\phi_0=\pi/6$ in the second direction return the same energy within $10^{-18}$ meV/spin for each SOC pair. Doubling the torus at fixed wavelength in a separate $A=0.5$ check changes the relaxed energy by less than $1.6\times10^{-18}$ meV/spin. These are local convergence checks, not proofs of a global minimum.

The scan and numerical checks took 40.6 s with a peak process RSS of 165 MiB on the tested Apple M1 machine with 8 GB memory, before figure and document generation. Nonlinear classical relaxation at these sizes is therefore feasible on this computer. The present evidence concerns only the smooth gradient sector of a local Y description. This smooth-wave test supplies no density-wall or vortex-core energies, statistical weights, quantum gradient corrections or temperature-dependent matching. In particular, the convergence at long wavelengths does not establish a continuum description for a defect whose core spans only a few lattice spacings, nor does it validate the clock RG trajectory of the quantum magnet.

## Classical walls between Y density domains {#sec-nbcp-y-density-wall}

A density wall changes which sublattice carries the downward spin of the Y state. It therefore leaves the local chart of a single density domain used in the smooth-wave test. At $B=0.2$ T, the full classical spin energy is minimized on a periodic array of $L\times W$ magnetic cells. Two adjacent layers near cell coordinate zero are fixed to the reference Y state; two layers halfway around the torus are fixed to its cyclic sublattice permutation followed by a common spin rotation through $\Delta\phi$. Every other spin can move on the full unit sphere. These boundary data create two interfaces without open surfaces. The reported energy per interface length is

$$
\bar\sigma_{L,W}(\Delta\phi)
=\frac{E_{\rm constrained}-E_{\rm uniform}}{2\ell_\parallel},
\qquad \ell_\parallel=\sqrt{3}Wa,
\qquad d_{\rm walls}=\frac{3La}{4}.
$$ {#eq-nbcp-y-density-wall-energy}

The two interfaces need not have identical microscopic cores, so $\bar\sigma$ is their average. The fixed slabs also impose phase twists at finite separation. Thus it is a finite-system excess energy, not an isolated-wall free energy. No quantum angular potential is added. The translated uniform domains have equal energies and vanishing torques to numerical precision in this construction.

The initial scan uses $L=32,64,128$, $W=1$ and eight equally spaced offsets over $2\pi$ for each of four SOC pairs. For the lowest sampled branch at $L=128$, additional calculations vary the initial wall width and random spin perturbations, increase $W$ to 4, 8 and 16, and increase $L$ to 256 and 512. The other translated domain and the second magnetic-lattice strip orientation are also sampled. Broad phase-twist starts test metastability at the opposite pinned offset; starts containing the third density domain test a possible splitting of the interface. Altogether 164 relaxed configurations are saved, in addition to auxiliary reference solves.

| $(J_{\rm PD},J_\Gamma)$ (meV) | $\bar\sigma_{512,1}$ (meV/$a$) | Change from $L=256$ | Density width ($a$) |
|---|---:|---:|---:|
| $(0,0)$ | 0.017505 | 0.066% | 3.09 |
| $(0.005,0)$ | 0.015691 | 0.081% | 3.46 |
| $(0.010,0)$ | 0.013461 | 0.066% | 3.80 |
| $(0.010,0.010)$ | 0.011646 | 0.198% | 3.32 |

These are the lower tested branches at the largest separation, not certified global minima or extrapolated tensions. The last-size changes are convergence diagnostics rather than error bounds. To specify the width without assuming a continuum wall shape, define $\mathbf m_l=W^{-1}\sum_w(n^z_{l,w,A},n^z_{l,w,B},n^z_{l,w,C})$ and $s_l=|\mathbf m_{l+1}-\mathbf m_l|$. The table uses the participation width $w_\rho=(3a/2)(\sum_l s_l)^2/(2\sum_l s_l^2)$, with the factor two accounting for the two principal interfaces. It measures the spread of the density change, not a fitted correlation length.

![Classical Y density-wall diagnostics at 0.2 T. Top left: lowest sampled excess energy at each size, with increasing wall separation toward the left. Top right: the direct eight-offset scan at L=128; crosses show additional starts with a broad phase twist. Bottom left: the magnitude of the three-sublattice longitudinal density order in each magnetic cell, normalized by its bulk value, showing both interfaces. Bottom right: the mixed-SOC sublattice profile near the core with the strongest density suppression. The two microscopic cores can differ. All results are constrained classical local minima.](../../data-space/verification/260918-y-density-wall/density-wall-diagnostic.png){#fig-nbcp-y-density-wall fig-pos="htbp"}

For the selected $L=128$ branches, increasing the transverse period from one to sixteen magnetic cells after random all-spin perturbations changes the tension by less than $2\times10^{-13}$ meV/$a$. The residual variation along the wall is below $1.2\times10^{-6}$ in unit-spin components. This supports local stability of these straight walls against the sampled transverse perturbations; it does not exclude another modulated wall. Multiple direct starts agree closely on the lower branch but also reveal nearby higher minima. A third density domain in the initial cores remains as a more costly multi-interface configuration, with roughly twice the excess energy of the lower two-interface branch. Its energy divided by two interface lengths is not an elementary-wall tension.

The imposed phase difference requires particular care. For pure PD at 0.010 meV and $L=512$, direct interpolation at $\Delta\phi=\pi$ gives approximately 0.014254 meV/$a$, while placing the phase offset in a broad twist before relaxation lowers it to 0.013516 meV/$a$. The lower $\Delta\phi=0$ branch is 0.013461 meV/$a$. Therefore the direct phase-offset curve includes metastability and finite-length twist costs. It does not determine a unique intrinsic phase jump or a fractional vortex charge bound to a wall.

The wall cores are only a few lattice spacings wide. Their structure must be resolved microscopically even though the smooth long-wavelength phase energy is accurately matched. The cell-defined density amplitude $|\sum_\alpha n^z_\alpha e^{2\pi\mathrm i\alpha/3}|$, with $\alpha=0,1,2$, can be reduced substantially inside a core; its minimum relative to the bulk is about 0.39 in the mixed-SOC example. This local, cell-dependent diagnostic is not a measurement of thermal loss of density order.

The analytic energy gradient agrees with a directional finite difference to $1.8\times10^{-10}$ relatively, and explicit bond enumeration checks the periodic energy independently. All saved configurations have projected spin forces below $2.2\times10^{-8}$ meV. The main scan took 14.3 s, with peak process RSS 95 MiB, and the refinement run took 58.6 s on the same computer; the largest transverse test contains 6,144 spins. The positive, weakly size-dependent excess energies support a finite classical cost for the tested walls. Since these are variational local minima, their positivity alone is not a lower-bound proof for all walls. Neither an ordering temperature nor persistence of density order over a clock critical phase follows from this calculation. Vortex cores, wall-vortex composites and finite-temperature free energies remain necessary tests.

## What the SOC Y results establish about clock RG {#sec-nbcp-y-rg-status}

The existing Y calculations are compatible with a sixfold clock description, but they have not established the finite-temperature RG trajectory of NBCP. The distinction can be made separately for the potential, spatial gradients and dynamics.

For the chosen Y domain, the combined lattice-spin $S_6$ operation exchanges the two oppositely canted sublattices and shifts the global angle by $\pi/3$. It therefore constrains the uniform effective potential to $v_Y(\phi+\pi/3)=v_Y(\phi)$, including when $J_\Gamma\ne0$. This is the symmetry action described in [Park et al., Sec. II](https://arxiv.org/html/2601.20963v1). It is not a spin-only $\pi$ symmetry of the Gamma Hamiltonian. Expanding a periodic potential in Fourier components leaves only $n\in6\mathbb Z$, so a leading nonzero sixth harmonic supplies $p=6$. The saved pure-PD and pure-Gamma Y scans are consistent with this selection rule. They determine a zero-temperature pinning coefficient, not the finite-temperature matched $y_6(T)$; the very small pure-Gamma coefficient also requires the numerical-resolution qualifications already recorded with those scans.

The positive classical tensor in @eq-nbcp-y-soc-static-schur is a necessary local input. For a *constant* tensor, spatial anisotropy alone causes no conflict with clock RG: the relevant Gaussian coefficient is $\sqrt{\det\rho}$ as derived in @sec-nbcp-clock-rg. The full-circle calculation in @sec-nbcp-y-angular-matching instead resolves rotating principal axes and, with PD, angle-dependent eigenvalues. Freezing the tensor at one angle is not a derivation of the compact phase theory over the whole circle. For weak angle-dependent gradient terms near an isotropic Gaussian theory, a normal-ordered operator $e^{\mathrm in\phi}\partial_\mu\phi\,\partial_\nu\phi$ has dimension $2+x_n$, so its linear coupling scales as $-x_n$ for $n\ne0$. This power counting explains why such weak derivative terms can be irrelevant; it does not establish their nonlinear feedback or irrelevance for the actual microscopic parameters. Symmetry-allowed potential terms generated during matching must still be retained.

The nonreciprocal energy slope is also not a contradiction of a static clock model. In @eq-nbcp-y-soc-dynamic-schur the drift enters through $\varepsilon k_\mu$, and it vanishes in the static, zero-frequency sector. Static internal-mode relaxation has already modified $C$. Integrating finite-frequency fluctuations may further renormalize the thermal coefficients, but the existence of an odd-in-$k$ dynamical term by itself changes neither the Gaussian static scaling dimension nor the symmetry-allowed clock harmonic.

A nonzero $T=0$ pseudo-Goldstone gap is likewise compatible with a possible finite-temperature algebraic window. At a minimum of a single sixth harmonic, $C_\phi=36\lambda_6$ and $\Delta_{\rm PG}^2=C_\phi/\chi_z$ characterize local pinning. In the intermediate clock regime it is the long-distance, thermally renormalized pinning that tends to zero. The zero-temperature gap is not a measurement of that finite-temperature flow, and the two-dimensional thermal RG is not a calculation of the quantum ground state.

| Question | Current evidence | Conclusion |
|:---|:---|:---|
| Is sixfold pinning allowed in SOC Y? | Combined lattice-spin symmetry; saved angular scans on the two SOC axes | Yes; a sixfold clock perturbation is consistent with this Y domain. |
| Is the smooth Y background locally rigid? | Positive hard Hessian and relaxed classical gradient tensor; full-zone numerical screen at 0.2 T | No harmonic instability detected at the sampled points; competing-phase stability remains separate. |
| Does the asymmetric magnon slope invalidate static clock RG? | Its leading additional term is proportional to frequency times momentum | No direct contradiction in the static sector. |
| Does this NBCP model enter the algebraic RG basin at finite temperature? | No matched thermal stiffness, clock amplitude or vortex core fugacity | Undetermined from the present calculations. |

A microscopic test requires $\rho_{\mu\nu}(T)$, the thermal angular free energy and $y_6(T)$, a vortex-core weight, and verification that density order survives over the proposed temperature range. A finite-size thermal calculation should then test algebraic transverse correlations, the running exponent $\eta$, clock-angle locking and helicity response together. The unresolved displacement sign must be fixed before assigning a laboratory direction to the nonreciprocal dynamics, but a global sign reversal of momentum does not decide this static thermal RG question.

## Vortices and finite-temperature tests

The smooth-wave and density-wall results constrain two parts of the effective description. Vortex-core energies, wall-vortex composites and temperature-dependent matching remain uncomputed. A thermal conclusion requires density-order observables, transverse correlations, phase locking and stiffness on increasing system sizes. The sampled classical walls cannot substitute for their constrained free energies at finite temperature.

# Supersolidity in the V Phase {#sec-nbcp-v-phase .newpage}



The pure-PD limit has an additional exact spin symmetry that changes the allowed angular anisotropy of the V state. At $J_\Gamma=0$, a common spin rotation by $\pi$ leaves the microscopic Hamiltonian invariant. Together with the threefold operation on the V orbit, this forbids a threefold pinning term and permits sixfold pinning. The saved zero-point-energy scans exhibit precisely this distinction: sixfold modulation for pure PD and threefold modulation for pure $\Gamma$.

This is a qualification of the finite-temperature argument, not a demonstration of a thermal V supersolid. A nonzero zero-temperature pseudo-Goldstone gap is compatible with an intermediate algebraic phase when the clock anisotropy is irrelevant there. Whether that phase occurs in this microscopic model also depends on its stiffness, defects and competing orders.

## The claim being examined

[Park et al., arXiv:2601.20963v1](https://arxiv.org/html/2601.20963v1#S2) use sixfold and threefold clock descriptions for Y and V, respectively, in Eqs. (3) and (4). Their thermal argument permits an intermediate BKT regime for Y and excludes it for V. The symmetry analysis in @sec-nbcp-v-symmetry distinguishes PD from $\Gamma$ through a spin-only $\pi$ rotation. The present review asks how the thermal conclusion must be scoped on the exactly $J_\Gamma=0$ axis.

The reference state, exchange conventions, fields and energy normalization are those of the [Y/V curvature note](#sec-nbcp-gap-appendix). The angular variable $\phi$ is the same physical global-$z$ rotation, with period $2\pi$. The derivation below follows one three-sublattice domain and does not identify the full manifold, including translation domains, with a single clock variable.

## The extra symmetry at zero Gamma coupling {#sec-nbcp-v-symmetry}

Under $R_z(\pi)$, the spin components transform as

$$
(\hat S^x,\hat S^y,\hat S^z)\longmapsto(-\hat S^x,-\hat S^y,\hat S^z).
$$

The XXZ terms, longitudinal Zeeman term and PD terms contain an even number of transverse spin components. Each $\Gamma$ term contains one transverse component and one longitudinal component. Consequently, rotation of every spin maps the family of Hamiltonians according to

$$
\hat U_\pi\hat H(J_{\rm PD},J_\Gamma)\hat U_\pi^\dagger
=\hat H(J_{\rm PD},-J_\Gamma).
$$

Only at $J_\Gamma=0$ is this a symmetry of the same generic PD Hamiltonian. An effective angular energy or free energy that preserves this exact microscopic symmetry must then satisfy

$$
v(\phi+\pi)=v(\phi).
$$

For the V configuration, the combined lattice-spin threefold operation preserves the equivalent pair of sublattices and shifts the orbit coordinate by $2\pi/3$, up to its sign convention. Thus

$$
v(\phi+2\pi/3)=v(\phi).
$$

Write a real angular potential as

$$
v(\phi)=v_0+\sum_{n\ge1}\bigl[a_n\cos(n\phi)+b_n\sin(n\phi)\bigr].
$$

The first symmetry requires even $n$ and the second requires $n\in3\mathbb Z$. Their intersection is $n\in6\mathbb Z$, so the leading symmetry-allowed potential on the pure-PD V branch is

$$
v_{\rm V}^{\rm PD}(\phi)
=v_0-\lambda_6\cos(6\phi-\delta_6)+\text{higher multiples of six}.
$$

This statement does not require a nonzero $\lambda_6$ at every parameter point. At the representative point below, the sixfold coefficient is nonzero. At generic nonzero $J_\Gamma$, the spin-only $\pi$ symmetry is lost and a term $-\lambda_3\cos(3\phi-\delta_3)$ is allowed. The phase offsets $\delta_p$ specify the origin of $\phi$ and do not change the harmonic order.

## Numerical evidence without a symmetry-constrained fit

The diagnostic reanalyzes the saved $T=0$ energies at $S=1/2$, $J=0.075$ meV and $J_z=0.125$ meV. The fields are $B=0.2$ T for Y and $B=1.4$ T for V. Exactly one SOC coupling is $0.010$ meV in each row. With $M=72$ uniformly spaced angles and $\bar e=M^{-1}\sum_j e_j$, the discrete coefficients are

$$
c_n=\frac{2}{M}\sum_{j=0}^{M-1}(e_j-\bar e)e^{-\mathrm i n\phi_j},
\qquad A_n=|c_n|=\sqrt{a_n^2+b_n^2}.
$$

All sampled harmonics below the Nyquist mode are evaluated. No threefold or sixfold selection rule is imposed. At base mesh $N=48$, the amplitudes are:

| Phase | Nonzero coupling | $A_3$ (meV/spin) | $A_6$ (meV/spin) | Dominant harmonic |
|---|---|---:|---:|---:|
| Y | PD | $7.19\times10^{-19}$ | $1.4367745\times10^{-6}$ | 6 |
| Y | Gamma | $1.93\times10^{-18}$ | $1.6429350\times10^{-12}$ | 6 |
| V | PD | $4.28\times10^{-19}$ | $1.0239780\times10^{-5}$ | 6 |
| V | Gamma | $7.1609759\times10^{-7}$ | $8.9632094\times10^{-11}$ | 3 |

The forbidden threefold amplitudes are at the scale of numerical noise; the exact vanishing follows from symmetry, not from declaring those fitted numbers to be zero. The same dominant harmonic is obtained from the $N=12$ and $N=24$ saved scans. For pure-PD V, the largest sampled difference $|e(\phi+\pi/3)-e(\phi)|$ is $2.35\times10^{-17}$ meV/spin or less at $N=48$. With pure $\Gamma$, that difference reaches $1.4322\times10^{-6}$ meV/spin, whereas the $2\pi/3$ shift remains invariant to numerical precision.

![The V-state zero-point energy along the common global-z orbit. Pure PD produces six minima while pure Gamma produces three. Each panel uses absolute energy differences per physical spin, with its own vertical scale; the curves are not normalized by their angular ranges.](../../data-space/verification/260916-clock-anisotropy/v-clock-anisotropy.png){#fig-nbcp-clock}

The saved Brillouin-zone quadrature includes rotated momentum copies. To check that the pure-PD result is not solely a consequence of that averaging, an additional calculation uses Cartesian Holstein-Primakoff matrices at 128 fresh, unsymmetrized momenta and $\phi=0.173$ rad. For pure-PD V, the largest matrix difference after $\phi\mapsto\phi+\pi$ is $2.87\times10^{-17}$ meV. The individual exchange matrices obey $R_z(\pi)^\mathsf T\mathsf J R_z(\pi)=\mathsf J$ exactly in floating-point arithmetic. For nonzero $\Gamma$, the corresponding test passes only after also reversing $J_\Gamma$, with a maximum matrix residual below $2.9\times10^{-17}$ meV across the four representative cases.

These checks share the existing bond geometry and state inputs. They support the stated symmetry identities; they are not an independent microscopic-model reconstruction or a finite-temperature calculation. Finite angular sampling can alias higher harmonics, so the table alone is not an all-orders Fourier theorem.

## Local gap and missing spatial matching

The V canonical response and representative zero-temperature gaps are recorded in @sec-states and @sec-results. They establish a local curvature comparison under the conditions of @sec-interpretation. The sixfold potential on the pure-PD axis changes the symmetry-based thermal question, but the V stiffness, defect weights and thermal RG initial conditions have not been matched. The Y gradient and wall results cannot be transferred to V without repeating those phase-specific calculations.

# Discussion and Conclusions {#sec-nbcp-discussion .newpage}

## Consequence for the paper and the next calculation

The threefold argument is appropriate for a generic V branch with nonzero $J_\Gamma$ and a nonvanishing threefold coefficient. It does not apply unchanged on the exactly $J_\Gamma=0$ axis. There, the pure-PD V branch has the sixfold selection rule and an intermediate algebraic phase is symmetry-allowed within the stated phase-only assumptions. This is a necessary qualification of the domain of the paper's thermal V-state conclusion; it does not establish that a microscopic V supersolid actually survives at finite temperature.

The zero-SOC Y calculation fixes a classical normalization baseline, and the SOC extension identifies internal relaxation and a mixed dynamical term. The full-zone harmonic screen at 0.2 T finds no instability for the sampled weak-SOC Y backgrounds, including the saved selected angles on the individual SOC axes. The subsequent angular matching quantifies the classical tensor variation and the leading vacuum-potential harmonics, including mixed SOC. The nonlinear smooth-wave test in @sec-nbcp-y-nonlinear-gradient further supports its classical gradient sector at long wavelength, with finite phase excursions and internal relaxation. The classical density-wall calculation in @sec-nbcp-y-density-wall resolves a finite energy cost on the tested local branches, with microscopic cores and metastable phase-offset responses. Following the current Y-first scope, the next calculation concerns vortex cores and their coupling to density walls with these distinctions retained. Its scope must separate a classical spin calculation from a phase model using the leading quantum potential. The physical displacement convention must also be resolved before assigning laboratory directions to odd-in-momentum responses. Quantum gradient corrections and the V calculation remain separate work before a general continuum theory can be assembled. A follow-up near the PD axis in V should include both threefold and sixfold pinning to study how small nonzero $J_\Gamma$ cuts off apparent algebraic behavior. Finite-size scaling or a coupled-defect analysis is still needed before assigning a thermal transition or a supersolid phase.

## Scope of the present evidence

The available results connect a microscopic nearest-neighbor Hamiltonian to local semiclassical pinning and a tested classical Y gradient sector. They also resolve density-wall profiles within constrained classical local minima. They leave open the global competition among phases, vortex and composite defects, quantum gradient corrections and thermal matching. Skyrmion and V supersolidity therefore retain the explicit evidence limits stated in their chapters.

Numerical agreement within the same Hamiltonian is evidence for implementation consistency, not an independent validation of the material model. The [physics-to-code review record](../../GOVERNMENT/Working-Pad/issue-notes/open/260918-nbcp-physics-code-review.md) maps the claims to implementation and saved checks, separates previously verified results from open convention issues, and records the next independent tests. This document remains in review.

# Pseudo-Goldstone gap: derivation and calculation {#sec-nbcp-gap-appendix .appendix .newpage}

The spin-orbit-coupling-induced pseudo-Goldstone gap in the three-sublattice Y and V states depends on two ingredients: the quantum energy curvature along a classical equal-energy orbit and the classical response conjugate to that orbit. For the nearest-neighbor model considered here, the soft coordinate is a common laboratory-$z$ rotation. Its relaxed conjugate motion is a nonuniform change of the polar angles, determined by the longitudinal susceptibility. This distinction explains why a uniform polar-angle increment in the archived calculation does not reproduce the leading-order gap.

::: {.result}
**Leading-order relation**

$$
C_\phi=\left.\frac{\partial^2 e_{\rm sw}}{\partial\phi^2}\right|_{\phi_*},
\qquad
\Delta_{\rm PG}=\hbar\omega_{\rm PG}
=\sqrt{\frac{C_\phi}{\chi_z}}.
$$ {#eq-lswt-yv-pg-gap}

Here $e_{\rm sw}$ is the energy per physical spin, $\phi_*$ is its selected angular minimum, and $\chi_z=\partial m_z/\partial h$ is evaluated along the relaxed classical branch. The reduction requires a stable background and finite classical stiffness in the other uniform modes.
:::

## Conventions at a glance {.unnumbered}

| Quantity | Meaning and normalization |
|:---|:---|
| $\phi$, $q=\phi-\phi_*$ | Common physical rotation about laboratory $z$; angles in radians |
| $\boldsymbol\vartheta$ | Signed polar-angle chart for the three sublattices |
| $m_z=(S/3)\sum_\alpha\cos\vartheta_\alpha$ | Magnetization per physical spin, in dimensionless spin units |
| $h=g_z\mu_B B$ | Zeeman energy in $-h\sum_i S_i^z$; measured in meV |
| $A$, $\mathbf w$ | Polar Hessian per three-spin cell; $w_\alpha=-S\sin\vartheta_\alpha$ |
| $C_\phi$, $\chi_z$ | Angular energy curvature per spin; susceptibility in meV$^{-1}$ |

The symbols $e$, $A$, and the sublattice labels $\alpha=A,B,C$ retain the conventions of the comparison data. In particular, $A$ is a classical polar Hessian, not the normal block of a bosonic Hamiltonian. No extra $g_z\mu_B$ or spin-length factor is appended to the gap.

**Reading route.** The classical orbit is specified first; the Berry term and constrained relaxation then determine its canonical partner. The Y and V specializations precede the numerical comparison. Implementation findings, convergence tables, and reproduction details are collected in @sec-nbcp-verification-appendix and the linked physics-to-code review record.

## Model and equal-energy orbit {#sec-orbit .newpage}

The target is the spin-orbit-coupling (SOC) induced gap of the common global-$z$ orbit in [Park et al. (2026)](https://arxiv.org/html/2601.20963v1). The internal, nonuniform zero-field XXZ mode discussed by [Lin and Shi (2025)](https://arxiv.org/html/2505.07229v1) is a different excitation. That distinction is essential when choosing the deformation used to calculate the curvature.

Only nearest-neighbor bonds are included, with $S=1/2$, $J=0.075$ meV, $J_z=0.125$ meV and $T=0$. The representative fields are $B=0.2$ T in Y and $B=1.4$ T in V, with $g_z=4.645$. The two SOC coefficients are denoted by $J_{PD}$ and $J_\Gamma$.

### Common laboratory rotation

$$
\mathbf S_\alpha(\phi)=R_z(\phi)\mathbf S_\alpha(0)
=S\begin{pmatrix}
\sin\vartheta_\alpha\cos\phi\\
\sin\vartheta_\alpha\sin\phi\\
\cos\vartheta_\alpha
\end{pmatrix},\qquad \alpha=A,B,C.
$$ {#eq-lswt-yv-pg-orbit}

The same lab-frame rotation acts on all three spins. In the signed-polar-angle chart used here, opposite transverse directions are represented by opposite signs of $\vartheta$, with a common azimuth. This is a physical spin rotation, not a rotation of a local transverse basis about a fixed spin.

For the three nearest-neighbor bond orientations, $\sum_d J_d=3\operatorname{diag}(J,J,J_z)$. Each A-B, B-C and C-A pair has all three orientations. Thus PD and Gamma cancel in the classical three-sublattice energy for every $\phi$, while they remain in the finite-momentum spin-wave Hamiltonian. This is an accidental degeneracy when SOC is nonzero. At zero SOC the same orbit is an exact U(1) symmetry and this particular gap is exactly zero.

Equal energy on this restricted manifold does not prove a global classical minimum; the finite-momentum Hessians are separately checked for stability. Unstable angular backgrounds are rejected rather than shifted.

![Angular energy for four separately activated SOC cases: Y–PD, Y–Gamma, V–PD and V–Gamma. The active coupling is 0.010 meV and the other is zero; Y uses B=0.2 T and V uses B=1.4 T. Each panel shows the current-Hamiltonian semiclassical energy difference per spin, evaluated from the zero-point component because the classical orbit energy is constant. The vertical axes use explicitly different absolute scales. Points are the saved 72-angle samples at base mesh N=48; the final point repeats the first at 360 degrees. No harmonic fit or new diagonalization is used.](../../data-space/verification/260917-clock-matching/yv-angular-energy-four-cases.png){#fig-yv-orbit fig-pos="htbp"}

## Canonical response and the gap {#sec-canonical}

The curvature relation is specialized here to the common laboratory-$z$ orbit. The following Y/V expressions are the derivation used in this comparison, rather than formulas quoted directly from the cited papers.

### Berry term and magnetization
Write $q=\phi-\phi_*$ and let $\mathbf x=\delta\boldsymbol\vartheta$ denote polar displacements from a stationary coplanar state. The spin Berry term, in a gauge differing from other common gauges by a total derivative, is $L_B=\hbar S\sum_i\cos\vartheta_i\,\dot\phi_i$. A common azimuth therefore couples to the total z magnetization. Per physical spin,

$$
\ell_B=\hbar m_z\dot q,
\qquad
p\equiv\delta m_z=\frac{\mathbf w^{\mathsf T}\mathbf x}{3},
\qquad
w_\alpha=-S\sin\vartheta_\alpha.
$$ {#eq-lswt-yv-pg-berry}

The constant equilibrium term $\hbar m_{z,0}\dot q$ does not affect the local equations of motion. The physical spin tangent of the global-z orbit is $\partial_q\mathbf S_\alpha=S\sin\vartheta_\alpha\,\mathbf e_{\phi,\alpha}$. Thus a common azimuth does not produce equal local transverse displacements. In the Y state the axial spin has zero tangent on this orbit. This statement remains regular in Cartesian tangent coordinates even though its individual azimuth is undefined at the pole.

### Relaxation at fixed magnetization

For the common-azimuth states, the classical energy per magnetic cell is

$$
E_{\rm cl}^{\rm cell}
=3S^2\sum_{(\alpha\beta)=(AB),(BC),(CA)}
\left[J\sin\vartheta_\alpha\sin\vartheta_\beta
+J_z\cos\vartheta_\alpha\cos\vartheta_\beta\right]
-hS\sum_\alpha\cos\vartheta_\alpha.
$$ {#eq-lswt-yv-pg-classical-energy}



The SOC cancellation on this uniform three-sublattice manifold is why the same expression supplies the classical hard stiffness. Assume that $A$ is positive definite and that the common-z direction is the only soft uniform mode. At fixed $p=\delta m_z$, the classical energy cost is obtained by minimizing $\mathbf x^{\mathsf T}A\mathbf x/6$ subject to $\mathbf w^{\mathsf T}\mathbf x=3p$. The stationary solution is

$$
\mathbf x_*(p)
=\frac{3A^{-1}\mathbf w}{\mathbf w^{\mathsf T}A^{-1}\mathbf w}\,p,
\qquad
\delta e_{\rm cl,min}=
\frac{3p^2}{2\mathbf w^{\mathsf T}A^{-1}\mathbf w}
=\frac{p^2}{2\chi_z}.
$$ {#eq-lswt-yv-pg-fixed-magnetization}

The same response follows without a dynamical assumption by differentiating the classical stationarity equation with respect to the Zeeman energy $h$:

$$
A\frac{d\boldsymbol\vartheta}{dh}=\mathbf w,
\qquad
\chi_z=\frac{1}{3}\mathbf w^{\mathsf T}A^{-1}\mathbf w,
\qquad
\frac{d\boldsymbol\vartheta}{dm_z}=\frac{A^{-1}\mathbf w}{\chi_z}.
$$ {#eq-lswt-yv-pg-susceptibility}

::: {.keep-together}
The quadratic effective energy per spin near the selected angle is

$$
\delta e=\frac{(\delta m_z)^2}{2\chi_z}
+\frac{C_\phi}{2}(\delta\phi)^2.
$$
:::

With the Berry term $\hbar\,\delta m_z\,\partial_t\delta\phi$, the linear equations give $\hbar^2\partial_t^2\delta\phi=-(C_\phi/\chi_z)\delta\phi$, yielding the gap in @eq-lswt-yv-pg-gap. The total Lagrangian contains the common factor $N_{\rm site}$, which cancels from the equations of motion.

### Trial directions and their stiffness

For $\mathbf x=\mathbf u\,\xi$, with a fixed trial direction $\mathbf u$, define

$$
b_{\mathbf u}=\frac{\mathbf w^{\mathsf T}\mathbf u}{3},
\qquad
\kappa_{\mathbf u}=\frac{\mathbf u^{\mathsf T}A\mathbf u}{3}.
$$ {#eq-lswt-yv-pg-trial-coordinates}

Here $A$ is the classical polar Hessian per three-spin magnetic cell, not a particle block of the spin-wave matrix. The restricted Berry term is $\hbar b_{\mathbf u}\xi\dot q$. If $b_{\mathbf u}=0$, these two coordinates do not form a canonical pair. If it is nonzero, $p_{\mathbf u}=b_{\mathbf u}\xi$ is a canonical momentum on this restricted surface, whose trial gap is

$$
\Delta_{\mathbf u}^{\,2}
=\frac{C_\phi\kappa_{\mathbf u}}{b_{\mathbf u}^{2}}.
$$ {#eq-lswt-yv-pg-trial-gap}

This is a prediction of the restricted two-coordinate model, not automatically a normal-mode frequency of the full spin system. Reversing the convention for $\xi$ or the orientation of the Berry two-form changes the sign of $b_{\mathbf u}$ but not this expression.

The condition for a trial direction to give the same leading result is stronger than $b_{\mathbf u}\ne0$. The Cauchy-Schwarz inequality in the positive $A$ metric gives

$$
(\mathbf w^{\mathsf T}\mathbf u)^2
\le (\mathbf w^{\mathsf T}A^{-1}\mathbf w)
   (\mathbf u^{\mathsf T}A\mathbf u),
\qquad
\frac{\kappa_{\mathbf u}}{b_{\mathbf u}^{2}}
\ge\frac{1}{\chi_z}.
$$ {#eq-lswt-yv-pg-stiffness-bound}

Equality holds precisely when $\mathbf u$ is proportional to $A^{-1}\mathbf w$. A correctly Berry-normalized but unrelaxed trial direction therefore overestimates the stiffness of this leading two-coordinate reduction. The bound concerns the restricted classical reduction, not an error bound on the full quantum spectrum.

## Y and V states {#sec-states}

### Y: opposite tilts of the canted spins

Use the signed chart $\boldsymbol\vartheta=(t,-t,\pi)$, with

$$
\cos t=\frac{h+3SJ_z}{3S(J+J_z)}.
$$ {#eq-lswt-yv-pg-y-state}

The old choice $\mathbf u=(1,1,1)^{\mathsf T}$ has $b_{\mathbf u}=-(S/3)(\sin t-\sin t+0)=0$. It leaves $m_z$ unchanged to first order. A nonzero classical curvature along it cannot be combined with the global-z curvature to obtain a canonical oscillation frequency.

::: {.keep-together}
Differentiating the Y branch instead gives

$$
\frac{d\boldsymbol\vartheta}{dh}
=\frac{(-1,1,0)^{\mathsf T}}{3S(J+J_z)\sin t},
\qquad
\chi_z^{Y}=\frac{2}{9(J+J_z)}.
$$ {#eq-lswt-yv-pg-y-response}
:::

For the admissible direction $\mathbf u_Y=(-1,1,0)^{\mathsf T}$, its Berry coefficient and stiffness are

$$
b_Y=\frac{2S\sin t}{3},
\qquad
\kappa_Y=2S^2(J+J_z)\sin^2t,
\qquad
\Delta_Y^2=\frac{9(J+J_z)}{2}C_\phi.
$$ {#eq-lswt-yv-pg-y-gap}

At $B=0.2$ T, $d\boldsymbol\vartheta/dh=(-5.6088836,5.6088836,0)$ meV$^{-1}$. In physical terms the two canted spins tilt oppositely and the axial spin stays fixed to first order. This is not a common polar increment. These formulas are local to the stable Y branch; approaching an additional soft mode or a collinear endpoint requires a new analysis.

### V: nonuniform response of the three spins

Write $\boldsymbol\vartheta=(t,t,v)$. Exchange symmetry between A and B implies a relaxed response $(t',t',v')$, where primes mean derivatives with respect to $h$. Define $a=A_{AA}+A_{AB}$, $b=A_{AC}$, $c=A_{CC}$ and $D=ac-2b^2$. Then

$$
\begin{pmatrix}a&b\\2b&c\end{pmatrix}
\begin{pmatrix}t'\\v'\end{pmatrix}
=-S\begin{pmatrix}\sin t\\\sin v\end{pmatrix},
$$ {#eq-lswt-yv-pg-v-system}

so that

$$
t'=-\frac{S(c\sin t-b\sin v)}{D},
\qquad
v'=-\frac{S(a\sin v-2b\sin t)}{D},
$$

$$
\chi_z^{V}=
\frac{S^2}{3D}
\left(2c\sin^2t-4b\sin t\sin v+a\sin^2v\right).
$$ {#eq-lswt-yv-pg-v-response}

The asymmetric appearance of the reduced $2\times2$ matrix reflects the two equal A/B displacements; it is not itself the Hessian in orthonormal reduced coordinates. At $B=1.4$ T the response is $(-0.2057662,-0.2057662,9.7220817)$ meV$^{-1}$ and $\chi_z^{V}=1.5509777351$ meV$^{-1}$ per spin.

For the uniform trial direction, $b_{\mathbf 1}=0.0240478049$ and $\kappa_{\mathbf 1}=0.0850517106$ meV per spin. Berry normalization is possible, but its restricted susceptibility is only $b_{\mathbf 1}^2/\kappa_{\mathbf 1}=0.0067993567$ meV$^{-1}$. Consequently its Berry-corrected trial gap would be 15.1032 times the relaxed result in the weak-pinning limit. This is not the archived code's gap ratio: that code also uses a different final normalization. The point is that fixing only that normalization still leaves the wrong hard-mode direction.

### Representative stationary states

| Phase | Sublattice | $\vartheta_\alpha$ (rad) | $d\vartheta_\alpha/dh$ (1/meV) |
|---|---|---:|---:|
| Y | A | 0.636389179 | -5.6088836 |
| Y | B | -0.636389179 | 5.6088836 |
| Y | C | 3.141592654 | 0.0 |
| V | A | 0.409364861 | -0.2057662 |
| V | B | 0.409364861 | -0.2057662 |
| V | C | -1.223629194 | 9.7220817 |

The susceptibilities per spin are $\chi_z^{Y}=1.11111111111$ meV$^{-1}$ and $\chi_z^{V}=1.55097773512$ meV$^{-1}$.

## Numerical comparison {#sec-results}

Each implementation is evaluated at its own angular minimum. This table uses fitted angular curvature; the separate legacy replay logs execute the original finite-difference formulas. Values are in meV.

| Phase | SOC | Current/resp. | Archive/resp. | Current/old | Archive/old |
|---|---|---:|---:|---:|---:|
| Y | PD | 0.00686217 | 0.0323672 | 0.000519921 | 0.00245234 |
| Y | Gamma | $7.2960\times10^{-6}$ | $3.4602\times10^{-6}$ | $5.5279\times10^{-7}$ | $2.6217\times10^{-7}$ |
| V | PD | 0.0156468 | 0.0259926 | 0.00284145 | 0.00472023 |
| V | Gamma | 0.00203898 | 0.00111472 | 0.000370278 | 0.000202433 |

The indicated SOC coefficient is 0.010 meV and the other is zero. Current/Archive identifies the quadratic Hamiltonian; resp./old identifies the susceptibility reduction or the archived uniform-theta formula. The base reciprocal mesh is $N=48$. Full-precision values remain in `scan-N48-P72.json`.

![Pseudo-Goldstone gap versus each SOC coefficient. Blue: current Hamiltonian and canonical response. Gray: current Hamiltonian and old formula. Orange: archived Hamiltonian and old formula. Shading denotes instability detected in the sampled current-Hamiltonian backgrounds; a physical gap is not assigned there.](../../data-space/verification/260912-pseudo-goldstone/yv-pseudo-gap-comparison.png){#fig-yv-gap fig-pos="htbp"}

### Cross-checks of the canonical response

The canonical response is cross-checked in both representative states without recomputing the zero-point-energy curves. Explicit Y/V formulas agree with the full $A^{-1}\mathbf w$ response. Differentiating independently relaxed field states at $\delta h=10^{-5}$ meV gives relative tangent errors below $8.0\times10^{-9}$. Nonlinear minimization at fixed magnetization approaches the derived tangent and energy cost as the displacement decreases.

For all eight sign charts in each phase, a finite-difference Hessian of the actual Cartesian bond energy agrees with the transformed analytic Hessian within $1.8\times10^{-9}$ meV; the relative susceptibility change is below $2.1\times10^{-8}$. The six-dimensional classical tangent dynamics with a weak pinning potential reproduces both the gap coefficient and the polar mode profile. Across pinning curvatures $10^{-7}$ and $10^{-9}$ meV per cell, relative frequency and mode-profile errors are below $7.3\times10^{-8}$ and $2.6\times10^{-7}$, respectively.

These checks support the local classical reduction and its normalization. They do not replace human physics review or provide an independent one-loop self-energy calculation. Several checks share the same classical energy or Hessian; their agreement is a consistency check, not a wholly independent microscopic calculation.

## Approximation and interpretation {#sec-interpretation}

### Curvature order and coordinate conventions

In [arXiv:1805.00947, Eqs. (7)-(9)](https://arxiv.org/html/1805.00947v2), the simple illustration uses equally weighted local transverse coordinates. Its prefactor $1/S$ belongs to that coordinate normalization. Here the physical global azimuth has sublattice weights $\sin\vartheta_\alpha$, so one must compute the Berry coefficient or use the magnetization coordinate directly.

The leading type-I calculation does not require a quantum mixed curvature to be identically zero. The classical energy is independent of the common azimuth, so its mixed curvature vanishes. With the usual expansion at fixed $h/S$, the hard classical curvature is $O(S^2)$ and the quantum soft and mixed curvatures are $O(S)$. The square of the quantum mixed curvature is therefore subleading in the determinant relative to the product of the classical hard and quantum soft curvatures. Near additional soft directions that ordering can fail. Thus setting the mixed term to zero is consistent with the present leading-order reduction; it is not a separately demonstrated leading-order error in the archived result.

The coordinate-relabeling check also needs a precise interpretation. Under $\vartheta_\alpha\mapsto-\vartheta_\alpha$, $\phi_\alpha\mapsto\phi_\alpha+\pi$ for selected sublattices, let $D_s$ be the diagonal sign matrix. The same physical response transforms as $A\mapsto D_sAD_s$, $\mathbf w\mapsto D_s\mathbf w$ and $\mathbf x_*\mapsto D_s\mathbf x_*$, leaving $\chi_z$ invariant. Reusing the numerical vector $(1,1,1)$ in the new chart generally chooses a different physical deformation. The old hard-curvature change diagnoses an unspecified deformation rule, not a failure of the classical energy's coordinate invariance.

### Limits of the comparison

This verifies the classical orbit, current quadratic Hamiltonian coefficients, canonical normalization and numerical curvature calculation. It is not an independent full one-loop self-energy calculation, an all-orders prediction for S=1/2, or proof of global phase stability. No finite-temperature gap is calculated. The field-induced internal XXZ branch and the zero-field internal pseudo-Goldstone mode are different modes and are not plotted here.

The shaded portions of the gap plots indicate sampled unstable spin-wave backgrounds. Missing weak-Gamma Y points indicate inadequate numerical resolution. Neither is assigned a physical zero gap. The finite-mesh minimum magnon frequency is recorded as a diagnostic and is never used as the pseudo-Goldstone gap.

A comparison with the published Figure 4 is conditional on the parameters and available local code. The exact source revision and numerical data used for the published gap curve have not been established.

# Clock RG: Derivation and Normalization {#sec-nbcp-clock-rg .newpage}



The clock criterion concerns a two-dimensional thermal phase field after short-distance and nonzero-frequency fluctuations have been integrated out. It is not an RG equation for the zero-temperature magnon energy. The assumptions are a stable density-ordered background, a compact phase $\phi\equiv\phi+2\pi$, a positive spatial stiffness, weak clock pinning and dilute integer vortices. Within these assumptions, the sixfold perturbation can be irrelevant while vortices remain bound, as in the planar-model analysis of [José et al. (1977)](https://doi.org/10.1103/PhysRevB.16.1217). The derivation below fixes the field, area and fugacity normalizations used here.

**Static normalization and constant spatial anisotropy.** Let $\mathcal T=k_{\rm B}T$, let $a_0$ be the matching cutoff of the phase theory, and take a phase-independent positive symmetric tensor $\rho$. The nearest-neighbor distance $a$, area per spin $a_{\rm spin}$ and matching cutoff $a_0$ are distinct quantities. The static free energy is

$$
F=\int d^2r\left[
\frac12(\nabla\phi)^{\mathsf T}\rho(\nabla\phi)
-\frac{\lambda_p}{a_{\rm spin}}\cos(p\phi-\delta_p)\right],
\qquad Z=\int\mathcal D\phi\,e^{-F/\mathcal T}.
$$ {#eq-nbcp-clock-partition}

Here $\lambda_p$ is a pinning energy per physical spin at the matching scale, and $p$ is an integer harmonic order, not the shorthand for $J_{\rm PD}$ used in the preceding SOC calculation. To remove constant spatial anisotropy, define $\rho_{\rm eff}=\sqrt{\det\rho}$ and make the area-preserving change of coordinates

$$
\mathbf r=L\mathbf R,\qquad
L=\frac{\rho^{1/2}}{(\det\rho)^{1/4}},\qquad
\det L=1,\qquad L^{-1}\rho L^{-\mathsf T}=\rho_{\rm eff}I_2.
$$ {#eq-nbcp-clock-anisotropy-map}

Then $d^2r=d^2R$ and the gradient energy is $\rho_{\rm eff}\int d^2R\,|\nabla_R\phi|^2/2$. For diagonal $\rho$, this means $x=(\rho_{xx}/\rho_{yy})^{1/4}X$ and $y=(\rho_{yy}/\rho_{xx})^{1/4}Y$. The microscopic cutoff shape changes under this transformation, affecting short-distance matching but not the Gaussian scaling dimensions. With dimensionless coordinates $\mathbf x=\mathbf R/a_0$,

$$
\mathcal S_0=\frac K2\int d^2x\,(\nabla\phi)^2,
\qquad
\delta\mathcal S=-y_p\int d^2x\,\cos(p\phi-\delta_p),
\qquad
K=\frac{\rho_{\rm eff}}{\mathcal T},\quad
y_p=\frac{a_0^2\lambda_p}{a_{\rm spin}\mathcal T}.
$$ {#eq-nbcp-clock-dimensionless-action}

$\mathcal S=F/\mathcal T$ is dimensionless; it is not the spin length $S$. For an isotropic tensor $\rho_{\rm eff}=\rho_s$. A tensor that depends on $\phi$ cannot be made constant everywhere by this single coordinate transformation; that limitation is relevant to SOC Y below.

**Gaussian correlation function and scaling dimension.** Use $\phi(\mathbf x)=\int d^2q\,e^{\mathrm i\mathbf q\cdot\mathbf x}\phi_{\mathbf q}/(2\pi)^2$. The Gaussian covariance follows by inverting its quadratic kernel:

$$
\mathcal S_0=\frac K2\int\frac{d^2q}{(2\pi)^2}
q^2\phi_{\mathbf q}\phi_{-\mathbf q},\qquad
\langle\phi_{\mathbf q}\phi_{\mathbf q'}\rangle_0
=\frac{(2\pi)^2\delta^{(2)}(\mathbf q+\mathbf q')}{Kq^2}.
$$ {#eq-nbcp-clock-propagator}

The zero mode cancels in the phase difference. With $R=|\mathbf R|\gg a_0$, angular integration gives

$$
\begin{aligned}
W(R)&=\langle[\phi(\mathbf R)-\phi(0)]^2\rangle_0\\
&=\frac{2}{K}\int^{1/a_0}\frac{d^2q}{(2\pi)^2}
\frac{1-\cos(\mathbf q\cdot\mathbf R)}{q^2}\\
&=\frac{1}{\pi K}\int_0^{1/a_0}\frac{dq}{q}[1-J_0(qR)]
=\frac{1}{\pi K}\ln\frac R{a_0}+O(1).
\end{aligned}
$$ {#eq-nbcp-clock-phase-variance}

The last step uses the logarithmic range $1/R\lesssim q\lesssim1/a_0$; the cutoff changes the additive constant. Gaussian averaging of a vertex operator now yields

$$
\begin{aligned}
\langle e^{\mathrm ip\phi(\mathbf R)}e^{-\mathrm ip\phi(0)}\rangle_0
&=\exp[-p^2W(R)/2]\propto(R/a_0)^{-p^2/(2\pi K)},\\
x_p&=\frac{p^2}{4\pi K},\qquad
\eta=2x_1=\frac{1}{2\pi K}.
\end{aligned}
$$ {#eq-nbcp-clock-vertex-dimension}

An operator of scaling dimension $x_p$ has a two-point function proportional to $R^{-2x_p}$. The cosine is the sum of charges $+p$ and $-p$ and has this same dimension. Its phase offset $\delta_p$ does not affect that dimension.

**Integrating a momentum shell.** Split $\phi=\phi_<+\phi_>$, with the fast modes in $\Lambda e^{-d\ell}<q<\Lambda$. Their local variance is

$$
\langle\phi_>^2\rangle_0
=\frac1K\int_{\Lambda e^{-d\ell}}^\Lambda
\frac{2\pi q\,dq}{(2\pi)^2q^2}
=\frac{d\ell}{2\pi K}.
$$ {#eq-nbcp-clock-shell-variance}

At first order in $y_p$, average the perturbation over these modes. The odd sine average vanishes and the Gaussian cosine average gives

$$
\begin{aligned}
\langle\cos[p(\phi_<+\phi_>)-\delta_p]\rangle_>
&=e^{-p^2\langle\phi_>^2\rangle_0/2}
\cos(p\phi_<-\delta_p)\\
&=e^{-p^2d\ell/(4\pi K)}\cos(p\phi_<-\delta_p).
\end{aligned}
$$ {#eq-nbcp-clock-shell-cosine}

Restore the cutoff with $\mathbf x=e^{d\ell}\mathbf x'$. The measure contributes $e^{2d\ell}$, while the Gaussian gradient action is invariant in two dimensions and the compact angle is not rescaled. Therefore

$$
y_p'=y_p\exp\left[\left(2-\frac{p^2}{4\pi K}\right)d\ell\right],
\qquad
\frac{dy_p}{d\ell}=\left(2-\frac{p^2}{4\pi K}\right)y_p+\cdots.
$$ {#eq-nbcp-clock-pinning-flow}

The two terms have different origins: $2$ is the area rescaling, and $p^2/(4\pi K)$ is the suppression by fast phase fluctuations. Treating $K$ as constant gives the exponential solution used in the paper. More generally, the linearized solution is $y_p(\ell)=y_p(0)\exp\{\int_0^\ell[2-p^2/(4\pi K(\ell'))]d\ell'\}$; it is not a fixed exponential once the stiffness flows.

**Vortex charge and fugacity.** Compactness permits a winding $\oint\nabla\phi\cdot d\mathbf l=2\pi m$, with integer $m$. Outside its core, $\phi=m\arg(X+\mathrm iY)$ and $|\nabla\phi|=|m|/R$. Hence

$$
E_m=E_{{\rm core},m}
+\frac{\rho_{\rm eff}}2\int_{a_0}^L2\pi R\,dR\,\frac{m^2}{R^2}
=E_{{\rm core},m}+\pi\rho_{\rm eff}m^2\ln(L/a_0).
$$ {#eq-nbcp-clock-vortex-energy}

A vortex position contributes a measure $d^2R/a_0^2$, or entropy $2k_{\rm B}\ln(L/a_0)$ for one defect. Its dimensionless weight therefore scales as $y_m(L/a_0)^{2-\pi Km^2}$, where $y_m$ includes the core weight and its local prefactor. This identifies $x_{v,m}=\pi Km^2$. The isolated-vortex argument extracts the scaling dimension; a periodic system has net charge zero and contains neutral vortex configurations. For charges $m=\pm1$ with fugacity $y_v$ per charge,

$$
\frac{dy_v}{d\ell}=(2-\pi K)y_v+\cdots.
$$ {#eq-nbcp-clock-vortex-flow}

Vortices are irrelevant at the Gaussian line only if $K>2/\pi$. A smooth-wave LSWT calculation cannot determine $y_v$: the vortex core involves configurations outside a small-amplitude expansion about one uniform state.

**Why the stiffness also flows.** The preceding eigenvalues are exact at the Gaussian line, but keeping $K$ fixed discards the leading feedback of defects. To display its normalization, use normal-ordered vertices at the cutoff and a real-space dipole shell $a_0<r<a_0e^{d\ell}$. Each pinning charge in $\exp[y_p\int\cos(p\phi)]$ has fugacity $y_p/2$. The neutral part of the second-order cumulant contributes

$$
\delta\mathcal S_{\rm neutral}
=-\frac{y_p^2}{4a_0^4}\int d^2R\int_{\rm shell}d^2r
\left(\frac{a_0}{r}\right)^{2x_p}
\cos\!\left[p\left(\phi(\mathbf R+\mathbf r/2)-\phi(\mathbf R-\mathbf r/2)\right)\right].
$$ {#eq-nbcp-clock-neutral-dipole}

The constant term changes the free energy. Expanding the phase difference as $\mathbf r\cdot\nabla\phi$ and the cosine as $1-p^2(\mathbf r\cdot\nabla\phi)^2/2$ gives

$$
\begin{aligned}
\int_{\rm shell}d^2r\,r_\mu r_\nu
\left(\frac{a_0}{r}\right)^{2x_p}
&=\pi a_0^4\delta_{\mu\nu}\,d\ell+O(d\ell^2),\\
\delta\mathcal S_{\rm grad}
&=\frac{\pi p^2y_p^2}{8}d\ell\int d^2R\,|\nabla\phi|^2,
\qquad
\left.\frac{dK}{d\ell}\right|_p=\frac{\pi p^2}{4}y_p^2.
\end{aligned}
$$ {#eq-nbcp-clock-electric-screening}

Pinning increases $K$ at this order. The vortex contribution can be obtained from the dual Gaussian field $\theta$. The neutral vortex gas has pair weight $\prod_{i<j}(r_{ij}/a_0)^{2\pi K m_i m_j}$, reproduced by the dual action

$$
\mathcal S_{\rm dual}
=\frac{K_d}{2}\int d^2R\,|\nabla\theta|^2
-\frac{2y_v}{a_0^2}\int d^2R\,\cos\theta,
\qquad K_d=\frac{1}{4\pi^2K}.
$$ {#eq-nbcp-clock-dual-action}

Indeed, $x_{e^{\mathrm i\theta}}=1/(4\pi K_d)=\pi K$. Applying the preceding dipole result with $p=1$ and cosine amplitude $2y_v$ gives $dK_d/d\ell=\pi y_v^2$, or $dK^{-1}/d\ell=4\pi^3y_v^2$. The dual field is an alternative representation of vortex effects, not an additional independent phase field. Combining the leading terms yields, in this dipole-fugacity convention,

$$
\begin{aligned}
\frac{dy_p}{d\ell}&=\left(2-\frac{p^2}{4\pi K}\right)y_p+\cdots,\\
\frac{dy_v}{d\ell}&=(2-\pi K)y_v+\cdots,\\
\frac{dK^{-1}}{d\ell}&=4\pi^3y_v^2-
\frac{\pi p^2}{4K^2}y_p^2+\cdots.
\end{aligned}
$$ {#eq-nbcp-clock-coupled-flow}

The quadratic coefficients require the stated fugacity normalization and cutoff convention; rescaling either fugacity changes them. The linear scaling dimensions and the opposing effects of vortex screening and pinning do not depend on that choice. Higher orders generate additional harmonics and mixed operators. The displayed equations are a dilute-defect, weak-pinning truncation, not a quantitative flow for arbitrary SOC.

The algebraic-window inequalities and their physical conditions are stated in @sec-nbcp-clock. They use the stiffness at the relevant scale and must not be converted to transition temperatures by inserting an unmatched classical coefficient.

# Classical Y Stiffness: Microscopic Derivation {#sec-nbcp-stiffness-appendix .newpage}

## Classical stiffness of the zero-SOC Y state {#sec-nbcp-y-stiffness}

A microscopic baseline can be obtained at $J_{\rm PD}=J_\Gamma=0$, fixed longitudinal field and $T=0$. The calculation below concerns the locally stable classical Y branch, with $J_z>J>0$, $0<h<3SJ$ and a positive Hessian on the remaining uniform modes. It gives the classical coefficient $\rho_s^{\rm cl}$, without its zero-point or thermal renormalization. The endpoint with additional soft modes must be treated separately.

**Bond energy and canting relaxation.**

Let $c=\cos t$, $s=\sin t=\sqrt{1-c^2}$ and choose the reference vectors $\mathbf n_A=(s,0,c)$, $\mathbf n_B=(-s,0,c)$ and $\mathbf n_C=(0,0,-1)$. A physical twist is imposed at the actual site position $\mathbf r$:

$$
\mathbf S_\alpha(\mathbf r)
=S R_z(\mathbf Q\cdot\mathbf r)\mathbf n_\alpha,
\qquad
c=\frac{h+3SJ_z}{3S(J+J_z)}.
$$ {#eq-nbcp-y-spatial-twist}

The vector $\mathbf Q$ has units of inverse length; the angle difference on a bond is $\mathbf Q\cdot\boldsymbol\delta$. It is not a common angle assigned to every site in a magnetic cell. Equivalently, periodic boundaries carry the corresponding twist. The derivative at $\mathbf Q=0$ is taken on the branch continuously connected to this Y state, rather than minimizing over different winding sectors.

Choose the oriented bond triplet $\boldsymbol\delta_d=a(1,0)$, $a(-1/2,\sqrt3/2)$ and $a(-1/2,-\sqrt3/2)$ for each cyclic sublattice pair. There are nine bonds per three-spin cell, each physical bond counted once. The triplet satisfies $\sum_d\boldsymbol\delta_d=0$ and $\sum_d\delta_{d\mu}\delta_{d\nu}=3a^2\delta_{\mu\nu}/2$. At fixed internal vectors, only the A-B bonds contribute transverse exchange. Defining

$$
\gamma(\mathbf Q)=\frac13\sum_{d=1}^3
\cos(\mathbf Q\cdot\boldsymbol\delta_d)
=1-\frac{a^2|\mathbf Q|^2}{4}
+O(a^4|\mathbf Q|^4),
$$ {#eq-nbcp-y-twist-structure-factor}

the energy per physical spin is

$$
e_Y(\mathbf Q,c)=S^2\left[
-J(1-c^2)\gamma(\mathbf Q)+J_z(c^2-2c)\right]
-\frac{hS}{3}(2c-1).
$$ {#eq-nbcp-y-twisted-energy}

The three A-B bonds contribute $S^2[-J(1-c^2)\gamma+J_zc^2]$ per spin; the three B-C and three C-A bonds each contribute $-J_zS^2c$. The division by three physical spins has already been made in each contribution. The field term follows from $S(n_A^z+n_B^z+n_C^z)=S(2c-1)$ per cell. Consequently,

$$
\begin{aligned}
\partial_c e_Y&=2S^2\{[J\gamma(\mathbf Q)+J_z]c-J_z\}
-\frac{2hS}{3},\\
c_*(\mathbf Q)&=\frac{J_z+h/(3S)}{J_z+J\gamma(\mathbf Q)}
=c_0+\frac{c_0Ja^2|\mathbf Q|^2}{4(J+J_z)}+O(|\mathbf Q|^4),
\end{aligned}
$$ {#eq-nbcp-y-canting-relaxation}

where $c_0$ is the untwisted value in @eq-nbcp-y-spatial-twist, denoted by $c$ below. Since $\partial_c e_Y(0,c_0)=0$ and $c_*-c_0=O(Q^2)$, this canting relaxation changes the energy only at $O(Q^4)$. At quadratic order the explicit $\gamma$ dependence therefore gives

$$
e_Y(\mathbf Q)-e_Y(0)
=\frac{JS^2(1-c^2)a^2}{4}|\mathbf Q|^2
+O(|\mathbf Q|^4).
$$ {#eq-nbcp-y-twist-cost}

**Regular coordinates and the full internal Hessian.**

Varying $t$ alone does not test all possible internal relaxations. Introduce orthonormal tangent vectors

$$
\begin{aligned}
\mathbf e_{\theta A}&=(c,0,-s),&
\mathbf e_{\theta B}&=(c,0,s),&
\mathbf e_{\theta C}&=(-1,0,0),\\
\mathbf e_{\varphi\alpha}&=(0,1,0),&
\mathbf n_\alpha(\boldsymbol\xi)&=
\mathbf n_\alpha\sqrt{1-x_\alpha^2-y_\alpha^2}
+\mathbf e_{\theta\alpha}x_\alpha+\mathbf e_{\varphi\alpha}y_\alpha.
\end{aligned}
$$ {#eq-nbcp-y-regular-tangents}

The variables $\boldsymbol\xi=(x_A,x_B,x_C,y_A,y_B,y_C)^{\mathsf T}$ are dimensionless transverse components. In particular, $y_C$ is a regular Cartesian component, not the singular azimuth of the axial C spin. Expanding a single bond gives a cross term $S^2\mathbf e_{u i}^{\mathsf T}\mathsf J\mathbf e_{v j}\xi_{u i}\xi_{v j}$ and a length-constraint term $-S^2(\mathbf n_i^{\mathsf T}\mathsf J\mathbf n_j)(x_i^2+y_i^2+x_j^2+y_j^2)/2$. The field adds $hS n_i^z(x_i^2+y_i^2)/2$. Summing all nine bonds and using stationarity gives the cell Hessian

$$
\begin{gathered}
\mathcal K_0=\begin{pmatrix}K_x&0\\0&K_y\end{pmatrix},\qquad
U=-J_z+c^2(J+J_z),\quad Z=J_z+c(J_z-J),\\
K_x=3S^2\begin{pmatrix}J&U&-cJ\\U&J&-cJ\\-cJ&-cJ&Z\end{pmatrix},\qquad
K_y=3S^2\begin{pmatrix}J&J&J\\J&J&J\\J&J&Z\end{pmatrix}.
\end{gathered}
$$ {#eq-nbcp-y-uniform-hessian}

A common physical rotation has tangent $\mathbf g=(0,0,0,s,-s,0)^{\mathsf T}$, so $\boldsymbol\xi=\mathbf g\phi+O(\phi^2)$ and $\mathcal K_0\mathbf g=0$. The norm of $\mathbf g$ is not set to one: $\phi$ retains its meaning as an angle in radians. If $\mathbf e_{x_A},\ldots,\mathbf e_{y_C}$ denote the six coordinate unit vectors, choose the five-column projector

$$
\mathsf P=\left(\mathbf e_{x_A},\mathbf e_{x_B},\mathbf e_{x_C},
\frac{\mathbf e_{y_A}+\mathbf e_{y_B}}{\sqrt2},\mathbf e_{y_C}\right),
\qquad H=\mathsf P^{\mathsf T}\mathcal K_0\mathsf P.
$$ {#eq-nbcp-y-hard-projector}

This removes only the uniform phase; both C-spin tilts remain. Local stability requires $H>0$. Let $\mathbf z$ denote these five hard coordinates. The cell energy has quadratic expansion

$$
\delta E_{\rm cell}
=\frac12\mathbf z^{\mathsf T}\mathsf K\mathbf z
+\mathbf z^{\mathsf T}\mathsf L\mathbf Q
+\frac12\mathbf Q^{\mathsf T}\mathsf D\mathbf Q+\cdots,
\qquad
\mathsf D_{\rm relaxed}
=\mathsf D-\mathsf L^{\mathsf T}\mathsf K^{-1}\mathsf L.
$$ {#eq-nbcp-y-stiffness-relaxation}

Here $\mathsf K=H$ is the positive Hessian on the hard subspace. Completing the square gives $\mathbf z_*=-H^{-1}\mathsf L\mathbf Q$ and lowers the quadratic energy by $\mathbf Q^{\mathsf T}\mathsf L^{\mathsf T}H^{-1}\mathsf L\mathbf Q/2$. Inverting the full singular $\mathcal K_0$ would not define this relaxation. In the present XXZ model, differentiating a bond rotation once with respect to $Q_\mu$ produces a factor $\delta_{d\mu}$ multiplying the same spin expression for all three orientations. The vanishing first bond moment therefore gives $\mathsf L=0$, including the axial-spin directions. The relaxed displacement starts at $O(|\mathbf Q|^2)$, and its energy correction starts at $O(|\mathbf Q|^4)$. Thus @eq-nbcp-y-twist-cost already gives the relaxed quadratic coefficient. This argument relies on the bond-independent XXZ exchange and must be rechecked when SOC is introduced.

Matching $\delta e=a_{\rm spin}\rho_s^{\rm cl}|\mathbf Q|^2/2$ with $a_{\rm spin}=\sqrt3a^2/2$ gives the isotropic tensor

$$
\rho_{\mu\nu}^{\rm cl}=\rho_s^{\rm cl}\delta_{\mu\nu},
\qquad
\boxed{\rho_s^{\rm cl}
=\frac{JS^2}{\sqrt3}\left[
1-\left(\frac{h+3SJ_z}{3S(J+J_z)}\right)^2\right]}.
$$ {#eq-nbcp-y-classical-stiffness}

The stiffness has units of energy. The lattice spacing cancels because both the bond second moment and the area per spin scale as $a^2$; the magnetic-cell area is three times the latter and cannot replace it without also changing the energy normalization. The result approaches zero on the Y side of the classical UUD boundary, where the transverse Y component disappears.

**Longitudinal response and the energy slope.**

For completeness, the susceptibility can be obtained from the same Hessian. The cell magnetization changes by $\delta M_z=\mathbf w^{\mathsf T}\mathbf x$, with $\mathbf w=-S(s,-s,0)^{\mathsf T}$. An additional longitudinal field $\delta h$ produces the energy $\mathbf x^{\mathsf T}K_x\mathbf x/2-\delta h\,\mathbf w^{\mathsf T}\mathbf x$. Minimizing gives $\mathbf x_*=K_x^{-1}\mathbf w\,\delta h$. Since

$$
\begin{aligned}
K_x\mathbf w&=3S^2(J+J_z)s^2\mathbf w,\\
\chi_{\rm cell}&=\mathbf w^{\mathsf T}K_x^{-1}\mathbf w
=\frac{2S^2s^2}{3S^2(J+J_z)s^2}
=\frac{2}{3(J+J_z)},\qquad
\chi_z=\frac{\chi_{\rm cell}}{3},
\end{aligned}
$$ {#eq-nbcp-y-hessian-response}

$\chi_z$ is the response per spin to the field energy $h$, without an additional $(g_z\mu_B)^2$ factor. It is also the coefficient of the phase kinetic term after eliminating the conjugate hard mode at this order. The division by three converts the magnetic-cell response to the convention used in the continuum energy.

At zero SOC the pinning curvature vanishes. Combining the relaxed susceptibility $\chi_z=2/[9(J+J_z)]$ from @eq-lswt-yv-pg-y-response with @eq-nbcp-phase-dispersion predicts the leading energy slope

$$
\varepsilon(\mathbf k)=u_Y|\mathbf k|+o(|\mathbf k|),
\qquad
u_Y^2=\frac{a_{\rm spin}\rho_s^{\rm cl}}{\chi_z}
=\frac94 a^2JS^2(J+J_z)(1-c^2).
$$ {#eq-nbcp-y-stiffness-dispersion}

The symbol $u_Y$ is an energy times a length; the physical group velocity is $u_Y/\hbar$. At $B=0.2$ T with the current comparison parameters, $c=0.804246889926$, $\rho_s^{\rm cl}=0.00382336077954$ meV and $u_Y/a=0.0545895118739$ meV. No lattice spacing in metres has been assumed.

The symbolic calculation verifies the stationarity equations, both bond moments, the zero mixed Hessian, the Goldstone null vector, the susceptibility and the formulas above. Numerical checks use five fields, four Cartesian directions and four twist or momentum magnitudes $qa=0.03,0.01,0.003,0.001$. The static estimator is $[e_*(\mathbf Q)+e_*(-\mathbf Q)-2e_*(0)]/(a_{\rm spin}|\mathbf Q|^2)$, where all five internal variables are relaxed at each twist. The dynamic estimator is $\chi_z[\varepsilon(\mathbf k)/|\mathbf k|]^2/a_{\rm spin}$, using the lowest positive production-LSWT energy at nonzero $\mathbf k$ without a gap regulator.

| $B$ (T) | $\rho_s^{\rm cl}$ (meV) | $u_Y/a$ (meV) |
|---:|---:|---:|
| 0.05 | 0.0059685633 | 0.0682058257 |
| 0.10 | 0.0052969722 | 0.0642540367 |
| 0.20 | 0.0038233608 | 0.0545895119 |
| 0.30 | 0.0021758436 | 0.0411813340 |
| 0.40 | 0.0003544207 | 0.0166205783 |

At the smallest tested magnitude, the largest relative deviations over these fields and directions are $2.79\times10^{-6}$ for the relaxed-energy estimator and $2.56\times10^{-6}$ for the LSWT estimator. These are convergence diagnostics, not bounds on physical corrections. An independently assembled Cartesian constrained Hessian reproduces the production-LSWT energies within $1.10\times10^{-13}$ meV. A separately enumerated 36-site triangular torus with twisted boundaries reproduces the three-site energy within $2.09\times10^{-17}$ meV/spin for the sampled configurations. These checks use the same XXZ model and parameters; they do not constitute an independent experimental or many-body validation.

![Classical Y-state stiffness at zero bond-dependent SOC. The energy-difference and LSWT estimates approach the same analytical coefficient. The right panel shows convergence at 0.2 T along the Cartesian x direction; the numerical checks also include three other directions.](../../data-space/verification/260917-y-stiffness/y-stiffness-validation.png){#fig-nbcp-y-stiffness}

This baseline supplies a microscopic spatial coefficient for Y at zero SOC. Its extension to classical Y with SOC is examined next. The stiffness of V, the zero-point correction and the renormalized stiffness entering the finite-temperature clock flow are not supplied by this baseline. Positive local stiffness alone does not establish global phase stability or a finite-temperature supersolid.

## Conditions for extending Y to SOC {#sec-nbcp-y-soc-conditions}

The classical uniform Y family remains stationary when the nearest-neighbor SOC tensors sum to zero over bond orientations. This does not preserve global spin-$z$ rotation as a symmetry of the Hamiltonian. The distinction matters for a spatially varying phase: the uniform energy and its Hessian can remain independent of the angle while the gradient coefficients depend on that angle. The following calculation is a classical harmonic expansion about a specified member $\phi_0$ of the Y family. It does not yet select $\phi_0$ by the quantum vacuum energy.

**Why the uniform-twist shortcut must be replaced.**

For two sites with angles $\phi_i$ and $\phi_j=\phi_i+\mathbf Q\cdot(\mathbf r_j-\mathbf r_i)$, the bond energy contains

$$
\mathbf n_i^{\mathsf T}R_z(\phi_i)^{\mathsf T}\mathsf J_d R_z(\phi_j)\mathbf n_j
=\mathbf n_i^{\mathsf T}
\bigl[R_z(\phi_i)^{\mathsf T}\mathsf J_d R_z(\phi_i)\bigr]
R_z\bigl(\mathbf Q\cdot(\mathbf r_j-\mathbf r_i)\bigr)\mathbf n_j.
$$ {#eq-nbcp-y-soc-twist-obstruction}

In XXZ the bracket equals $\mathsf J_d$. With SOC it depends on the absolute phase $\phi_i$. Replacing this bracket by a fixed tensor in a three-site cell therefore does not describe a global spiral with SOC. Instead, perturb a fixed background by a small-amplitude phase wave, $\phi(\mathbf r)=\phi_0+\epsilon\cos(\mathbf k\cdot\mathbf r)$, and let all five internal coordinates relax. Take $\epsilon\to0$ first, then $\mathbf k\to0$. This defines a local gradient coefficient without sampling the whole angular orbit in space.

There is also a sign convention to resolve before attaching laboratory directions to this calculation. In the current NBCP builder, the stored vectors $\mathbf d$ match $\mathbf r_i-\mathbf r_j$ modulo magnetic translations, whereas the `SpinSystem` interface documents the opposite displacement. The diagnostic uses the existing Fourier factor $e^{-\mathrm i\mathbf k\cdot\mathbf d}$ and the compatible real-space embedding $\mathbf r_j=\mathbf r_i-\mathbf d$. Thus the formulas below refer to the current code's momentum coordinates. Reversing every displacement leaves the even stiffness unchanged and reverses the odd dispersion term. The production convention is left as an open issue; no API or Hamiltonian change is made here.

Write $p=J_{\rm PD}$ and $\Gamma=J_\Gamma$ in the following formulas, with the exchange matrices defined in @eq-nbcp-bond-matrix. For stored $\mathbf d=a(\cos\varphi_d,\sin\varphi_d)$ and $\varphi_d=0,2\pi/3,4\pi/3$, the uniform sum is $\sum_d\mathsf J_d=3\operatorname{diag}(J,J,J_z)$, but its first moments are

$$
\begin{aligned}
M_x=\sum_d d_x\mathsf J_d
&=a\begin{pmatrix}3p&0&0\\0&-3p&3\Gamma/2\\0&3\Gamma/2&0\end{pmatrix},\\
M_y=\sum_d d_y\mathsf J_d
&=a\begin{pmatrix}0&-3p&-3\Gamma/2\\-3p&0&0\\-3\Gamma/2&0&0\end{pmatrix}.
\end{aligned}
$$ {#eq-nbcp-y-soc-first-moments}

Consequently, the zero first moment of the *unweighted* bond vectors no longer implies a vanishing phase-gradient coupling to the hard coordinates.

**Static elimination of the internal modes.**

Rotate the reference spins and their tangent frames together by $\phi_0$. Assemble their constrained Fourier Hessian $\mathcal K(\mathbf k;\phi_0)$ from the bond expansion used above. For distinct sublattices its tangent block contains $S^2\mathbf e_{u i}^{\mathsf T}\mathsf J_d\mathbf e_{v j}e^{-\mathrm i\mathbf k\cdot\mathbf d}$, and the reversed block is its Hermitian conjugate. The diagonal terms come from the length constraint and field. The uniform sum makes $\mathcal K(0;\phi_0)=\mathcal K_0$ of @eq-nbcp-y-uniform-hessian for this Y family.

Expand $\mathcal K=\mathcal K_0+k_\mu\mathcal K_\mu+k_\mu k_\nu\mathcal K_{\mu\nu}/2+\cdots$, and use the physical phase tangent $\mathbf g$ and projector $\mathsf P$ already defined. With real exchange tensors, the first derivative is purely imaginary. Define real hard-source vectors and a direct gradient tensor by

$$
\boldsymbol\ell_\mu=-\mathrm i\mathsf P^{\mathsf T}\mathcal K_\mu\mathbf g,
\qquad
D_{\mu\nu}=\tfrac12\mathbf g^{\mathsf T}\mathcal K_{\mu\nu}\mathbf g,
\qquad H=\mathsf P^{\mathsf T}\mathcal K_0\mathsf P.
$$ {#eq-nbcp-y-soc-gradient-sources}

The exact static Schur complement at fixed $\mathbf k$, followed by its small-$k$ expansion, gives

$$
\begin{aligned}
\kappa_{\rm stat}(\mathbf k)
&=\mathbf g^\dagger\mathcal K\mathbf g
-\mathbf g^\dagger\mathcal K\mathsf P
(\mathsf P^\dagger\mathcal K\mathsf P)^{-1}
\mathsf P^\dagger\mathcal K\mathbf g,\\
\kappa_{\rm stat}(\mathbf k)&=k_\mu C_{\mu\nu}k_\nu+O(k^4),\\
C_{\mu\nu}&=D_{\mu\nu}
-\operatorname{Re}\bigl(\boldsymbol\ell_\mu^{\mathsf T}H^{-1}\boldsymbol\ell_\nu\bigr),
\qquad \rho_{\mu\nu}^{\rm stat}=\frac{C_{\mu\nu}}{3a_{\rm spin}}.
\end{aligned}
$$ {#eq-nbcp-y-soc-static-schur}

The factor $3a_{\rm spin}$ is the cell area because $\mathcal K$ is a cell-energy Hessian. Internal relaxation lowers the static gradient tensor by a positive-semidefinite matrix when $H>0$. The source vectors have units of energy times length and $C$ has units of energy times length squared. This subtraction is present already at $k^2$ with SOC.

At $\phi_0=0$, the bond derivatives give the following explicit six-component sources before projection, $\boldsymbol\ell_\mu=\mathsf P^{\mathsf T}\widetilde{\boldsymbol\ell}_\mu$:

$$
\begin{aligned}
\widetilde{\boldsymbol\ell}_x
&=aS^2(-3\Gamma s^2/2,\;3\Gamma s^2/2,\;0,\;-3ps,\;-3ps,\;6ps)^{\mathsf T},\\
\widetilde{\boldsymbol\ell}_y
&=aS^2(-3psc,\;-3psc,\;-6ps,\;0,\;0,\;0)^{\mathsf T},\\
D&=\frac32a^2S^2s^2
\begin{pmatrix}J-p&0\\0&J+p\end{pmatrix}.
\end{aligned}
$$ {#eq-nbcp-y-soc-explicit-sources}

Together with the explicit $H$ above, these expressions specify $C$ without finite differences or a singular inverse. In particular $C_{xy}=0$ at this reference angle. The direct term changes linearly in $p$, while the relaxation subtraction is quadratic in the SOC couplings. Other background angles require rotating the tangent frames in the bond tensors; they need not have the same diagonal components.

**Dynamics and the two momentum directions.**

The dynamical elimination must retain the conjugate hard coordinates as well. In energy units, their antisymmetric form is

$$
\Omega=S\begin{pmatrix}0&-I_3\\I_3&0\end{pmatrix},\qquad
\mathbf b=\mathsf P^{\mathsf T}\Omega\mathbf g,\qquad
\chi_{\rm cell}=\mathbf b^{\mathsf T}H^{-1}\mathbf b.
$$ {#eq-nbcp-y-soc-symplectic-form}

The linear spectral equation is $(\mathcal K+\mathrm i\varepsilon\Omega)\boldsymbol\xi=0$, where $\varepsilon=\hbar\omega$. Its hard-to-phase block is $\mathrm i(k_\mu\boldsymbol\ell_\mu+\varepsilon\mathbf b)$ to first order. Eliminating it with $H^{-1}$ therefore produces a mixed term as well as the static and inertial terms:

$$
\begin{aligned}
\kappa(\mathbf k,\varepsilon)
&=k_\mu C_{\mu\nu}k_\nu
-2\varepsilon\beta_\mu k_\mu-\chi_{\rm cell}\varepsilon^2+\cdots,\\
\beta_\mu&=\mathbf b^{\mathsf T}H^{-1}\boldsymbol\ell_\mu,
\qquad \mathbf v=\boldsymbol\beta/\chi_{\rm cell}.
\end{aligned}
$$ {#eq-nbcp-y-soc-dynamic-schur}

Solving the quadratic equation for the positive low-energy branch gives

$$
\begin{aligned}
\varepsilon(\mathbf k)
&=-\mathbf v\cdot\mathbf k+
\sqrt{(\mathbf v\cdot\mathbf k)^2+
\mathbf k^{\mathsf T}C\mathbf k/\chi_{\rm cell}}+o(|\mathbf k|),\\
\left.\mathbf v\right|_{\phi_0=0}
&=(3aS\Gamma s/2,\;0),\qquad
\chi_{\rm cell}=\frac{2}{3(J+J_z)}.
\end{aligned}
$$ {#eq-nbcp-y-soc-nonreciprocal-dispersion}

The coefficient $\mathbf v$ has units of energy times length. A nonzero $\Gamma$ makes the two signed slopes different at $\phi_0=0$. The product, however, eliminates this drift at leading order:

$$
\widehat{\mathbf k}^{\mathsf T}\rho^{\rm stat}\widehat{\mathbf k}
=\lim_{k\to0}
\frac{\chi_z\,\varepsilon(k\widehat{\mathbf k})
\varepsilon(-k\widehat{\mathbf k})}{a_{\rm spin}k^2},
\qquad \chi_z=\chi_{\rm cell}/3.
$$ {#eq-nbcp-y-soc-paired-estimator}

Thus squaring one positive-$k$ slope does not generally recover the static stiffness. The zero-SOC formula is recovered when both SOC couplings vanish. These relations describe the gapless classical harmonic branch. They do not justify inserting the quantum pseudo-Goldstone gap into the same expression without a consistent treatment of the quantum effective energy and dynamics.

**Local numerical checks and remaining conditions.**

At $B=0.2$ T, $S=1/2$, $J=0.075$ meV, $J_z=0.125$ meV and $\phi_0=0$, the calculated coefficients are:

| $p$ (meV) | $\Gamma$ (meV) | $\rho_{xx}$ (meV) | $\rho_{yy}$ (meV) | $v_x/a$ (meV) |
|---:|---:|---:|---:|---:|
| 0 | 0 | 0.0038233608 | 0.0038233608 | 0 |
| 0.005 | 0 | 0.0032801939 | 0.0036766924 | 0 |
| 0 | 0.005 | 0.0038169885 | 0.0038233608 | 0.0022286075 |
| 0.005 | 0.005 | 0.0032738216 | 0.0036766924 | 0.0022286075 |

All four cases have $\rho_{xy}=0$ at this angle. The symbolic calculation passes 13 exact checks, including the first moments, hard sources, susceptibility, drift and zero-SOC limit. Numerical comparisons cover these four couplings at $\phi_0=0,0.173,\pi/6$, three momentum directions and four magnitudes $ka=0.03,0.01,0.003,0.001$. At the finest magnitude, the maximum relative differences from the analytic coefficient are $1.28\times10^{-7}$ for the static Schur estimate and $1.18\times10^{-7}$ for the paired-dispersion estimate. The predicted individual energies differ from the production LSWT values by at most $6.09\times10^{-8}$ relatively. The separately assembled tangent dynamics and production spectra agree within $1.46\times10^{-13}$ meV.

A real-space energy check independently enumerates a periodic 576-site triangular lattice, with the code-compatible bond embedding stated above. For each of the four $\phi_0=0$ cases, a relaxed Fourier tangent is imposed with amplitudes $0.002$ and $0.001$ and exact spin-length normalization. The symmetric energy difference approaches the same finite-momentum static kernel. This checks the cell factor and the real-space meaning of the Fourier relaxation; it does not resolve the API displacement wording or independently reconstruct the microscopic Hamiltonian.

The extension can be used locally when the background is stationary, the five-dimensional $H$ is positive and separated from zero, and the relaxed tensor $C$ is positive. Approaching an additional soft mode requires retaining that mode explicitly rather than eliminating it. These are necessary local conditions; the full-zone numerical screen in @sec-nbcp-y-full-zone-stability extends them at one field, while competing-phase comparisons remain necessary. Quantum use additionally requires the selected angle $\phi_*$, the pinning curvature there, and a controlled decision about the order retained in the gradient and dynamical coefficients. None of the present benchmarks is a quantum-corrected stiffness or a finite-temperature phase boundary.

# Numerical Verification and Reproduction {#sec-nbcp-verification-appendix .newpage}

## Implementation findings and coordinate checks {#sec-legacy}

The archived gap implementation has known coordinate and Hamiltonian-assembly discrepancies. Their detailed code locations and interpretation are retained in the [physics-to-code review record](../../GOVERNMENT/Working-Pad/issue-notes/open/260918-nbcp-physics-code-review.md#preserved-legacy-implementation-findings). The matrix and coordinate comparison below records the existing numerical evidence, without treating agreement with the archive as physical validation.

### Matrix and coordinate checks

The matrix comparison uses independent Cartesian Holstein-Primakoff (HP) coefficients at $J_{PD}=J_\Gamma=0.005$ meV. Matrix errors are in meV; the two hard-curvature columns are in meV per spin.

| Phase | Current H error | Archive H error | Original chart | Equivalent chart |
|---|---:|---:|---:|---:|
| Y | $2.784\times10^{-17}$ | $1.536\times10^{-2}$ | 0.0206658746 | 0.0766217798 |
| V | $4.164\times10^{-17}$ | $2.017\times10^{-2}$ | 0.0850517129 | 0.0255063026 |

Changing one spin from (theta, phi) to (-theta, phi+pi) leaves the physical configuration and the current zero-point energy unchanged, but reapplying the archived uniform-theta rule selects a different physical perturbation and hence a different hard curvature. The relaxed susceptibility is invariant, as checked in the detailed derivation above.

## Numerical convergence {#sec-convergence .newpage}

The reciprocal quadrature uses N x N midpoints and six rotated copies, without an endpoint duplication or a k=0 regulator. All positive physical bands and the normal-ordering trace constant enter the vacuum energy. Fits include all harmonics 1 through 18, without imposing Z3/Z6. Very small fitted curvature is marked unresolved against an estimated floating-point/fit floor; this estimate is not a rigorous error bound.

| Base mesh N | Phase | SOC = 0.010 meV | Gap (meV) |
|---:|---|---|---:|
| 12 | Y | PD | 0.0068587113552 |
| 12 | Y | Gamma | $7.29595989041\times10^{-6}$ |
| 12 | V | PD | 0.0156410420112 |
| 12 | V | Gamma | 0.00203895133135 |
| 24 | Y | PD | 0.00686145193025 |
| 24 | Y | Gamma | $7.29600055943\times10^{-6}$ |
| 24 | V | PD | 0.0156460286068 |
| 24 | V | Gamma | 0.00203898155653 |
| 48 | Y | PD | 0.0068621739178 |
| 48 | Y | Gamma | $7.2959923841\times10^{-6}$ |
| 48 | V | PD | 0.0156468152768 |
| 48 | V | Gamma | 0.00203898166782 |

Local five-point curvature independently checks the angular fits. Representative results at N=96 and step 0.04 rad:

| Phase | SOC | Gap (meV) | Mesh change | Step change |
|---|---|---:|---:|---:|
| Y | PD | 0.00686213408 | $1.524\times10^{-5}$ | $2.009\times10^{-5}$ |
| Y | Gamma | $7.29575296\times10^{-6}$ | $-2.291\times10^{-5}$ | $9.395\times10^{-5}$ |
| V | PD | 0.0156467362 | $8.114\times10^{-6}$ | $2.554\times10^{-5}$ |
| V | Gamma | 0.00203897924 | $-3.107\times10^{-8}$ | $1.087\times10^{-6}$ |

Mesh change means $N=48\to96$ at a fixed step of 0.04 rad; step change means $0.04\to0.02$ rad at $N=96$. The entries are relative changes, not percentages. Their absolute values are below 0.01% at these four representative points. The existing Hamiltonian-pairing regression suite also passed all eight tests during the calculation session.

For the very weak Y/Gamma energy modulation, making the derivative step too small amplifies cancellation error; all four step sizes are preserved in `curvature-validation.json`. These convergence differences do not bound higher-order physical corrections.

## Evidence and reproduction

- [Classical density-wall scan](../../data-space/verification/260918-y-density-wall/density-wall-check.json) and [refinements](../../data-space/verification/260918-y-density-wall/density-wall-validation.json), reproduced by [the wall diagnostic](../../examples/nbcp_y_density_wall.py) and [the refinement script](../../examples/nbcp_y_density_wall_validation.py). These retain full-sphere spin motion, two periodic interfaces and explicit phase-boundary conventions. The results are classical local minima, not thermal wall free energies.

- [Nonlinear smooth-wave results](../../data-space/verification/260918-y-nonlinear-gradient/nonlinear-gradient-check.json), reproduced by [the constrained classical diagnostic](../../examples/nbcp_y_nonlinear_gradient.py): 216 configurations, finite-momentum harmonic matching, analytic-gradient checks, random starts and a fixed-wavelength torus comparison. This tests the classical gradient sector within a local Y chart; it does not compute defects or thermal coefficients.

- [Y angular matching](../../data-space/verification/260918-y-angular-matching/angular-matching-check.json): full-circle tensors, principal directions, unconstrained harmonics, pure and mixed SOC scans, numerical-resolution diagnostics and source hashes. Reproduce with [the matching diagnostic](../../examples/nbcp_y_angular_matching.py). [Independent numerical checks](../../data-space/verification/260918-y-angular-matching/independent-check.json), produced by [the validation script](../../examples/nbcp_y_angular_validation.py), use fresh unaveraged momenta, off-grid tensor evaluations and local five-point energy curvatures. These checks do not replace quantum or thermal matching or human physics review.

- [Y full-zone stability screen](../../data-space/verification/260917-y-stability/stability-check.json): mesh and local-refinement minima, phase-projector overlaps, adjustable tolerances, direct matrix and archived-code comparisons, an intentionally unstable control, runtime and input hashes. Reproduce with [the stability diagnostic](../../examples/nbcp_y_stability.py). The calculation tests harmonic stability at one field and does not replace a competing-phase or quantum thermal calculation.

- [Four-case angular-energy figure](../../data-space/verification/260917-clock-matching/four-case-figure.json): panel parameters, saved energy differences, source hashes and plotting provenance. Reproduce with [the four-case plotter](../../examples/nbcp_clock_matching_figures.py). The original scan arrays and earlier orbit illustration remain unchanged.

- [Clock RG normalization checks](../../data-space/verification/260917-clock-rg/clock-rg-check.json), reproduced by [the symbolic check](../../examples/nbcp_clock_rg_checks.py): shell variance, dipole factors, duality normalization, constant-tensor mapping and sixfold exponents. No thermal RG trajectory is computed.

- [Y SOC symbolic checks](../../data-space/verification/260917-y-soc-conditions/symbolic-soc-check.json) and [numerical checks](../../data-space/verification/260917-y-soc-conditions/soc-conditions-check.json): first moments, static and dynamical reduction, representative coefficients and the open bond-direction convention issue. Reproduce with [Wolfram Language](../../examples/nbcp_y_soc_conditions.wl) followed by [Python](../../examples/nbcp_y_soc_conditions.py).

- [Y stiffness symbolic checks](../../data-space/verification/260917-y-stiffness/symbolic-check.json) and [numerical checks](../../data-space/verification/260917-y-stiffness/stiffness-check.json): the zero-SOC classical baseline and its scope. Reproduce with [Wolfram Language](../../examples/nbcp_y_stiffness.wl) followed by [Python](../../examples/nbcp_y_stiffness.py); both scripts preserve the existing gap scans.
- [Clock-anisotropy audit JSON](../../data-space/verification/260916-clock-anisotropy/clock-anisotropy-audit.json): coefficients at three meshes, fresh matrix checks, input and code hashes, and limitations.
- [Diagnostic script](../../examples/nbcp_clock_anisotropy_audit.py): rerun from the repository root with `PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 python examples/nbcp_clock_anisotropy_audit.py`.
- [Existing scan data](../../data-space/verification/260912-pseudo-goldstone/): preserved original energy arrays. New angular and momentum refinements are stored separately in the angular-matching directory.

## Reproduction and provenance {#sec-reproduction .newpage}

- `examples/pseudo_goldstone_comparison.py`: calculation, checks and original-class replay.
- `examples/pseudo_goldstone_plot.py`: figures only, regenerated from saved calculation data.
- `examples/pseudo_goldstone_validation.py`: independent local curvature and $N=96$ checks.
- `examples/pseudo_goldstone_conjugate_mode.py`: explicit Y/V partner, constrained relaxation, coordinate invariance and weak-pinning dynamics checks.
- `examples/nbcp_research_export.py`: PDF export from the single Markdown manuscript.
- `scan-N*-P72.json`: actual arrays, failures, diagnostics and source hashes.
- `curvature-validation.json`: finite-difference and mesh checks.
- `conjugate-mode-validation-260915.json`: the 2026-09-15 canonical-partner verification and source hashes.
- `legacy-replay-*.txt`: unchanged legacy gap class executed with the matched inputs.

Run the scan from the repository root:

```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 \
  python examples/pseudo_goldstone_comparison.py --mesh 48 \
  --couplings 0 0.0025 0.005 0.0075 0.01 0.0125 0.015 0.0175 0.02
```

To regenerate the PDF preview from this Markdown:

```bash
python examples/nbcp_research_export.py
```

The complete manuscript, including this appendix and the clock analysis, is edited in `docs/nbcp/research-note.md`. Calculation data and original figures remain in `data-space/verification/`. The exporter requires Quarto and XeLaTeX and writes only `research-note.pdf` and `research-export.json` to `docs/nbcp/output/`. Intermediate TeX, rendering Markdown and figure copies exist only in a temporary directory. The ordinary LaTeX preamble and conversion filter in `examples/nbcp-note-style/` control presentation, not scientific content.

### Scope and revision record

The numerical comparison was recorded on 2026-09-12, the explicit canonical-mode derivation and cross-checks on 2026-09-15, and the research-note layout on 2026-09-16. On 2026-09-16 the detailed gap and clock notes were consolidated with the main chapters into one Markdown manuscript. This Markdown is the editable internal record; the PDF is generated from it. The note remains in review and is not an accepted theory document or a publication-ready result. The production package and archived scripts were not edited as part of this comparison.

The original gap script defaults to $J=0.076$ meV and $h=0.05$ meV. The comparisons instead supply the same paper parameters and states to both implementations. An earlier discussion of the internal XXZ orbit did not invalidate the common-$z$ orbit used by the archived SOC-induced Y/V calculation.

The scan field `old_pair_Berry_coefficient_per_spin` records $+(S/3)\sum_\alpha\sin\vartheta_\alpha$, opposite to the sign convention used for $b_{\mathbf u}$ in the derivation. The gap depends on its square. The canonical-response evidence and source hashes are preserved in `conjugate-mode-validation-260915.json`.

# References and Source Roles {#references .unnumbered .newpage}

## Sources for the gap analysis {.unnumbered}

1. Seongjun Park, Sung-Min Park, Yun-Tak Oh, Hyun-Yong Lee, and Eun-Gook Moon, *Spin-orbit-induced Instability and Finite-Temperature Stabilization of a Triangular-lattice Supersolid*, [arXiv:2601.20963v1](https://arxiv.org/abs/2601.20963v1) (2026). Source for the model, common-$z$ orbit, and Figure 4 parameter choices.

2. Jeffrey G. Rau, Paul A. McClarty, and Roderich Moessner, *Pseudo-Goldstone gaps and order-by-quantum-disorder in frustrated magnets*, [Physical Review Letters **121**, 237201](https://doi.org/10.1103/PhysRevLett.121.237201) (2018); [arXiv:1805.00947v2](https://arxiv.org/abs/1805.00947v2). Source for the leading-order curvature formula and conjugate zero-mode coordinates. The susceptibility reduction here records its application to the common-$z$ mode.

3. Xiyue Lin and Tao Shi, *Pseudo-Goldstone Modes at Finite Temperature*, [arXiv:2505.07229v1](https://arxiv.org/abs/2505.07229v1) (2025). Reference for nonlinear soft paths; the internal zero-field XXZ mode discussed there is a separate target.

## Sources for the clock analysis {.unnumbered}

- J. Chen et al., [Phase transition of the q-state clock model: duality and tensor renormalization](https://arxiv.org/abs/1706.03455), Chinese Physics Letters 34, 050503 (2017). The abstract reports tensor calculations of both transition temperatures for the standard six-state clock model; this supports the effective-model mechanism, not microscopic NBCP matching.

- S. Park, S.-M. Park, Y.-T. Oh, H.-Y. Lee and E.-G. Moon, [Spin-orbit-induced Instability and Finite-Temperature Stabilization of a Triangular-lattice Supersolid](https://arxiv.org/html/2601.20963v1), arXiv:2601.20963v1 (2026). Section II, model-symmetry discussion, Figure 4 and Eqs. (3)-(4) specify the claims reviewed here. The arXiv record checked on 2026-09-16 lists v1.
- J. V. Jose, L. P. Kadanoff, S. Kirkpatrick and D. R. Nelson, [Renormalization, vortices, and symmetry-breaking perturbations in the two-dimensional planar model](https://doi.org/10.1103/PhysRevB.16.1217), Physical Review B 16, 1217 (1977); [erratum](https://doi.org/10.1103/PhysRevB.17.1477), Physical Review B 17, 1477 (1978). The publisher abstract supports the sixfold-anisotropy mechanism; the full article and erratum were not inspected here. The linearized exponents used above are explicitly derived from the Gaussian action and vortex energy-entropy balance.

