"""Export the single Markdown NBCP manuscript to a PDF preview.

No physics calculation runs here. Intermediate TeX, rendering Markdown and
figure copies are temporary; only the PDF and provenance manifest are retained.
"""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'docs/nbcp/research-note.md'
STYLE = ROOT / 'examples/nbcp-note-style'
OUTPUT = ROOT / 'docs/nbcp/output'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(args, cwd):
    result = subprocess.run(args, cwd=cwd, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(result.stdout[-8000:] + result.stderr[-8000:])
    return result


def main():
    quarto, xelatex = shutil.which('quarto'), shutil.which('xelatex')
    if not quarto or not xelatex:
        raise RuntimeError('Quarto and XeLaTeX are required.')
    images = {}

    def relocate(text, origin):
        def image_link(match):
            target=(origin.parent/match.group(1)).resolve()
            if not target.is_file():
                raise FileNotFoundError(target)
            if target.name in images and images[target.name] != target:
                raise ValueError('Image basename collision')
            images[target.name]=target
            return ']('+target.name+')'
        text=re.sub(r'\]\(([^)]+\.(?:png|svg|jpg))\)',image_link,text)
        # Local evidence links point to the original files, even from scratch/output.
        def local_link(match):
            href=match.group(1)
            if href.startswith(('https:', 'http:', '#')) or href in images:
                return match.group(0)
            path, sep, anchor=href.partition('#')
            target=(origin.parent/path).resolve()
            return ']('+target.as_uri()+(sep+anchor if sep else '')+')'
        return re.sub(r'\]\(([^)]+)\)',local_link,text)

    source_text=SOURCE.read_text()
    rendered=relocate(source_text,SOURCE)
    inputs=[SOURCE,STYLE/'research-note-preamble.tex',STYLE/'research-note-filter.lua',Path(__file__)]
    original_hashes={str(p.relative_to(ROOT)):digest(p) for p in inputs}
    with tempfile.TemporaryDirectory(prefix='nbcp-research-') as directory:
        scratch=Path(directory)
        (scratch/'research-note.md').write_text(rendered)
        for name,path in images.items():
            shutil.copy2(path,scratch/name)
        settings={
            'format':{'latex':{
                'documentclass':'article','fontsize':'11pt','papersize':'a4',
                'geometry':['left=25mm','right=25mm','top=25mm','bottom=25mm'],
                'mainfont':'texgyrepagella-regular.otf',
                'mainfontoptions':['BoldFont=texgyrepagella-bold.otf','ItalicFont=texgyrepagella-italic.otf',
                                   'BoldItalicFont=texgyrepagella-bolditalic.otf'],
                'sansfont':'texgyreheros-regular.otf',
                'sansfontoptions':['BoldFont=texgyreheros-bold.otf','ItalicFont=texgyreheros-italic.otf'],
                'monofont':'texgyrecursor-regular.otf','monofontoptions':['BoldFont=texgyrecursor-bold.otf'],
                'mathfont':'texgyrepagella-math.otf','number-sections':True,
                'toc':True,'toc-depth':2,'colorlinks':True,
                'include-in-header':str(STYLE/'research-note-preamble.tex')}},
            'filters':[str(STYLE/'research-note-filter.lua')],
            'crossref':{'eq-prefix':'Eq.','fig-prefix':'Fig.'},'execute':{'enabled':False}}
        (scratch/'settings.yml').write_text(json.dumps(settings,indent=2))
        run([quarto,'render','research-note.md','--to','latex','--metadata-file','settings.yml',
             '--output','research-note.tex'],scratch)
        tex=scratch/'research-note.tex'
        tex.write_text('% Generated from docs/nbcp/research-note.md.\n'
                       '% Edit Markdown for content; LaTeX styling is in examples/nbcp-note-style/.\n'+tex.read_text())
        for _ in range(3):
            run([xelatex,'-interaction=nonstopmode','-halt-on-error','-no-shell-escape','research-note.tex'],scratch)
        log=(scratch/'research-note.log').read_text(errors='replace')
        bad=[line for line in log.splitlines() if any(k in line for k in
             ['Overfull','Missing character','undefined references','multiply defined'])]
        if bad:
            raise RuntimeError('PDF review failed:\n'+'\n'.join(bad))
        OUTPUT.mkdir(parents=True,exist_ok=True)
        assert original_hashes=={str(p.relative_to(ROOT)):digest(p) for p in inputs}
        shutil.copy2(scratch/'research-note.pdf',OUTPUT/'research-note.pdf')
        manifest={'generated_utc':datetime.now(timezone.utc).isoformat(),
                  'inputs_sha256':original_hashes,
                  'figure_inputs_sha256':{str(p.relative_to(ROOT)):digest(p) for p in images.values()},
                  'outputs_sha256':{'research-note.pdf':digest(OUTPUT/'research-note.pdf')},
                  'latex_review_messages':bad,
                  'source_display_equations':source_text.count('$$')//2,
                  'scope':'PDF preview only; single Markdown source; no physics scan rerun'}
        (OUTPUT/'research-export.json').write_text(json.dumps(manifest,indent=2)+'\n')
        print(json.dumps(manifest,indent=2))
    assert original_hashes=={str(p.relative_to(ROOT)):digest(p) for p in inputs}


if __name__=='__main__':
    main()
